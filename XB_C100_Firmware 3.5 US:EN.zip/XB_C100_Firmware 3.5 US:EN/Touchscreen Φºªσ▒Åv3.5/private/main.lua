local last_sreen=0           --��¼��һ�ε�ҳ��
local current_screen=0       --��¼��ǰ����

local time1 = 15000--60���޴���  �л�����������
local time2 = 100--100����   ����10���Ӳ�ѯһ�ο�������״̬
local time3 = 500--500����   �����Զ����Ե�ַ����
local time4 = 500--500���� ���Ʋ���ģʽ���Ͳ��ַ����
local time5 = 6000--6���� ��������ʱд���ַ�Ͳ��� ��ʾ�������ʾʱ��

local auto_run=0 
local auto_run_tt=0
local run_num=0
local run_num_tt=0
local jiange_ch=0
local chongfu_ch=0
local tongyi=0
local fangxiang=0
local sel_contr=0
local sel_port=0
local start_ch=0
local sel_chip=0
local check_sum=0
local tmp_dat={}--д����ʱ�������ʱ����
local send_cmd_xb={}--��������������������

local SM185_cur_count=0

local S5C2=0
local S5C3
local SM1722_param =0 
local SM1722_current = 0
local rr,gg,bb,ww,nw,aw=0
local ch,chip,cyc=0
local brightness=255
local mode=0
local ss
local cmd_param=0

local UCS512_param=0
local buchang_ok=0

local first_run = 0
local first_run_1=0
local first_run_2=0
local SD_Exist = 0
local bat = 0
local DL_value =0 
local Is_charge = 0
local charge_frame = 0
local charge_frame_low = 0
local upgrade = 0
local ver="���̰汾:v3.5" --�����汾��
local ver_H,ver_L  --�������汾��
local DMX_add_param -- DMXд��ַ����д����
local Touch_over--�Ƿ�����������
local secret_1--��һ�β��������
local secret_2--��һ�β��������
local ztd_flag--��ͨ�����ֱ��
local str
local DMX_Status_page--д���ַ�Ͳ��� �ƾ�״̬

local buc_time_G,buc_time_count_G,buc_time_H,buc_time_count_H

local draw_pen_color = 0xFFFF                       --������ɫΪ��ɫ��RGB565

local Is_charge_tmp
local delay_show
local delay_count

local test_flash

local rtc_n,rtc_y,rtc_r,rtc_s,rtc_f,rtc_m,rtc_w

local ic_sel_test

local Save_screen
local Save_show

local sd_guiji=0

local data={}--��flash�б��濪���´�ʱ����Ϣ

local draw_select_x = 150
local draw_select_y = 140

local select_rgb       = 0xffff

local qh_chip	--д�� д����

local xh=0

local GSTY = 0

local ys = 3

local xp=0

local xp_num=35

local Auto_write = 0

local GS_BPH = 16

local GS_canshu

--��
function And(num1,num2)
	local tmp1 = num1
	local tmp2 = num2
	local ret = 0
	local count = 0
	repeat
		local s1 = tmp1 % 2
		local s2 = tmp2 % 2
		if s1 == s2 and s1 == 1 then
			ret = ret + 2^count
		end
		tmp1 = math.modf(tmp1/2)
		tmp2 = math.modf(tmp2/2)
		count = count + 1
	until(tmp1 == 0 and tmp2 == 0)
	return ret
end

--��
function Or(num1,num2)
	local tmp1 = num1
	local tmp2 = num2
	local ret = 0
	local count = 0
	repeat
		local s1 = tmp1 % 2
		local s2 = tmp2 % 2
		if s1 == s2 and s1 == 0 then
 
		else
			ret = ret + 2^count
		end
		tmp1 = math.modf(tmp1/2)
		tmp2 = math.modf(tmp2/2)
		count = count + 1
	until(tmp1 == 0 and tmp2 == 0)
	return ret
end

--���
function Xor(num1,num2)
	local tmp1 = num1
	local tmp2 = num2
	local ret = 0
	local count = 0
	repeat
		local s1 = tmp1 % 2
		local s2 = tmp2 % 2
		if s1 ~= s2 then
			ret = ret + 2^count
		end
		tmp1 = math.modf(tmp1/2)
		tmp2 = math.modf(tmp2/2)
		count = count + 1
	until(tmp1 == 0 and tmp2 == 0)
	return ret
end

function show_week()
	if get_language() == 0--����
	then
		rtc_n,rtc_y,rtc_r,rtc_s,rtc_f,rtc_m,rtc_w = get_date_time()
		
		if rtc_w == 1
		then	
			set_text(0,24,"����һ")
			set_text(37,10,"����һ")
		elseif rtc_w == 2
		then	
			set_text(0,24,"���ڶ�")
			set_text(37,10,"���ڶ�")
		elseif rtc_w == 3
		then	
			set_text(0,24,"������")
			set_text(37,10,"������")
		elseif rtc_w == 4
		then
			set_text(0,24,"������")
			set_text(37,10,"������")
		elseif rtc_w == 5
		then	
			set_text(0,24,"������")
			set_text(37,10,"������")
		elseif rtc_w == 6
		then
			set_text(0,24,"������")
			set_text(37,10,"������")
		elseif rtc_w == 0
		then	
			set_text(0,24,"������")
			set_text(37,10,"������")
		end
	elseif get_language() == 1--Ӣ��
	then
		rtc_n,rtc_y,rtc_r,rtc_s,rtc_f,rtc_m,rtc_w = get_date_time()
		
		if rtc_w == 1
		then	
			set_text(0,24,"Monday")
			set_text(37,10,"Monday")
		elseif rtc_w == 2
		then	
			set_text(0,24,"Tuesday")
			set_text(37,10,"Tuesday")
		elseif rtc_w == 3
		then	
			set_text(0,24,"Wednesday")
			set_text(37,10,"Wednesday")
		elseif rtc_w == 4
		then	
			set_text(0,24,"Thursday")
			set_text(37,10,"Thursday")
		elseif rtc_w == 5
		then	
			set_text(0,24,"Friday")
			set_text(37,10,"Friday")
		elseif rtc_w == 6
		then	
			set_text(0,24,"Saturday")
			set_text(37,10,"Saturday")
		elseif rtc_w == 0
		then	
			set_text(0,24,"Sunday")
			set_text(37,10,"Sunday")
		end
	end
end

function language_sel(lang)
	local temp
	
	if lang == 0 --����
	then
		set_language(0)	--�������Ļ���
		---------------------

		rtc_n,rtc_y,rtc_r,rtc_s,rtc_f,rtc_m,rtc_w = get_date_time()
		
		if rtc_w == 1
		then	
			set_text(0,24,"����һ")
			set_text(37,10,"����һ")
		elseif rtc_w == 2
		then	
			set_text(0,24,"���ڶ�")
			set_text(37,10,"���ڶ�")
		elseif rtc_w == 3
		then	
			set_text(0,24,"������")
			set_text(37,10,"������")
		elseif rtc_w == 4
		then
			set_text(0,24,"������")
			set_text(37,10,"������")
		elseif rtc_w == 5
		then	
			set_text(0,24,"������")
			set_text(37,10,"������")
		elseif rtc_w == 6
		then
			set_text(0,24,"������")
			set_text(37,10,"������")
		elseif rtc_w == 0
		then	
			set_text(0,24,"������")
			set_text(37,10,"������")
		end

		temp = get_value(0,12)
		if temp == 0
		then
			set_text(0,17,"Ԥ��Ч��")
		else 
			set_text(0,17,"SDЧ��")
		end

		temp = get_value(0,14)
		if temp == 0
		then
			set_text(0,19,"3ͨ��")
		else
			set_text(0,19,"4ͨ��")
		end

 		temp = get_value(0,21)
		if temp == 0
		then
			set_text(0,22,"��ѭ��")
		else
			set_text(0,22,"ѭ��")
		end	
	
		set_text(1,5,"���¹̼�")

		temp = get_value(3,12)
		if temp == 0
		then
			set_text(3,2,"дַ")
		else
			set_text(3,2,"����дַ")
		end
		
		temp = get_value(69,12)
		if temp == 0
		then
			set_text(69,2,"дַ")
		else
			set_text(69,2,"����дַ")
		end
		
		if get_text(69,27)=="Self channel"
		then
			set_text(69,27,"��ͨ��дַ")
		elseif get_text(69,27)=="Parallel write"
		then
			set_text(69,27,"����дַ")
		elseif get_text(69,27)=="Conventional"
		then
			set_text(69,27,"����дַ")
		else
			set_text(69,27,"��ͨ��дַ")
		end

		temp = get_value(4,10)
		if temp == 0
		then
			set_text(4,13,"�� ʼ �� ��")
		else
			set_text(4,13,"ͣ ֹ �� ��")
		end

		temp = get_value(5,7)
		if temp == 0
		then
			set_text(5,16,"�������һ֡")
		else
			set_text(5,16,"�ָ��ϵ�״̬")
		end

		temp = get_value(9,5)
		if temp == 0
		then
			set_text(9,14,"�ֶ�дַ")
		else
			set_text(9,14,"�Զ�дַ")
		end
		
		temp = get_value(10,7)
		if temp == 0
		then
			set_text(10,18,"�������һ֡")
		else
			set_text(10,18,"�ָ��ϵ�״̬")
		end

		set_text(10,6,"1��")
		set_text(10,16,"3ɫ")

	 	temp = get_value(11,7)
		if temp == 0
		then
			set_text(11,21,"�������һ֡")
		else
			set_text(11,21,"�ָ��ϵ�״̬")
		end	

		temp = get_value(11,16)
		if temp == 0
		then
			set_text(11,23,"�ر�")
		else
			set_text(11,23,"����")
		end	

		temp = get_value(12,7)
		if temp == 0
		then
			set_text(12,21,"�������һ֡")
		else
			set_text(12,21,"�ָ��ϵ�״̬")
		end	

		set_text(12,24,"3ɫ")
		set_text(12,25,"������")
		set_text(12,19,"�޵�������")

		temp = get_value(15,16)
		if temp == 0
		then
			set_text(15,23,"�ر�")
		else
			set_text(15,23,"����")
		end	

		temp = get_value(15,7)
		if temp == 0
		then
			set_text(15,21,"�������һ֡")
		else
			set_text(15,21,"�ָ��ϵ�״̬")
		end	

		set_text(16,19,"������")
		set_text(16,24,"��/����+����")

		temp = get_value(16,5)
		if temp == 0
		then
			set_text(16,28,"�ر�")
		else
			set_text(16,28,"����")
		end	

		temp = get_value(17,9)
		if temp == 0
		then
			set_text(17,28,"�ر�")
		else
			set_text(17,28,"����")
		end	

		temp = get_value(17,10)
		if temp == 0
		then
			set_text(17,22,"��д��EEPROM")
		else
			set_text(17,22,"д��EEPROM")
		end	

		set_text(19,5,"ͨ��һ")
		set_text(19,15,"�� �� �� ��")

		temp = get_value(22,13)
		if temp == 0
		then
			set_text(22,14,"�������һ֡")
		else
			set_text(22,14,"�ָ��ϵ�״̬")
		end	

		temp = get_value(22,5)
		if temp == 0
		then
			set_text(22,28,"�ر�")
		else
			set_text(22,28,"����")
		end	

		--Hi512A6����
		temp = get_value(23,6)
		if temp == 0
		then
			set_text(23,21,"6ͨ��")
		else
			set_text(23,21,"4ͨ��")
		end	

		temp = get_value(23,18)
		if temp == 0
		then
			set_text(23,23,"����")
		else
			set_text(23,23,"����")
		end	

		temp = get_value(23,5)
		if temp == 0
		then
			set_text(23,28,"����")
		else
			set_text(23,28,"����")
		end	

		temp = get_value(23,17)
		if temp == 0
		then
			set_text(23,33,"�������һ֡")
		else
			set_text(23,33,"�ָ��ϵ�״̬")
		end	

		temp = get_value(23,19)
		if temp == 0
		then
			set_text(23,24,"����")
		else
			set_text(23,24,"����")
		end	
		
		temp = get_value(24,7)
		if temp == 0
		then
			set_text(24,21,"�������һ֡")
		else
			set_text(24,21,"�ָ��ϵ�״̬")
		end	
		
		temp = get_value(24,25)
		if temp == 0
		then
			set_text(24,28,"�ر�")
		else
			set_text(24,28,"����")
		end	
		
		set_text(24,19,"��")
		
		temp = get_value(26,4)
		if temp == 0
		then
			set_text(26,3,"�ϵ���")
		else
			set_text(26,3,"�ϵ粻��")
		end	

		temp = get_value(26,25)
		if temp == 0
		then
			set_text(26,7,"�������һ֡")
		else
			set_text(26,7,"Ϩ��")
		end		
		
		temp = get_value(45,12)
		if temp == 0
		then
			set_text(45,14,"�ر�")
		else
			set_text(45,14,"����")
		end	
		
		temp = get_value(45,18)
		if temp == 0
		then
			set_text(45,19,"����")
		else
			set_text(45,19,"�ر�")
		end	
		
		temp = get_value(45,7)
		if temp == 0
		then
			set_text(45,8,"�ر�")
		else
			set_text(45,8,"����")
		end	
		
		temp = get_value(46,8)
		if temp == 0
		then
			set_text(46,28,"����")
		else
			set_text(46,28,"�ر�")
		end	
		
		temp = get_value(46,7)
		if temp == 0
		then
			set_text(46,21,"�ָ��ϵ�����")
		else
			set_text(46,21,"�������һ֡")
		end	
		
		temp = get_value(54,8)
		if temp == 0
		then
			set_text(54,28,"��ַ�߼��ģʽ")
		else
			set_text(54,28,"�Զ���Ҷ�")
		end	
		
		temp = get_value(54,7)
		if temp == 0
		then
			set_text(54,21,"�ָ��ϵ�����״̬")
		else
			set_text(54,21,"�������һ֡")
		end	
		
		temp = get_value(56,8)
		if temp == 0
		then
			set_text(56,28,"��ַ�߼��ģʽ")
		else
			set_text(56,28,"�Զ���Ҷ�")
		end	
		
		
		temp = get_value(56,7)
		if temp == 0
		then
			set_text(56,21,"�ָ��ϵ�����״̬")
		else
			set_text(56,21,"�������һ֡")
		end	
		
		
		if get_value(53,7)==0	then set_text(53,28,"����")
		elseif get_value(53,7)==1 then set_text(53,28,"�ر�")	end
		
		if get_value(53,12)==0	then set_text(53,16,"�ر�")
		elseif get_value(53,12)==1 then set_text(53,16,"����")	end
		
		if get_value(55,7)==0	then set_text(55,28,"����")
		elseif get_value(55,7)==1 then set_text(55,28,"�ر�")	end
		
		if get_value(55,12)==0	then set_text(55,16,"�ر�")
		elseif get_value(55,12)==1 then set_text(55,16,"����")	end
		
		if xh==0	
		then
			set_text(53,6,"������")--�ֶ�
			set_text(53,45,"������")--�˿�ˢ����
			set_text(53,16,"������")--�Ҷ�ƽ��
			set_text(53,19,"�����ȼ�  1~16 :")
			
			set_text(55,6,"������")--�ֶ�
			set_text(55,45,"������")--�˿�ˢ����
			set_text(55,16,"������")--�Ҷ�ƽ��
			set_text(55,19,"�����ȼ�  1~16 :")
			
		elseif xh==1
		then
			set_text(53,6,"������")--�ֶ�
			set_text(53,45,"������")--�˿�ˢ����
			set_text(53,16,"������")--�Ҷ�ƽ��
			set_text(53,19,"�����ȼ�  ������ :")
			
			set_text(55,6,"������")--�ֶ�
			set_text(55,45,"������")--�˿�ˢ����
			set_text(55,16,"������")--�Ҷ�ƽ��
			set_text(55,19,"�����ȼ�  ������ :")
			
			
		elseif xh==2
		then
			set_text(53,6,"������")--�ֶ�
			set_text(53,45,"������")--�˿�ˢ����
			set_text(53,16,"������")--�Ҷ�ƽ��
			set_text(53,19,"�����ȼ�  ������ :")
			
			set_text(55,6,"������")--�ֶ�
			set_text(55,45,"������")--�˿�ˢ����
			set_text(55,16,"������")--�Ҷ�ƽ��
			set_text(55,19,"�����ȼ�  ������ :")
			
			
		elseif xh==3
		then
			if get_text(53,47) == "UCS7604"
			then
				set_value(53,6,3)----�ֶοؼ���ֵ
				set_text(53,45,"������")--�˿�ˢ����
				set_text(53,16,"������")--�Ҷ�ƽ��
				set_text(53,19,"�����ȼ�  1~16 :")
			elseif get_text(53,47) == "UCS7804"
			then
				set_value(53,6,3)----�ֶοؼ���ֵ
				set_text(53,45,"16KHZ")--�˿�ˢ����
				set_text(53,16,"�ر�")
				set_text(53,19,"�����ȼ�  1~64 :")
			end
			
			if get_text(55,47) == "UCS7604"
			then
				set_value(55,6,3)----�ֶοؼ���ֵ
				set_text(55,45,"������")--�˿�ˢ����
				set_text(55,16,"������")--�Ҷ�ƽ��
				set_text(55,19,"�����ȼ�  1~16 :")
			elseif get_text(55,47) == "UCS7804"
			then
				set_value(55,6,3)----�ֶοؼ���ֵ
				set_text(55,45,"16KHZ")--�˿�ˢ����
				set_text(55,16,"�ر�")
				set_text(55,19,"�����ȼ�  1~64 :")
			end
		end
		
		if get_value(62,7) == 1 then set_text(62,16,"��") else set_text(62,16,"�ر�") end
		
		if get_value(63,14) == 0
		then 
			set_text(63,7,"RGBW�ϵ�����")
		elseif get_value(63,14) == 1  
		then
			set_text(63,7,"����Ч��")
		elseif get_value(63,14) == 2  
		then
			set_text(63,7,"���")
		elseif get_value(63,14) == 3 
		then
			set_text(63,7,"�������һ֡")
		end
		
		if get_value(63,15) == 0
		then 
			set_text(63,9,"5֡/��")
		elseif get_value(63,15) == 1  
		then
			set_text(63,9,"10֡/��")
		elseif get_value(63,15) == 2  
		then
			set_text(63,9,"20֡/��")
		elseif get_value(63,15) == 3 
		then
			set_text(63,9,"40֡/��")
		end
		
		if get_value(63,26) == 0
		then 
			set_text(63,10,"16��")
		elseif get_value(63,26) == 1  
		then
			set_text(63,10,"32��")
		elseif get_value(63,26) == 2  
		then
			set_text(63,10,"64��")
		elseif get_value(63,26) == 3 
		then
			set_text(63,10,"128��")
		end
		
		if get_value(63,37) == 0
		then 
			set_text(63,38,"���õ���")
		elseif get_value(63,37) == 1  
		then
			set_text(63,38,"���õ���")
		end
		
		if get_value(67,39) == 0
		then 
			set_text(67,6,"1��")
		elseif get_value(67,39) == 1  
		then
			set_text(67,6,"2��")
		elseif get_value(67,39) == 2  
		then
			set_text(67,6,"3��")
		elseif get_value(67,39) == 3 
		then
			set_text(67,6,"4��")
		end
		
		if get_value(67,7) == 0
		then 
			set_text(67,16,"������")
		elseif get_value(67,7) == 1  
		then
			set_text(67,16,"������")
		end
		
		if get_value(3,19) == 1
		then
			set_text(3,26,"��ʼͨ����")
		elseif get_value(3,20) == 1
		then
			set_text(3,26,"��ʼ������")
		end
		
	elseif lang == 1 --Ӣ��
	then
		set_language(1)
		------------------------

		rtc_n,rtc_y,rtc_r,rtc_s,rtc_f,rtc_m,rtc_w = get_date_time()
		
		if rtc_w == 1
		then	
			set_text(0,24,"Monday")
			set_text(37,10,"Monday")
		elseif rtc_w == 2
		then	
			set_text(0,24,"Tuesday")
			set_text(37,10,"Tuesday")
		elseif rtc_w == 3
		then	
			set_text(0,24,"Wednesday")
			set_text(37,10,"Wednesday")
		elseif rtc_w == 4
		then	
			set_text(0,24,"Thursday")
			set_text(37,10,"Thursday")
		elseif rtc_w == 5
		then	
			set_text(0,24,"Friday")
			set_text(37,10,"Friday")
		elseif rtc_w == 6
		then	
			set_text(0,24,"Saturday")
			set_text(37,10,"Saturday")
		elseif rtc_w == 0
		then	
			set_text(0,24,"Sunday")
			set_text(37,10,"Sunday")
		end
		

		temp = get_value(0,12)
		if temp == 0
		then
			set_text(0,17,"Default")
		else 
			set_text(0,17,"SD")
		end

 		temp = get_value(0,14)
		if temp == 0
		then
			set_text(0,19,"3-channel")
		else
			set_text(0,19,"4-channel")
		end	

		temp = get_value(0,21)
		if temp == 0
		then
			set_text(0,22,"No Cycle")
		else
			set_text(0,22,"Cycle")
		end	

		set_text(1,5,"Update")

 		temp = get_value(3,12)
		if temp == 0
		then
			set_text(3,2,"Write Add")
		else
			set_text(3,2,"Writing")
		end	
		
		temp = get_value(69,12)
		if temp == 0
		then
			set_text(69,2,"Write Add")
		else
			set_text(69,2,"Writing")
		end	

		if get_text(69,27)=="��ͨ��дַ"
		then
			set_text(69,27,"Self channel")
		elseif get_text(69,27)=="����дַ"
		then
			set_text(69,27,"Parallel write")
		elseif get_text(69,27)=="����дַ"
		then
			set_text(69,27,"Conventional")
		else
			set_text(69,27,"Self channel")
		end

 		temp = get_value(4,10)
		if temp == 0
		then
			set_text(4,13,"Start Test")
		else
			set_text(4,13,"Stop Test")
		end
	
		temp = get_value(5,7)
		if temp == 0
		then
			set_text(5,16,"Save last frame")
		else
			set_text(5,16,"Restore light status")
		end

 		temp = get_value(9,5)
		if temp == 0
		then
			set_text(9,14,"Manual Write")
		else
			set_text(9,14,"Autol Write")
		end	

 		temp = get_value(10,7)
		if temp == 0
		then
			set_text(10,18,"Save last frame")
		else
			set_text(10,18,"Restore light status")
		end	

		set_text(10,6,"1 times")
		set_text(10,16,"3 color")

 		temp = get_value(11,7)
		if temp == 0
		then
			set_text(11,21,"Save last frame")
		else
			set_text(11,21,"Restore light status")
		end		

 		temp = get_value(11,16)
		if temp == 0
		then
			set_text(11,23,"Close")
		else
			set_text(11,23,"Open")
		end		

 		temp = get_value(12,7)
		if temp == 0
		then
			set_text(12,21,"Save last frame")
		else
			set_text(12,21,"Restore light status")
		end			

		set_text(12,24,"3 color")
		set_text(12,25,"Return zero")
		set_text(12,19,"No")

 		temp = get_value(15,16)
		if temp == 0
		then
			set_text(15,23,"Close")
		else
			set_text(15,23,"Open")
		end		

 		temp = get_value(15,7)
		if temp == 0
		then
			set_text(15,21,"Save last frame")
		else
			set_text(15,21,"Restore light status")
		end			

		set_text(16,19,"No")
		set_text(16,24,"Loop play")

		temp = get_value(16,5)
		if temp == 0
		then
			set_text(16,28,"Close")
		else
			set_text(16,28,"Open")
		end	

		temp = get_value(17,9)
		if temp == 0
		then
			set_text(17,28,"Close")
		else
			set_text(17,28,"Open")
		end	

		temp = get_value(17,10)
		if temp == 0
		then
			set_text(17,22,"No save")
		else
			set_text(17,22,"Save to EEPROM")
		end	

		set_text(19,5,"CH1")
		set_text(19,15,"Auto Count")

		temp = get_value(22,13)
		if temp == 0
		then
			set_text(22,14,"Save last frame")
		else
			set_text(22,14,"Restore light status")
		end		
	
 		temp = get_value(22,5)
		if temp == 0
		then
			set_text(22,28,"Close")
		else
			set_text(22,28,"Open")
		end		

 		--Hi512A6����
		temp = get_value(23,6)
		if temp == 0
		then
			set_text(23,21,"6channel")
		else
			set_text(23,21,"4channel")
		end	

		temp = get_value(23,18)
		if temp == 0
		then
			set_text(23,23,"Close")
		else
			set_text(23,23,"Open")
		end	

		temp = get_value(23,5)
		if temp == 0
		then
			set_text(23,28,"Close")
		else
			set_text(23,28,"Open")
		end	

		temp = get_value(23,17)
		if temp == 0
		then
			set_text(23,33,"Save last frame")
		else
			set_text(23,33,"Restore light status")
		end	

		temp = get_value(23,19)
		if temp == 0
		then
			set_text(23,24,"Close")
		else
			set_text(23,24,"Open")
		end	

		temp = get_value(24,25)
		if temp == 0
		then
			set_text(24,28,"Close")
		else
			set_text(24,28,"Open")
		end	

		temp = get_value(24,7)
		if temp == 0
		then
			set_text(24,21,"Save last frame")
		else
			set_text(24,21,"Restore light status")
		end

		set_text(24,19,"No")

 		temp = get_value(26,4)
		if temp == 0
		then
			set_text(26,3,"Turn on")
		else
			set_text(26,3,"Turn off")
		end		

 		temp = get_value(26,25)
		if temp == 0
		then
			set_text(26,7,"Save last frame")
		else
			set_text(26,7,"Turn off")
		end	
		
		temp = get_value(45,12)
		if temp == 0
		then
			set_text(45,14,"Close")
		else
			set_text(45,14,"Open")
		end	
		
		temp = get_value(45,18)
		if temp == 0
		then
			set_text(45,19,"Open")
		else
			set_text(45,19,"Close")
		end	
		
		temp = get_value(45,7)
		if temp == 0
		then
			set_text(45,8,"Close")
		else
			set_text(45,8,"Open")
		end	
		
		temp = get_value(46,8)
		if temp == 0
		then
			set_text(46,28,"Open")
		else
			set_text(46,28,"Close")
		end	
		
		temp = get_value(46,7)
		if temp == 0
		then
			set_text(46,21,"Restore light status")
		else
			set_text(46,21,"Save last frame")
		end
		
		temp = get_value(54,8)
		if temp == 0
		then
			set_text(54,28,"Address line detection")
		else
			set_text(54,28,"Custom gray scale")
		end	
		
		temp = get_value(54,7)
		if temp == 0
		then
			set_text(54,21,"Restore light status")
		else
			set_text(54,21,"save last frame")
		end	
		
		temp = get_value(56,8)
		if temp == 0
		then
			set_text(56,28,"Address line detection")
		else
			set_text(56,28,"Custom gray scale")
		end	
		
		temp = get_value(56,7)
		if temp == 0
		then
			set_text(56,21,"Restore light status")
		else
			set_text(56,21,"save last frame")
		end	
		
		
		if get_value(53,7)==0	then set_text(53,28," Open")
		elseif get_value(53,7)==1 then set_text(53,28," Close")		end
		
		if get_value(53,12)==0	then set_text(53,16," Close")
		elseif get_value(53,12)==1 then set_text(53,16," Open")		end
		
		
		if get_value(55,7)==0	then set_text(55,28," Open")
		elseif get_value(55,7)==1 then set_text(55,28," Close")		end
		
		if get_value(55,12)==0	then set_text(55,16," Close")
		elseif get_value(55,12)==1 then set_text(55,16," Open")		end
		
		
		
		if xh==0	
		then
			set_text(53,6,"  invalid")--�ֶ�
			set_text(53,45,"  invalid")--�˿�ˢ����
			set_text(53,16,"  invalid")--�Ҷ�ƽ��
			set_text(53,19,"Current rating   1~16 :")
			
			set_text(55,6,"  invalid")--�ֶ�
			set_text(55,45,"  invalid")--�˿�ˢ����
			set_text(55,16,"  invalid")--�Ҷ�ƽ��
			set_text(55,19,"Current rating   1~16 :")
			
		elseif xh==1
		then
			set_text(53,6,"  invalid")--�ֶ�
			set_text(53,45,"  invalid")--�˿�ˢ����
			set_text(53,16,"  invalid")--�Ҷ�ƽ��
			set_text(53,19,"Current rating   invalid :")
			
			set_text(55,6,"  invalid")--�ֶ�
			set_text(55,45,"  invalid")--�˿�ˢ����
			set_text(55,16,"  invalid")--�Ҷ�ƽ��
			set_text(55,19,"Current rating   invalid :")
			
			
			
		elseif xh==2
		then
			set_text(53,6,"  invalid")--�ֶ�
			set_text(53,45,"  invalid")--�˿�ˢ����
			set_text(53,16,"  invalid")--�Ҷ�ƽ��
			set_text(53,19,"Current rating   invalid :")
			
			set_text(55,6,"  invalid")--�ֶ�
			set_text(55,45,"  invalid")--�˿�ˢ����
			set_text(55,16,"  invalid")--�Ҷ�ƽ��
			set_text(55,19,"Current rating   invalid :")
			
			
		elseif xh==3
		then
			if get_text(53,47) == "UCS7604"
			then
				set_value(53,6,3)----�ֶοؼ���ֵ
				set_text(53,45,"  invalid")--�˿�ˢ����
				set_text(53,16,"  invalid")--�Ҷ�ƽ��
				set_text(53,19,"Current rating   1~16 :")
			elseif get_text(53,47) == "UCS7804"
			then
				set_value(53,6,3)----�ֶοؼ���ֵ
				set_text(53,45,"16KHZ")--�˿�ˢ����
				set_text(53,16,"  close")--�Ҷ�ƽ��
				set_text(53,19,"Current rating   1~64 :")
			end
			
			if get_text(55,47) == "UCS7604"
			then
				set_value(55,6,3)----�ֶοؼ���ֵ
				set_text(55,45,"  invalid")--�˿�ˢ����
				set_text(55,16,"  invalid")--�Ҷ�ƽ��
				set_text(55,19,"Current rating   1~16 :")
			elseif get_text(55,47) == "UCS7804"
			then
				set_value(55,6,3)----�ֶοؼ���ֵ
				set_text(55,45,"16KHZ")--�˿�ˢ����
				set_text(55,16,"  close")--�Ҷ�ƽ��
				set_text(55,19,"Current rating   1~64 :")
			end
		end
		
		if get_value(62,7) == 1 then set_text(62,16,"Open") else set_text(62,16,"Close") end
		
		if get_value(63,14) == 0
		then 
			set_text(63,7,"Restore light status")
		elseif get_value(63,14) == 1  
		then
			set_text(63,7,"Built in effects")
		elseif get_value(63,14) == 2  
		then
			set_text(63,7,"Lights out")
		elseif get_value(63,14) == 3 
		then
			set_text(63,7,"Save last frame")
		end
		
		if get_value(63,15) == 0
		then 
			set_text(63,9,"5Frames/sec")
		elseif get_value(63,15) == 1  
		then
			set_text(63,9,"10Frames/sec")
		elseif get_value(63,15) == 2  
		then
			set_text(63,9,"20Frames/sec")
		elseif get_value(63,15) == 3 
		then
			set_text(63,9,"40Frames/sec")
		end
		
		if get_value(63,26) == 0
		then 
			set_text(63,10,"16points")
		elseif get_value(63,26) == 1  
		then
			set_text(63,10,"32points")
		elseif get_value(63,26) == 2  
		then
			set_text(63,10,"64points")
		elseif get_value(63,26) == 3 
		then
			set_text(63,10,"128points")
		end
		
		if get_value(63,37) == 0
		then 
			set_text(63,38,"Internal current")
		elseif get_value(63,37) == 1  
		then
			set_text(63,38,"External current")
		end
		
		if get_value(67,39) == 0
		then 
			set_text(67,6,"Level 1")
		elseif get_value(67,39) == 1  
		then
			set_text(67,6,"Level 2")
		elseif get_value(67,39) == 2  
		then
			set_text(67,6,"Level 3")
		elseif get_value(67,39) == 3 
		then
			set_text(67,6,"Level 4")
		end
		
		if get_value(67,7) == 0
		then 
			set_text(67,16,"Positive polarity")
		elseif get_value(67,7) == 1  
		then
			set_text(67,16,"Reverse polarity")
		end

		if get_value(3,19) == 1
		then
			set_text(3,26,"Start Ch:")	
		elseif get_value(3,20) == 1
		then
			set_text(3,26,"Start Num:")	
		end
		
	end
end

-- ϵͳ����: ��ʼ������
function on_init()
	start_timer(0,time1,1,1)--������ʱ��0������15���޷�Ӧ��������	
	start_timer(1,time2,1,0)--������ʱ��10���Ӳ�ѯһ�ο�������״̬ �ظ�����
	start_timer(2,time3,1,0)--������ʱ��500���룬��ѯһ���Ƿ���Ҫ��ʼ�Զ����Ե�ַ	
	start_timer(3,time4,1,0)--������ʱ��500���룬���ڲ���ģʽʱ���� ���ַ����
	stop_timer(4)--�رն�ʱ��5���ȴ�ʹ��ʱ������
	uart_set_timeout(1000,200) --���ô��ڽ��ճ�ʱ��

	auto_run = 0
	run_num = 0	
	buchang_ok = 0	

	first_run = 0 --�ո��ϵ��ȡ��������״̬

	first_run_1 = 0	--�ո��ϵ���ʱ500ms�л���������1
	
	first_run_2 = 0

	SD_Exist = 0 --�ж�SD���Ƿ����	Ĭ�ϲ�����

	upgrade = 0

	DMX_add_param = 0

	Touch_over = 0x55--��ʼ����δ������������
	secret_1 = 0x55--��ʼ����δ�򿪹������ ������ʾ�����
	secret_2 = 0x00--��ʼ����δ�򿪹������ ������ͨ�������������
	ztd_flag = 0x00--��ͨ�����ֱ��
	DMX_Status_page = 0x00--д���ַ�Ͳ��� �ƾ�״̬

	buc_time_G = 0 --UCS512-G
	buc_time_count_G = 0
	
	buc_time_H = 0 --UCS512-H
	buc_time_count_H = 0

	set_value(1,1,0)
	set_value(1,2,0)
	set_text(1,3,"0%")

	set_value(0,12,0)--SD��������	
	set_value(0,14,0)--3ͨ��	
 	set_visiable(0,14,1)--��ʾ3/4ͨ����ť		

	set_text(20,1,ver)--��ʾ�汾��
	
	set_value(3,19,1)--Ĭ�ϰ���ͨ��д��
	set_value(3,20,0)
	
	language_sel(get_language())--�������ԣ���ʾ��ǰ����	

	if get_language() == 0
	then
		set_value(37,18,0)
	elseif get_language() == 1
	then
		set_value(37,18,1)
	end

	Is_charge = 0
	Is_charge_tmp = 0
	delay_show = 0
	delay_count = 0

	ic_sel_test = 10--Ĭ��DMX

	test_flash = 0

	--���ص�ص����İٷֱȺ�AD��ʾ
	--[[
	set_visiable(0,5,0)--�ٷֱ�
	set_visiable(0,3,0)--�ٷֱ�
	set_visiable(37,3,0)--�ٷֱ�
	set_visiable(37,8,0)--�ٷֱ�
	--]]
	set_visiable(0,23,0)--AD��ʾ
	set_visiable(37,23,0)--AD��ʾ	
	
	Save_screen = 0
	Save_show = 0

	--------------
	--��ȡflash�д�ŵ�����
	data = read_flash(0x00,20)
	if data[0] == 0x33 and data[1] == 0x55 --�����������  ��̬
	then
		Save_screen = 0x55--��̬����ı��	

		if data[17] == 0--��׼����
		then
			Save_show = 0
		elseif data[17] == 0x55--ģ������
		then
			Save_show = 0x55
		else
			Save_show = 0--��׼����
		end
	elseif data[0] == 0xaa and data[1] == 0xcc --�����������  ��̬
	then
		Save_screen = 0x33--��̬����ı��
		
		Save_show = 0--��׼����
	else
		Save_screen = 0--Ĭ���Ƕ�̬����
		Save_show = 0--Ĭ���� ��׼����
		
		set_value(44,22,0)
		
		set_visiable(44,15,0)--����
		set_value(44,21,0)--����
		
		set_visiable(44,16,1)--��ʾ
		set_visiable(44,17,1)--��ʾ
		set_visiable(44,19,1)--��ʾ
		
		set_visiable(44,31,1)--��ʾ
		set_visiable(44,32,1)--��ʾ
		set_visiable(44,33,1)--��ʾ
		set_visiable(44,34,1)--��ʾ
		set_visiable(44,35,1)--��ʾ
		set_visiable(44,36,1)--��ʾ
	end
	
		if get_language() == 0--����
	then
		set_text(53,6,"������")--�ֶ�
		set_text(53,45,"������")--�˿�ˢ����
		set_text(53,16,"������")--�Ҷ�ƽ��
		set_text(53,19,"�����ȼ�  1~16 :")
		
		set_text(55,6,"������")--�ֶ�
		set_text(55,45,"������")--�˿�ˢ����
		set_text(55,16,"������")--�Ҷ�ƽ��
		set_text(55,19,"�����ȼ�  ������ :")
	elseif get_language() == 1--Ӣ��
	then
		set_text(53,6,"  invalid")--�ֶ�
		set_text(53,45,"  invalid")--�˿�ˢ����
		set_text(53,16,"  invalid")--�Ҷ�ƽ��
		set_text(53,19,"Current rating   1~16 :")
		
		set_text(55,6,"  invalid")--�ֶ�
		set_text(55,45,"  invalid")--�˿�ˢ����
		set_text(55,16,"  invalid")--�Ҷ�ƽ��
		set_text(55,19,"Current rating   invalid :")
	end	
	
	--------------------------------UCS512KHĬ��3ɫ
	set_visiable(53,2,0)
	set_visiable(53,40,0)
	set_visiable(53,12,0)
	set_visiable(53,26,1)
	
	set_visiable(55,2,0)
	set_visiable(55,40,0)
	set_visiable(55,12,0)
	set_visiable(55,26,0)
	
	local num = get_value(53,29)
	for i = 1,7 do
		set_visiable(54,i+71,0)
		if i <= num
		then
			set_visiable(53,i+51,1)--KH�����ȼ�
			set_visiable(55,i+51,1)--KL�����ȼ�
			
			set_visiable(54,i+60,1)--KH�ϵ�Ҷ�
			set_visiable(56,i+60,1)--KL�ϵ�Ҷ�
			
			set_visiable(54,i+9,1)--KHͨ��ת��˳���ı�
			set_visiable(54,i+35,1)--KHͨ��ת��˳�򰴼�
			
			set_visiable(54,i+52,1)--KHͨ��ת������
		else
			set_visiable(53,i+51,0)--KH�����ȼ�
			set_visiable(55,i+51,0)--KL�����ȼ�
			
			set_visiable(54,i+60,0)--KH�ϵ�Ҷ�
			set_visiable(56,i+60,0)--KL�ϵ�Ҷ�
			
			set_visiable(54,i+9,0)--KHͨ��ת��˳���ı�
			set_visiable(54,i+35,0)--KHͨ��ת��˳�򰴼�
			
			set_visiable(54,i+52,0)--KHͨ��ת������
		end
	end
	
	set_visiable(0,26,0)-- 8525_2
	
	
	set_visiable(62,39,0)-- 8525_2
	set_visiable(62,40,0)
	set_visiable(62,43,0)
	set_visiable(62,44,0)-- 8525_2
	set_visiable(62,45,0)
	set_visiable(62,46,0)
	set_visiable(62,47,0)-- 8525_2
	set_visiable(62,48,0)
	set_visiable(62,49,0)
	
	set_visiable(63,14,0)-- 8525_2
	set_visiable(63,15,0)
	set_visiable(63,26,0)
	
	set_visiable(66,14,0)
	
	set_visiable(67,39,0)-- 8525_2
	set_visiable(67,40,0)
	set_visiable(67,43,0)
	set_visiable(67,44,0)-- 8525_2
	set_visiable(67,45,0)
	
	set_visiable(70,46,0)
	set_visiable(70,47,0)
	set_visiable(70,48,0)
	set_visiable(70,49,0)
	set_visiable(71,50,0)
	
	set_visiable(0,1,0)--����ʱ����ʾ
	set_visiable(0,24,0)--����������ʾ
	
	set_visiable(37,1,0)--����ʱ����ʾ
	set_visiable(37,10,0)--����������ʾ
	
	local num = get_value(73,19)
	for i = 1,7 do
		set_visiable(73,i+44,0)
		
		if i <= num
		then
			set_visiable(73,i+9,1)
			set_visiable(73,i+35,1)
			set_visiable(73,i+52,1)
		else
			set_visiable(73,i+9,0)
			set_visiable(73,i+35,0)
			set_visiable(73,i+52,0)
		end
		
		if num == 0
		then
			set_value(73,i+44,0)
		end
	end
	
	set_visiable(74,33,0)
	set_visiable(74,36,0)
	
	set_visiable(75,15,0)
	set_visiable(75,16,0)
	set_visiable(75,28,0)
	set_visiable(75,31,0)
	
	set_visiable(75,32,0)
	set_visiable(75,42,0)
	set_visiable(75,43,0)
	set_visiable(75,44,0)
	
end

--ϵͳ���� ��ʱ����ʱ�ص�����
function on_timer(timer_id)  

	--��ʱ��������ʱ����������1
	if timer_id==0
	then	
		set_backlight(30)--����ϵͳ�����ȣ������͹���
		
		if current_screen == 27--����Ǵ�����Ϣ���棬��ִ����ת�����Ž���Ĳ���
		then
		else
			if Save_screen ~= 0x55 and Touch_over == 0x55--δ������������
			then
				if get_value(0,12) == 0--����Ч��
				then
					Send_cmd(0xc1,0,0,0,0,0,0,0,0)	
				else
					Send_cmd(0xa1,0,0,0,0,0,0,0,0)	
				end
				change_screen(0)
			end
		end
	end
	
	--��ѯ������״̬
	if timer_id==1 --δ�յ�����������ʱ��100���� �յ���������10000����
	then
		Send_cmd(0xe1,0,0,0,0,0,0,0,0)		
	end

	--��ʱ���Ͳ��Ե�ַ����
	if timer_id==2 --500����
	then
		if delay_show == 0x55--���ڳ���벻����л�ʱ����ʱ��ʾ��ذٷֱȵ�����
		then
			delay_count = delay_count + 1
			if delay_count > 120 -- 60�� 1���Ӻ󣬲ſ�ʼ��ʾ�ٷֱ�
			then
				delay_count = 0
				delay_show = 0
			end
		end
	
		--�����ǰ���ڳ��״̬��Ҫ���ŵ�����
 		if Is_charge == 0x55
		then
			if bat <2050
			then
				charge_frame_low = 0
			elseif 	bat >=2050 and bat <2230
			then
				charge_frame_low = 1	
			elseif bat >=2230 and bat <2410
			then
				charge_frame_low = 2
			elseif bat >=2410 and bat <2560
			then
				charge_frame_low = 3
			elseif bat >=2560
			then
				charge_frame_low = 4
			end		

			charge_frame = charge_frame +1
			if charge_frame > 4
			then
				charge_frame = charge_frame_low
			end

			set_value(0,3,charge_frame)
			set_value(37,3,charge_frame)
		end	

		if upgrade == 0--�����¹̼�ʱ���Ų�������
		then
			--�����ǿ���ʱ�������������л���������1�Ĵ���
			if first_run_1 < 5
			then
				first_run_1 = first_run_1 +1
			end
	
			if first_run_1 == 3
			then
				first_run_1 = 0x55
				
				if Save_screen == 0x55 --˵������� ��̬����Ľ���  
				then				
					set_value(44,2,data[3])--ͨ����
					
					set_value(44,25,1)--����Ǿ�̬����
					
					rr = data[5]
					gg = data[6]
					bb = data[7]
					ww = data[8]
					nw = data[9]
					aw = data[10]
	
					if Save_show == 0x00--��׼����  ��Ҫ��Щ��Ϣ
					then					
						set_value(44,22,0)

						set_visiable(44,15,0)--����
						set_value(44,21,0)--����
						
						set_visiable(44,16,1)--��ʾ
						set_visiable(44,17,1)--��ʾ
						set_visiable(44,19,1)--��ʾ	

						set_visiable(44,31,1)--��ʾ
						set_visiable(44,32,1)--��ʾ
						set_visiable(44,33,1)--��ʾ
						set_visiable(44,34,1)--��ʾ
						set_visiable(44,35,1)--��ʾ
						set_visiable(44,36,1)--��ʾ
					
						set_value(44,16,rr)
						set_value(44,17,gg)						
						set_value(44,19,bb)	
					elseif Save_show == 0x55--ģ������ ��Ҫ��Щ��Ϣ
					then					
						set_value(44,22,1)
						
						set_visiable(44,15,1)--��ʾ
						set_value(44,21,1)--��ʾ
						
						set_visiable(44,16,0)--����
						set_visiable(44,17,0)--����
						set_visiable(44,19,0)--����
						
						set_visiable(44,31,0)--����
						set_visiable(44,32,0)--����
						set_visiable(44,33,0)--����
						set_visiable(44,34,0)--����
						set_visiable(44,35,0)--����
						set_visiable(44,36,0)--����
					
						draw_select_x = data[11]*256 + data[12]--X����
						draw_select_y = data[13]*256 + data[14]--Y����
						
						select_rgb = data[15]*256 + data[16]--ѡ�е���ɫֵ 	
					end				
	
					set_value(44,5,ww)				
					set_value(44,7,nw)					
					set_value(44,9,aw)
	
					change_screen(44)
				else
					change_screen(37)
				end

				show_week()	
			end
		end
		
		if auto_run==0x55--�Զ����ַ����
		then
			send_cmd_xb[0] = 0xc3
	
			send_cmd_xb[1] = 0xff --UID
		 	send_cmd_xb[2] = 0xff	
			send_cmd_xb[3] = 0xff	
			send_cmd_xb[4] = 0xff	
			
			send_cmd_xb[5] = 0xc8 --������
	
			--���ͨ��
	 		jiange_ch = get_value(4,3)
			send_cmd_xb[6] = jiange_ch 
	
			--��ǰ�ܵ��ĸ�����
			run_num=get_value(4,7)
	 	    run_num=run_num+1	
			if  run_num*jiange_ch > 3072
			then
				run_num = 0
			end		
			set_value(4,7,run_num)
			
	 		send_cmd_xb[7] = math.modf(run_num/256)--����
			send_cmd_xb[8] = math.modf(run_num%256)
			
			if get_value(4,21) == 0
			then
				send_cmd_xb[9] = 0x00--Ĭ�ϲ����ò��Թ켣
			else
				send_cmd_xb[9] = 0x55--���ò��Թ켣
			end
			
			--ָ��������
			send_cmd_xb[10] = 0xff
			send_cmd_xb[11] = 0xff		
			
			--ָ���˿�
			send_cmd_xb[12] = 0xff	
	
			if (get_text(0,4) == "DMX 500K") or (get_text(3,8) == "Hi512A0") or (get_text(3,8) == "Hi512A0_Self")
			then
				send_cmd_xb[13] = 0x55
			else
				send_cmd_xb[13] = 0x00	
			end
			
			for i=14,18 do
				send_cmd_xb[i] = 0x00
			end
			
			local check_sum = 0	
			for i=1,17 do--��test_addr[1]�ӵ�test_addr[17]
				check_sum = check_sum  + send_cmd_xb[i]
			end
		
			check_sum = math.modf(check_sum%256)	
			check_sum = Xor(check_sum,0x39)
		
			send_cmd_xb[18]	= check_sum
			send_cmd_xb[19] = 0xca	
		
			uart_send_data(send_cmd_xb) --��������
		end
		
		if auto_run_tt==0x55--�Զ���������
		then
			ch = get_value(19,4)--ͨ����
			brightness = get_value(19,8)--��������	

			Test_chip_sel()
		
			run_num_tt=get_value(19,19)
			run_num_tt=run_num_tt+1	
			if  run_num_tt*ch > 3072
			then
				run_num_tt = 0
			end		
			set_value(19,19,run_num_tt)

			if get_value(19,21) == 0
			then
				sd_guiji = 0x00--Ĭ�ϲ���������켣
			else
				sd_guiji = 0x55--��������켣
			end
			
			ss = get_text(19,5)--ģʽѡ��
		if get_language() == 0
		then
			if ss == "ͨ��һ"
			then
				mode = 0
			elseif ss == "ͨ����"
			then
				mode = 1
			elseif ss == "ͨ����"
			then
				mode = 2
			elseif ss == "ͨ����"
			then
				mode = 3
			elseif ss == "ͨ����"
			then
				mode = 4
			elseif ss == "ͨ����"
			then
				mode = 5
			elseif ss == "ȫ��"
			then
				mode = 6
			end
		elseif get_language() == 1
		then
			if ss == "CH1"
			then
				mode = 0
			elseif ss == "CH2"
			then
				mode = 1
			elseif ss == "CH3"
			then
				mode = 2
			elseif ss == "CH4"
			then
				mode = 3
			elseif ss == "CH5"
			then
				mode = 4
			elseif ss == "CH6"
			then
				mode = 5
			elseif ss == "All bright"
			then
				mode = 6
			end
	    end

			Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),sd_guiji,mode)	
		end
	end

	if timer_id==3 --500���� �������� ����
	then
		if buchang_ok==0x55 and auto_run == 0
		then
			send_cmd_xb[0] = 0xc3
	
			send_cmd_xb[1] = 0xff --UID
		 	send_cmd_xb[2] = 0xff	
			send_cmd_xb[3] = 0xff	
			send_cmd_xb[4] = 0xff	
			
			send_cmd_xb[5] = 0xc8 --������
	
			--���ͨ��
	 		jiange_ch = get_value(4,3)
			send_cmd_xb[6] = jiange_ch 
	
			--��ǰ�ܵ��ĸ�����
	 		send_cmd_xb[7] = math.modf(run_num/256)--����
			send_cmd_xb[8] = math.modf(run_num%256)
			
			if get_value(4,21) == 0
			then
				send_cmd_xb[9] = 0x00--Ĭ�ϲ����ò��Թ켣
			else
				send_cmd_xb[9] = 0x55--���ò��Թ켣
			end
			
			--ָ��������
			send_cmd_xb[10] = 0xff
			send_cmd_xb[11] = 0xff		
			
			--ָ���˿�
			send_cmd_xb[12] = 0xff	
	
			if (get_text(0,4) == "DMX 500K") or (get_text(3,8) == "Hi512A0") or (get_text(3,8) == "Hi512A0_Self")
			then
				send_cmd_xb[13] = 0x55
			else
				send_cmd_xb[13] = 0x00	
			end
			
			for i=14,18 do
				send_cmd_xb[i] = 0x00
			end
			
			local check_sum = 0	
			for i=1,17 do--��test_addr[1]�ӵ�test_addr[17]
				check_sum = check_sum  + send_cmd_xb[i]
			end
		
			check_sum = math.modf(check_sum%256)	
			check_sum = Xor(check_sum,0x39)
		
			send_cmd_xb[18]	= check_sum
			send_cmd_xb[19] = 0xca	
		
			uart_send_data(send_cmd_xb) --��������
		end
	end	
	
	if timer_id==4 -- д���ַ�Ͳ������ƾߵ�״̬��ʾ
	then
		if DMX_Status_page == 0x55
		then
			DMX_Status_page = 0
			change_screen(last_sreen)--�лص�ԭ���Ľ���
		end
	end 
end

function on_draw(screen)
	
	if screen == 41  
	then
		set_pen_color(draw_pen_color)
		draw_rect(427,64,475,190,1)
	elseif screen == 5--UCS512-C
	then
		set_pen_color(draw_pen_color)
		draw_rect(389,173,424,204,1)
	elseif screen == 10--UCS512-E
	then
		set_pen_color(draw_pen_color)
		draw_rect(389,184,424,215,1)
	elseif screen == 11--SM17512
	then
		set_pen_color(draw_pen_color)
		draw_rect(367,170,402,200,1)
	elseif screen == 12--SM17500
	then
		set_pen_color(draw_pen_color)
		draw_rect(366,220,401,248,1)
	elseif screen == 15--SM1752X
	then
		set_pen_color(draw_pen_color)
		draw_rect(368,217,403,247,1)
	elseif screen == 16--Hi512D
	then
		set_pen_color(draw_pen_color)
		draw_rect(391,195,430,224,1)
	elseif screen == 22--Hi512A4
	then
		set_pen_color(draw_pen_color)
		draw_rect(366,220,401,248,1)
	elseif screen == 23--Hi512A6
	then
		set_pen_color(draw_pen_color)
		draw_rect(411,202,450,231,1)
	elseif screen == 24--SM1852X
	then
		set_pen_color(draw_pen_color)
		draw_rect(379,200,418,229,1)
	elseif screen == 44--��������õ�
	then
		if Save_screen == 0x55 and Save_show == 0x55--��̬���� ������ģ������
		then
			--����'��ɫȦ'����ʾ��ǰѡ�е���ɫ
			draw_image(63, 1, draw_select_x, draw_select_y, 20, 20, 0, 0)
			
			--������ɫ����������ǰѡ�е���ɫ��
			set_pen_color(select_rgb)
			draw_rect(10,60,40,90,1)
		end
	end
end

-- �Զ��庯�� ��������
function Send_cmd(cmd,dat,c1,c2,c3,c4,c5,c6,c7)	

	send_cmd_xb[0] = 0xc3

	send_cmd_xb[1] = 0xff --UID
 	send_cmd_xb[2] = 0xff	
	send_cmd_xb[3] = 0xff	
	send_cmd_xb[4] = 0xff	
	
	send_cmd_xb[5] = cmd --������
	
	send_cmd_xb[6] = dat --����
	
	send_cmd_xb[7] = c1
	send_cmd_xb[8] = c2
	send_cmd_xb[9] = c3
	send_cmd_xb[10] = c4
	send_cmd_xb[11] = c5
	send_cmd_xb[12] = c6
    send_cmd_xb[13] = c7
	
	for i=14,18 do
		send_cmd_xb[i] = 0x00
	end
	
	check_sum = 0	
	for i=1,17 do
		check_sum = check_sum  + send_cmd_xb[i]
	end

	check_sum = math.modf(check_sum%256)	
	check_sum = Xor(check_sum,0x39)

	send_cmd_xb[18]	= check_sum
	send_cmd_xb[19] = 0xca	

	uart_send_data(send_cmd_xb) --��������
end

-- �Զ��庯�� ���Ͳ�����������
function Send_param_cmd(cmd,d1,d2,d3,d4,d5,d6,d7,d8,d9,d10,d11)	

	send_cmd_xb[0] = 0xc3
 	send_cmd_xb[1] = 0xff
	send_cmd_xb[2] = 0xff
	send_cmd_xb[3] = 0xff
	send_cmd_xb[4] = 0xff
	send_cmd_xb[5] = 0xc7
	send_cmd_xb[6] = cmd
	send_cmd_xb[7] = d1
	send_cmd_xb[8] = d2
	send_cmd_xb[9] = d3
	send_cmd_xb[10] =d4
	send_cmd_xb[11] =d5
	send_cmd_xb[12] =d6
	send_cmd_xb[13] =d7
	send_cmd_xb[14] =d8	
	send_cmd_xb[15] =d9

	send_cmd_xb[16] =d10	
	send_cmd_xb[17] =d11		

	check_sum=0	
	for i=1,17 do
		check_sum = check_sum  + send_cmd_xb[i]
	end

	check_sum = math.modf(check_sum%256)	
	check_sum = Xor(check_sum,0x39)

	send_cmd_xb[18]	= check_sum
	send_cmd_xb[19] = 0xca	
	
	uart_send_data(send_cmd_xb) --��������
end

function TiaoGuang()	
    rr  =  get_value(8,8)--��
	gg =  get_value(8,9)--��
	bb =  get_value(8,10)--��
	ww  =  get_value(8,11)--��
	nw =  get_value(8,12)--ů��
	aw =  get_value(8,13)--����

	ch = get_value(19,4)--ͨ����

	Test_chip_sel()

	Send_cmd(0xe3,ic_sel_test,ch,rr,gg,bb,ww,nw,aw)	
end

function TiaoGuang_new()	
	if Save_screen == 0x55--��̬����ʱ
	then
		if Save_show == 0x00--��׼����
		then
			rr = get_value(44,16)--��
			gg = get_value(44,17)--��
			bb = get_value(44,19)--��
		elseif Save_show == 0x55--ģ������
		then 
			bb = ((select_rgb >>  0) & 0x1F) << 3
			gg = ((select_rgb >>  5) & 0x3F) << 2
			rr = ((select_rgb >> 11) & 0x1F) << 3
		end
		
		ww = get_value(44,5)--��
		nw =  get_value(44,7)--ů��
		aw =  get_value(44,9)--����

		ch = get_value(44,2)--ͨ����

		if get_text(0,4) == "UCS1903"
		then
			ic_sel_test = 0
		elseif get_text(0,4) == "DMX 250K"
		then
			ic_sel_test = 10
		elseif get_text(0,4) == "DMX 500K"
		then
			ic_sel_test = 11
		elseif get_text(0,4) == "GS851X"
		then
			ic_sel_test = 23
		elseif get_text(0,4) == "TM1914"
		then
			ic_sel_test = 8
		elseif get_text(0,4) == "UCS5603"
		then
			ic_sel_test = 15
		elseif get_text(0,4) == "UCS8904"
		then
			ic_sel_test = 20
		else
			ic_sel_test = 10
		end

		Send_cmd(0xe3,ic_sel_test,ch,rr,gg,bb,ww,nw,aw)	
	else--��̬����ʱ
		ic_sel_test = get_value(0,12)--���Է���SD״̬��������Ч�� 0����Ч�� 1SD��Ч��
		
		ch = get_value(44,2)--ͨ����
	
		rr = get_value(44,16)--��
		gg = get_value(44,17)--��
		bb = get_value(44,19)--��
		ww = get_value(44,5)--��
		nw =  get_value(44,7)--ů��
		aw =  get_value(44,9)--����
		Send_cmd(0xe4,ic_sel_test,ch,rr,gg,bb,ww,nw,aw)	
	end
end

function Test_chip_sel()

	if get_text(19,13) == "UCS1903"
	then
		ic_sel_test = 0
	elseif get_text(19,13) == "DMX 250K"
	then
		ic_sel_test = 10
	elseif get_text(19,13) == "DMX 500K"
	then
		ic_sel_test = 11
	elseif get_text(19,13) == "GS851X"
	then
		ic_sel_test = 23
	elseif get_text(19,13) == "TM1814"
	then
		ic_sel_test = 17	
	elseif get_text(19,13) == "TM1914"
	then
		ic_sel_test = 8
	elseif get_text(19,13) == "UCS2603"
	then
		ic_sel_test = 30
	elseif get_text(19,13) == "UCS5/8603"
	then
		ic_sel_test = 15
	elseif get_text(19,13) == "UCS8904"
	then
		ic_sel_test = 20
	elseif get_text(19,13) == "UCS9812"
	then
		ic_sel_test = 26
	elseif get_text(19,13) == "UCS7804"
	then
		ic_sel_test = 31
	elseif get_text(19,13) == "UCS7604"
	then
		ic_sel_test = 33
	elseif get_text(19,13) == "GS8208"
	then
		ic_sel_test = 0
	elseif get_text(19,13) == "SM16714"
	then
		ic_sel_test = 21
	elseif get_text(19,13) == "SM16212"
	then
		ic_sel_test = 32
	elseif get_text(19,13) == "SM16716"
	then
		ic_sel_test = 1
	elseif get_text(19,13) == "SM16803"
	then
		ic_sel_test = 27
	elseif get_text(19,13) == "SM16813"
	then
		ic_sel_test = 22
	elseif get_text(19,13) == "WS2801"
	then
		ic_sel_test = 5
	elseif get_text(19,13) == "WS2816"
	then
		ic_sel_test = 25
	elseif get_text(19,13) == "P9813"
	then
		ic_sel_test = 2
	elseif get_text(19,13) == "P9883"
	then
		ic_sel_test = 9
	elseif get_text(19,13) == "LPD1886"
	then
		ic_sel_test = 6
	elseif get_text(19,13) == "LPD6803"
	then
		ic_sel_test = 3
	elseif get_text(19,13) == "INK1003"
	then
		ic_sel_test = 18
	elseif get_text(19,13) == "LX1003"
	then
		ic_sel_test = 4
	elseif get_text(19,13) == "SM16703"
	then
		ic_sel_test = 0
	elseif get_text(19,13) == "WS2814"
	then
		ic_sel_test = 60
	elseif get_text(19,13) == "MT1885"
	then
		ic_sel_test = 61
	elseif get_text(19,13) == "KW5603A"
	then
		ic_sel_test = 34
	elseif get_text(19,13) == "KW5604"
	then
		ic_sel_test = 35
	elseif get_text(19,13) == "WS2811"
	then
		ic_sel_test = 0
	elseif get_text(19,13) == "TM1804"
	then
		ic_sel_test = 0
	elseif get_text(19,13) == "QS2633"
	then
		ic_sel_test = 38
	elseif get_text(19,13) == "QS2639"
	then
		ic_sel_test = 39
	elseif get_text(19,13) == "SM16713_A"
	then
		ic_sel_test = 40
	elseif get_text(19,13) == "SM16713_B"
	then
		ic_sel_test = 41
	elseif get_text(19,13) == "SM16713_C"
	then
		ic_sel_test = 42
	else
		ic_sel_test = 10
	end
end

function dmx_ic_Sel()
	
	local ret
	ss = get_text(3,8)
	if ss == "UCS512-A"
	then
		ret = 0
	elseif ss == "UCS512-B"
	then
		ret = 0
	elseif ss == "UCS512-C4"
	then
		ret = 3
	elseif ss == "UCS512-CN"
	then
		ret = 3
 	elseif ss == "UCS512-D"
	then
		ret = 6
	elseif ss == "UCS512-C1"
	then
		ret = 6
	elseif ss == "UCS512-E"
	then
		ret = 7
	elseif ss == "UCS512-F"
	then
		ret = 10
	elseif ss == "GS8511"
	then
		ret = 12
	elseif ss == "GS8512"
	then
		ret = 12
	elseif ss == "GS8513"
	then
		ret = 12
	elseif ss == "GS8515"
	then
		ret = 12
	elseif ss == "GS8516"
	then
		ret = 12
	elseif ss == "GS8516B"
	then
		ret = 12
	elseif ss == "GS8525"
	then
		ret = 12
	elseif ss == "SM1651X-3CH"
	then
		ret = 4
	elseif ss == "SM1651X-4CH"
	then
		ret = 5
	elseif ss == "SM17512"
	then
		ret = 8
	elseif ss == "SM1752X"
	then
		ret = 9	
 	elseif ss == "SM17500"
	then
		ret = 13
	elseif ss == "SM17500-S"
	then
		ret = 16
	elseif ss == "QED512P"
	then
		ret = 14
	elseif ss == "Hi512D"
	then
		ret = 15
	elseif ss == "SM1852X"
	then
		ret = 23
	elseif ss == "TM512AB"
	then
		ret = 0
	elseif ss == "TM512AL"
	then
		ret = 0
	elseif ss == "TM512AC"
	then
		ret = 3
	elseif ss == "TM512AD"
	then
		ret = 6
	elseif ss == "TM512AE"
	then
		ret = 7
	elseif ss == "Hi512A0"
	then
		ret = 20
	elseif ss == "Hi512A4"
	then
		ret = 21
	elseif ss == "Hi512A6"
	then
		ret = 22
	elseif ss == "Hi512A0_Self"
	then
		ret = 24
	elseif (ss == "UCS512-G") or (ss == "UCS512-H")or (ss == "UCS512-KH")or (ss == "UCS512-KL")
	then
		ret = 25
	elseif (ss == "UCS512-G-S") or (ss == "UCS512-H-S")or (ss == "UCS512-KH-S")or (ss == "UCS512-KL-S")
	then
		ret = 26
	elseif ss == "SM1952X"
	then
		ret = 27
	elseif ss == "UCS512-K-Self"
	then
		ret = 28
	elseif ss == "KW512A"
	then
		ret = 29
	--[[
	elseif ss == "UCS512-k-s" --ucs512-k ����дַ
	then
		ret = 30 
	--]]
	elseif ss == "GS8523" or ss == "GS8524"  or ss == "GS8526"
	then
		ret = 31
	elseif ss == "SM522" or ss == "SM18500P"  or ss == "SM18500PS"
	then
		ret = 32
	elseif ss == "SM522-S" or ss == "SM18500P-S"  or ss == "SM18500PS-S"
	then
		ret = 33
	end
	return ret
end

function GS_test()

	tmp_dat[7] = get_value(71,12) 
	tmp_dat[8] = get_value(71,50) 
	
	if get_text(71,18) == "250K"
	then
		tmp_dat[9] = 0xAA
	elseif get_text(71,18) == "400K"
	then
		tmp_dat[9] = 0xBB
	elseif get_text(71,18) == "500K"
	then
		tmp_dat[9] = 0xCC
	else
		tmp_dat[9] = 0xAA	--Ĭ��250K
	end
	
	tmp_dat[10] = get_value(71,23)
	
	if get_text(71,30)=="GS8526"
	then
		tmp_dat[11] = 1
	else
		tmp_dat[11] = 0
	end
	
	Send_cmd(0xd4,0x04,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],0,0)
end

--ϵͳ���� �����Զ�����պ���
function on_uart_recv_data(packet)
	collectgarbage("collect")
	if packet[0]==0xee and packet[1]==0xb5  and packet[12]==0xff and packet[13]==0xfc and packet[14]==0xff and packet[15]==0xff  
	then
		if packet[2] == 0xe1--��ѯ���� оƬ ģʽ  �ٶ� ͨ���� ��ͣ/���� SD���Ƿ����
		then
			--оƬ
			if packet[3] == 0
			then
				xp = 0
				set_text(0,4,"UCS1903")
			elseif packet[3] == 1
			then
				xp = 18
				set_text(0,4,"SM16716")
			elseif packet[3] == 2
			then
				set_text(0,4,"P9813")
			elseif packet[3] == 3
			then
				xp = 23
				set_text(0,4,"LPD6803")
			elseif packet[3] == 4
			then
				set_text(0,4,"LX1003")
			elseif packet[3] == 5
			then
				set_text(0,4,"WS2801")
			elseif packet[3] == 6
			then
				set_text(0,4,"LPD1886")
			elseif packet[3] == 8
			then	
				xp = 5
				set_text(0,4,"TM1914")
			elseif packet[3] == 9
			then
				set_text(0,4,"P9883")
			elseif packet[3] == 10
			then
				xp = 1
				set_text(0,4,"DMX 250K")
	 		elseif packet[3] == 11
			then	
				xp = 2
				set_text(0,4,"DMX 500K")
			elseif packet[3] == 14
			then	
				xp = 6
				set_text(0,4,"UCSX603_T")
			elseif packet[3] == 15
			then	
				xp = 8
				set_text(0,4,"UCS5/8603")
			elseif packet[3] == 17
			then	
				xp = 4
				set_text(0,4,"TM1814")
			elseif packet[3] == 18
			then	
				set_text(0,4,"INK1003")
			elseif packet[3] == 20
			then	
				xp = 9
				set_text(0,4,"UCS8904")
			elseif packet[3] == 21
			then	
				xp = 17
				set_text(0,4,"SM16714")
			elseif packet[3] == 22
			then	
				xp = 21
				set_text(0,4,"SM16813")
			elseif packet[3] == 23
			then	
				xp = 3
				set_text(0,4,"GS851X")
			elseif packet[3] == 25
			then	
				xp = 22
				set_text(0,4,"WS2816")
			elseif packet[3] == 26
			then	
				xp = 10
				set_text(0,4,"UCS9812")
			elseif packet[3] == 27
			then	
				xp = 19
				set_text(0,4,"SM16803")
			elseif packet[3] == 28
			then	
				xp = 20
				set_text(0,4,"SM16804")
			elseif packet[3] == 30
			then	
				xp = 7
				set_text(0,4,"UCS2603")
			elseif packet[3] == 31
			then	
				xp = 12
				set_text(0,4,"UCS7804")
			elseif packet[3] == 33
			then	
				xp = 11
				set_text(0,4,"UCS7604")
			elseif packet[3] == 40
			then	
				xp = 14
				set_text(0,4,"SM16713_A")
			elseif packet[3] == 41
			then
				xp = 15
				set_text(0,4,"SM16713_B")
			elseif packet[3] == 42
			then	
				xp = 16
				set_text(0,4,"SM16713_C")
			elseif packet[3] == 50
			then	
				xp = 24
				set_text(0,4,"HW1002")
			elseif packet[3] == 51
			then	
				xp = 25
				set_text(0,4,"HW1603_1")
			elseif packet[3] == 52
			then
				xp = 26
				set_text(0,4,"HW1603_2")
			elseif packet[3] == 53
			then	
				xp = 27
				set_text(0,4,"HW1603_3")
			elseif packet[3] == 60
			then	
				xp = 34
				set_text(0,4,"WS2814")
			elseif packet[3] == 61
			then	
				xp = 35
				set_text(0,4,"MT1885")
			end
	
			--ģʽ
 			ss = string.format("Mode%d",packet[4]+1)	
			set_text(0,6,ss)	
	
			--�ٶ�
			ss = string.format("Speed%d",packet[5])	
			set_text(0,7,ss)	

	 		--ͨ����
			ch =math.modf(And(packet[6],0x0f))
			if ch == 3--��ͨ��
			then
				set_value(0,14,0)	

				if get_language() == 0--����
				then
					set_text(0,19,"3ͨ��")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(0,19,"3-channel")
				end	
			elseif ch == 4--4ͨ��
			then
				set_value(0,14,1)	
				
				if get_language() == 0--����
				then
					set_text(0,19,"4ͨ��")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(0,19,"4-channel")
				end		
			end
					
			--ѭ�����
			packet[6] = math.modf(packet[6]/16)
			cyc =math.modf(And(packet[6],0x0f))
			if cyc == 0--��ѭ��
			then
				set_value(0,21,0)	

				if get_language() == 0--����
				then
					set_text(0,22,"��ѭ��")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(0,22,"No Cycle")
				end	
			elseif cyc == 0x05--ѭ��
			then
				set_value(0,21,1)	
				
				if get_language() == 0--����
				then
					set_text(0,22,"ѭ��")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(0,22,"Cycle")
				end		
			end
			
			--����������汾��
			ver_H= math.modf(packet[7]/16)
			ver_H =math.modf(And(ver_H,0x0f))
			
			ver_L=math.modf(And(packet[7],0x0f))	 			

			ss = string.format("v%d.%d",ver_H,ver_L)	
			set_text(0,2,ss)
			set_text(37,2,ss)		
			
			-----------------------
			--�����ǵ�ص�������ʾ
			
			--���ڳ��ʱ��ADC���ֵҪ��㡣
			--ֹͣ���ʱ��ADC���ֵҪС�㡣
			
			bat = packet[9]*256+packet[10]--��ص���,���ݲ�ͬ��������ʾ��ͬ�Ķ���
				
			set_value(0,23,bat)	
			set_value(37,23,bat)

			Is_charge = packet[11]--�Ƿ��ڳ��״̬

			if bat >=2560--��ⷶΧΪ 3.0V--4.15V �����ﵽ4.15Vʱ��ʵ�ʻ�û��������������Ϊ�Ѿ�������
			then
				Is_charge = 0
 				charge_frame = 0	
			end

			--2.9V--4.1V    1.2/5=2.4
			--1860--2560 ��700��  �ֳ�5���ȼ�
			--< 1940    <3.14V
			-->=1940 && < 2048 3.14V-- 3.38V
			-->=2048 && < 2228 3.38V--3.62V
			-->=2228 && <2400  3.62V--3.86V
			-->=2480  >=3.9V  

			if Is_charge == 0--��������������ʾ
			then
				if bat <2050
				then
					set_value(0,3,0)
					set_value(37,3,0)	
				elseif 	bat >=2050 and bat <2200
				then
					set_value(0,3,1)
					set_value(37,3,1)			
				elseif bat >=2200 and bat <2350
				then
					set_value(0,3,2)
					set_value(37,3,2)
				elseif bat >=2350 and bat <2480
				then
					set_value(0,3,3)
					set_value(37,3,3)
				elseif bat >=2480
				then
					set_value(0,3,4)
					set_value(37,3,4)
				end
				
				if bat < 2050
				then
					bat = 2050
				elseif bat > 2480
				then
					bat = 2480
				end
				
				--[[
				--�������� 2050--2480 430��  ������Ԥ����������� 2050 ���������2480����Ҫ����
				DL_value = string.format("%d%%",math.modf((bat - 2050)*100/430))--����ֵ	
				set_text(0,5,DL_value)
				set_text(37,8,DL_value)
				--]]
				
				if first_run == 0 --�ϵ��һ������ʱ���ͼ�⵽�ڳ�磬��ô�����ֱ����ʾ
				then
					--�������� 2050--2480 430��  ������Ԥ����������� 2050 ���������2480����Ҫ����
					DL_value = string.format("%d%%",math.modf((bat - 2050)*100/430))--����ֵ	
					set_text(0,5,DL_value)
					set_text(37,8,DL_value)
				else
					if Is_charge_tmp == 0 and delay_show == 0
					then
						--�������� 2050--2480 430��  ������Ԥ����������� 2050 ���������2480����Ҫ����
						DL_value = string.format("%d%%",math.modf((bat - 2050)*100/430))--����ֵ	
						set_text(0,5,DL_value)
						set_text(37,8,DL_value)
					else
						delay_show = 0x55--֮ǰ���ڳ�磬���ڲ�����ˣ�����ʱ��ʾ���
					end	
				end
						
			elseif Is_charge == 0x55--���ڳ��
			then
				if bat < 2140
				then
					bat = 2140
				elseif bat > 2560
				then
					bat = 2560
				end			
				--[[	
				--���ڳ�磬 2140--2560 420��    ������Ԥ����������� 2140 ���������2560����Ҫ����
				DL_value = string.format("%d%%",math.modf((bat - 2140)*100/420))--����ֵ	
				set_text(0,5,DL_value)
				set_text(37,8,DL_value)
				--]]
				
				if first_run == 0 --�ϵ��һ������ʱ���ͼ�⵽�ڳ�磬��ô�����ֱ����ʾ
				then
					--���ڳ�磬 2140--2560 420��    ������Ԥ����������� 2140 ���������2560����Ҫ����
					DL_value = string.format("%d%%",math.modf((bat - 2140)*100/420))--����ֵ	
					set_text(0,5,DL_value)
					set_text(37,8,DL_value)
				else
					if Is_charge_tmp == 0x55 and delay_show == 0
					then
						--���ڳ�磬 2140--2560 420��    ������Ԥ����������� 2140 ���������2560����Ҫ����
						DL_value = string.format("%d%%",math.modf((bat - 2140)*100/420))--����ֵ	
						set_text(0,5,DL_value)
						set_text(37,8,DL_value)
					else
						delay_show = 0x55--֮ǰû�г�磬���ڳ���ˣ�����ʱ��ʾ���					
					end
				end
				
			end
			
			if Is_charge_tmp == Is_charge
			then
				
			else
				delay_count = 0--������ʱ��ʱ��
			end
			
			Is_charge_tmp = Is_charge

			--------------------------

			if first_run ==0 --����һ�ο�������ʱ���յ��˿������ķ������ͰѶ�ʱ����ʱ������Ϊ10��
			then
				first_run = 0x55

				SD_Exist = packet[8]--SD���Ƿ���ڵı��
				if SD_Exist == 0x55--SD������
				then
					set_value(0,12,1)	
					
					if get_language() == 0--����
					then
						set_text(0,17,"SDЧ��")	
					elseif get_language() == 1--Ӣ��
					then
						set_text(0,17,"SD")	
					end	
				else--SD��������  Default
					set_value(0,12,0)	

					if get_language() == 0--����
					then
						set_text(0,17,"Ԥ��Ч��")
					elseif get_language() == 1--Ӣ��
					then
						set_text(0,17,"Default")
					end	
				end

				time2 = 10000--�������ö�ʱ��1
				stop_timer(1)
 				start_timer(1,time2,1,0)	
			end
		
		elseif packet[2] == 0xc7--д��������
		then
			if packet[3] == 0x02--UCS512-Cд��������
			then
				set_value(5,13,0)
 				set_text(5,15,"Set")	
 			elseif packet[3] == 0x03--UCS512-Dд��������
			then
				set_value(5,13,0)	
 				set_text(5,15,"Set")		
 			elseif packet[3] == 0x04--UCS512-Dд��������
			then
				set_value(9,13,0)
				set_text(9,7,"Set")		
 			elseif packet[3] == 0x05--UCS512-Eд��������
			then
				set_value(10,13,0)
				set_text(10,19,"Set")	
			elseif packet[3] == 0x06--UCS512-Eд��ͨ��������
			then
				set_value(13,4,0)	
 				set_text(13,8,"Set")		
			elseif packet[3] == 0x07--UCS512-Eд��������
			then
				set_value(13,13,0)	
 				set_text(13,7,"Set")		
			elseif packet[3] == 0x08--SM17512д��������
			then
				set_value(11,13,0)		
 				set_text(11,22,"Set")		
			elseif packet[3] == 0x09--SM1752Xд��������
			then
				set_value(15,13,0)	
 				set_text(15,22,"Set")		
 			elseif packet[3] == 0x0a--SM1752Xд��������
			then
				set_value(14,13,0)		
 				set_text(14,22,"Set")		
 			elseif packet[3] == 0x0b--UCS512Fд��������
			then
				set_value(5,13,0)
 				set_text(5,15,"Set")		
 			elseif packet[3] == 0x0c--UCS512F�����Զ�/�ֶ�д��
			then
				set_value(9,4,0)	
 				set_text(9,8,"Set")			
 			elseif packet[3] == 0x0d--UCS512Fд��������
			then
				set_value(9,13,0)		
 				set_text(9,7,"Set")			
 			elseif packet[3] == 0x0f--GS851Xд���ŵ�ַ
			then	
				set_value(18,13,0)		
 				set_text(18,7,"Set")	
 			elseif packet[3] == 0x10--GS851X����Ϊ�޵�ַģʽ
			then	
				set_value(18,14,0)	
				set_text(18,6,"Set")		
 			elseif packet[3] == 0x11--SM17500д����
			then	
				set_value(12,13,0)		
 				set_text(12,22,"Set")	
 			elseif packet[3] == 0x12--SM17500д��ͨ����
			then	
				set_value(14,4,0)	
 				set_text(14,16,"Set")	
			elseif packet[3] == 0x13--SM17500��ͨ����дַ
			then	
				set_value(14,7,0)		
 				set_text(14,17,"Set")		
 			elseif packet[3] == 0x14--SM17500д����
			then	
				set_value(14,13,0)		
 				set_text(14,22,"Set")		
 			elseif packet[3] == 0x15--Hi512Dд����
			then	
				set_value(16,13,0)
 				set_text(16,29,"Set")	
			elseif packet[3] == 0x16--Hi512Dд����
			then	
				set_value(17,20,0)	
				set_text(17,24,"Set")	
			elseif packet[3] == 0x17--Hi512D�ĵ��ŵ�ַ
			then	
				set_value(17,7,0)	
				set_text(17,29,"Set")		
			elseif packet[3] == 0x18--Hi512D�Զ���ַ
			then	
				set_value(17,13,0)		
 				set_text(17,23,"Set")		
			elseif packet[3] == 0x30--Hi512A0д��ͨ����
			then	
				set_value(21,4,0)	
				set_text(21,16,"Set")	
			elseif packet[3] == 0x31--Hi512A4д����
			then	
				set_value(22,4,0)	
				set_text(22,1,"Set")		
			elseif packet[3] == 0x32--Hi512A6д����
			then	
				set_value(23,13,0)	
				set_text(23,29,"Set")	
 			elseif packet[3] == 0x33--SM1852Xд����
			then	
				set_value(24,13,0)	
				set_text(24,22,"Set")	
			elseif packet[3] == 0x34--SM1852Xд����
			then	
				set_value(25,13,0)	
				set_text(25,7,"Set")		
 			elseif packet[3] == 0x35--SM1852X�Զ�����
			then	
				set_value(25,15,0)	
				set_text(25,16,"Set")
			elseif packet[3] == 0x36--QED512Pд����
			then	
				set_value(26,5,0)	
				set_text(26,16,"Set")	
			elseif packet[3] == 0x3a--UCS512-Gд����
			then	
				if packet[5] == 0x01--�����ֶ���
				then
					set_value(45,13,0)	
					set_text(45,22,"Set")

					set_value(47,13,0)	
					set_text(47,22,"Set")
				elseif packet[5] == 0x02--���� �Զ�д��
				then
					set_value(45,9,0)	
					set_text(45,10,"Set")

					set_value(47,9,0)	
					set_text(47,10,"Set")
				elseif packet[5] == 0x03--���� �Ҷ�ƽ��
				then
					set_value(45,15,0)	
					set_text(45,16,"Set")	
					
					set_value(47,15,0)	
					set_text(47,16,"Set")	
				elseif packet[5] == 0x04--���� A�˿ڿ�����
				then
					set_value(45,20,0)	
					set_text(45,21,"Set")
					
					set_value(47,20,0)	
					set_text(47,21,"Set")
				elseif packet[5] == 0x05--���� �����ȼ�
				then
					set_value(45,26,0)	
					set_text(45,27,"Set")
				elseif packet[5] == 0x06--���� PWM�ȼ�
				then
					set_value(45,31,0)	
					set_text(45,32,"Set")
				elseif packet[5] == 0x07--���� ��������
				then
					set_value(46,31,0)	
					set_text(46,32,"Set")
				elseif packet[5] == 0x08--���� 0�ֶ�ģʽ
				then
					set_value(47,31,0)	
					set_text(47,32,"Set")
				elseif packet[5] == 0x09--���� UCS512-H��������
				then
					set_value(48,31,0)	
					set_text(48,32,"Set")
				elseif packet[5] == 0x0a--���� UCS512-H�����ȼ�
				then
					set_value(47,26,0)	
					set_text(47,27,"Set")
				elseif packet[5] == 0x0b--����ʱ��
				then
					set_value(45,48,0)	
					set_text(45,49,"Set")

					set_value(47,38,0)	
					set_text(47,39,"Set")
				end
			elseif packet[3] == 0x3b--SM1952Xд����
			then
				if packet[4] == 0x01
				then
					set_value(50,41,0)	
					set_text(50,42,"Set")
				elseif packet[4] == 0x02
				then
					set_value(51,27,0)	
					set_text(51,19,"Set")
				elseif packet[4] == 0x03
				then
					set_value(50,27,0)	
					set_text(50,29,"Set")
				elseif packet[4] == 0x04
				then
					set_value(52,13,0)	
					set_text(52,15,"Set")
				elseif packet[4] == 0x05
				then
					set_value(50,37,0)	
					set_text(50,38,"Set")
				end
			elseif packet[3] == 0x3d--ָʾUCS512-KHд����
			then
				if packet[4] == 0x01
				then
					set_value(53,13,0)	
					set_text(53,8,"Set")
				elseif packet[4] == 0x11
				then
					set_value(55,13,0)	
					set_text(55,8,"Set")
				elseif packet[4] == 0x02
				then
					set_value(53,38,0)	
					set_text(53,20,"Set")
				elseif packet[4] == 0x12
				then
					set_value(55,38,0)	
					set_text(55,20,"Set")
				elseif packet[4] == 0x03
				then
					set_value(53,9,0)	
					set_text(53,21,"Set")
				elseif packet[4] == 0x13
				then
					set_value(55,9,0)	
					set_text(55,21,"Set")
					
					Auto_write = 0x55
					
					if get_language() == 0--����
					then
						if get_text(3,8)== "UCS512-KL"		then	set_text(65,7,"UCS512-KL����д��ɹ�")
						elseif get_text(3,8)== "UCS512-KH" 	then	set_text(65,7,"UCS512-KH����д��ɹ�") 	end
						
						set_text(65,2,"�ѹرո�оƬ���Զ�д�빦�ܣ�")	
					elseif get_language() == 1--Ӣ��
					then
						if get_text(3,8)== "UCS512-KL"		then	set_text(65,7,"UCS512-KL Parameter writing succeeded")
						elseif get_text(3,8)== "UCS512-KH" 	then	set_text(65,7,"UCS512-KH Parameter writing succeeded") 	end
							
						set_text(65,2,"Parameter writing succeeds��")	
					end

					
				elseif packet[4] == 0x04
				then
					set_value(53,31,0)	
					set_text(53,22,"Set")
				elseif packet[4] == 0x05
				then
					set_value(54,31,0)	
					set_text(54,32,"Set")
				elseif packet[4] == 0x15
				then
					set_value(56,31,0)	
					set_text(56,32,"Set")
				elseif packet[4] == 0x06
				then
					set_value(54,2,0)	
					set_text(54,3,"Set")
				elseif packet[4] == 0x07
				then
					set_value(53,26,0)	
					set_text(53,27,"Set")
				elseif packet[4] == 0x17
				then
					set_value(55,26,0)	
					set_text(55,27,"Set")
				elseif packet[4] == 0x08
				then
					set_value(54,34,0)	
					set_text(54,35,"Set")
				elseif packet[4] == 0x09
				then
					set_value(53,18,0)
					set_value(54,20,0)
					
					set_text(53,24,"Set")
					set_text(54,6,"Set")
				elseif packet[4] == 0x19
				then
					set_value(55,18,0)
					set_value(56,20,0)
					
					set_text(55,24,"Set")
					set_text(56,6,"Set")
				end
			elseif packet[3] == 0x3e--UCS512-C1
			then
				if packet[4] == 0x01
				then
					set_value(59,25,0)	
					set_text(59,26,"Set")
				elseif packet[4] == 0x02
				then
					set_value(59,28,0)	
					set_text(59,29,"Set")
				end
			elseif packet[3] == 0x3f--KW512A
			then
				if packet[4] == 0x00
				then
					set_value(68,13,0)	
					set_text(68,15,"Set")
				end
			elseif packet[3] == 0x40--SM522
			then
				if packet[4] == 0x01	--��������λ
				then
					set_value(72,27,0)	
					set_text(72,19,"Set")
				elseif packet[4] == 0x02	--��������
				then
					set_value(72,13,0)	
					set_text(72,15,"Set")
				end
			elseif packet[3] == 0x41--SM18500P
			then
				if packet[4] == 0x01	--��������λ
				then
					set_value(73,34,0)	
					set_text(73,35,"Set")
				elseif packet[4] == 0x02	--��������
				then
					set_value(74,34,0)	
					set_text(74,35,"Set")
				elseif packet[4] == 0x03	--����дַ
				then
					set_value(74,15,0)	
					set_text(74,16,"Set")
				elseif packet[4] == 0x04	--����Ч��
				then
					set_value(75,34,0)	
					set_text(75,35,"Set")
				end
			end	
	
 		elseif packet[2] == 0xc6--д�뷴��
		then	
			set_value(3,12,0)	
			set_value(69,12,0)
			if get_language() == 0--����
			then
				set_text(3,2,"дַ")
				set_text(69,2,"дַ")
			elseif get_language() == 1--Ӣ��
			then
				set_text(3,2,"Write Add")
				set_text(69,2,"дַ")
			end				
 		elseif packet[2] == 0xa2--SD�� �л���Ŀ����
		then	
 			ss = string.format("Mode%d",packet[3]+1)	
			set_text(0,6,ss)	
	
			if Save_screen == 0x55--�б����ǣ�������ñ��
			then
				Save_screen = 0
			
				data[0] = 0--���λ
				data[1] = 0
				
				write_flash(0x00,data)
			end
 		elseif packet[2] == 0xa3--SD�� �л�IC����
		then	
			--оƬ
			if packet[3] == 0
			then
				set_text(0,4,"UCS1903")
			elseif packet[3] == 1
			then
				set_text(0,4,"SM16716")
			elseif packet[3] == 2
			then
				set_text(0,4,"P9813")
			elseif packet[3] == 3
			then
				set_text(0,4,"LPD6803")
			elseif packet[3] == 4
			then
				set_text(0,4,"LX1003")
			elseif packet[3] == 5
			then
				set_text(0,4,"WS2801")
				elseif packet[3] == 6
			then
				set_text(0,4,"LPD1886")
			elseif packet[3] == 8
			then	
				set_text(0,4,"TM1914")
			elseif packet[3] == 9
			then
				set_text(0,4,"P9883")
			elseif packet[3] == 10
			then
				set_text(0,4,"DMX 250K")
	 		elseif packet[3] == 11
			then	
				set_text(0,4,"DMX 500K")
			elseif packet[3] == 14
			then	
				set_text(0,4,"UCSX603_T")
			elseif packet[3] == 15
			then	
				set_text(0,4,"UCS5/8603")
			elseif packet[3] == 17
			then	
				set_text(0,4,"TM1814")
			elseif packet[3] == 18
			then	
				set_text(0,4,"INK1003")
			elseif packet[3] == 20
			then	
				set_text(0,4,"UCS8904")
			elseif packet[3] == 21
			then	
				set_text(0,4,"SM16714")
			elseif packet[3] == 22
			then	
				set_text(0,4,"SM16813")
			elseif packet[3] == 23
			then	
				set_text(0,4,"GS851X")
			elseif packet[3] == 25
			then	
				set_text(0,4,"WS2816")
			elseif packet[3] == 26
			then	
				set_text(0,4,"UCS9812")
			elseif packet[3] == 27
			then	
				set_text(0,4,"SM16803")
			elseif packet[3] == 28
			then	
				set_text(0,4,"SM16804")
			elseif packet[3] == 30
			then	
				set_text(0,4,"UCS2603")
			elseif packet[3] == 31
			then	
				set_text(0,4,"UCS7804")
			elseif packet[3] == 33
			then	
				set_text(0,4,"UCS7604")
			elseif packet[3] == 40
			then	
				set_text(0,4,"SM16713_A")
			elseif packet[3] == 41
			then	
				set_text(0,4,"SM16713_B")
			elseif packet[3] == 50
			then	
				set_text(0,4,"HW1002")
			elseif packet[3] == 51
			then	
				set_text(0,4,"HW1603_1")
			elseif packet[3] == 52
			then	
				set_text(0,4,"HW1603_2")
			elseif packet[3] == 53
			then	
				set_text(0,4,"HW1603_3")
			elseif packet[3] == 60
			then	
				set_text(0,4,"WS2814")
			elseif packet[3] == 61
			then	
				set_text(0,4,"MT1885")
			end
 		elseif packet[2] == 0xa4--SD�� �����ٶȷ���
		then	
 			ss = string.format("Speed%d",packet[3])	
			set_text(0,7,ss)	

			if Save_screen == 0x55--�б����ǣ�������ñ��
			then
				Save_screen = 0
			
				data[0] = 0--���λ
				data[1] = 0
				
				write_flash(0x00,data)
			end
 		elseif packet[2] == 0xa5--SD�� ѭ�����ŷ���
		then	
 			if packet[3] == 0x00 --��ѭ��
			then
				set_value(0,21,0)

				if get_language() == 0--����
				then
					set_text(0,22,"��ѭ��")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(0,22,"No Cycle")
				end	

			elseif packet[3] == 0x55 --ѭ��
			then
				set_value(0,21,1)

				if get_language() == 0--����
				then
					set_text(0,22,"ѭ��")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(0,22,"Cycle")
				end	
			end		
		elseif packet[2] == 0xc2--����Ч�� �л���Ŀ����
		then		
			ss = string.format("Mode%d",packet[3]+1)	
			set_text(0,6,ss)	

			if Save_screen == 0x55--�б����ǣ�������ñ��
			then
				Save_screen = 0
			
				data[0] = 0--���λ
				data[1] = 0
				
				write_flash(0x00,data)
			end
 		elseif packet[2] == 0xc3--����Ч�� �����ٶȷ���
		then		
			ss = string.format("Speed%d",packet[3])	
			set_text(0,7,ss)	

			if Save_screen == 0x55--�б����ǣ�������ñ��
			then
				Save_screen = 0
			
				data[0] = 0--���λ
				data[1] = 0
				
				write_flash(0x00,data)
			end
 		elseif packet[2] == 0xc4--����Ч�� ����IC����
		then	
			--оƬ
			if packet[3] == 0
			then
				set_text(0,4,"UCS1903")
			elseif packet[3] == 1
			then
				set_text(0,4,"SM16716")
			elseif packet[3] == 2
			then
				set_text(0,4,"P9813")
			elseif packet[3] == 3
			then
				set_text(0,4,"LPD6803")
			elseif packet[3] == 4
			then
				set_text(0,4,"LX1003")
			elseif packet[3] == 5
			then
				set_text(0,4,"WS2801")
				elseif packet[3] == 6
			then
				set_text(0,4,"LPD1886")
			elseif packet[3] == 8
			then	
				set_text(0,4,"TM1914")
			elseif packet[3] == 9
			then
				set_text(0,4,"P9883")
			elseif packet[3] == 10
			then
				set_text(0,4,"DMX 250K")
	 		elseif packet[3] == 11
			then	
				set_text(0,4,"DMX 500K")
			elseif packet[3] == 14
			then	
				set_text(0,4,"UCSX603_T")
			elseif packet[3] == 15
			then	
				set_text(0,4,"UCS5/8603")
			elseif packet[3] == 17
			then	
				set_text(0,4,"TM1814")
			elseif packet[3] == 18
			then	
				set_text(0,4,"INK1003")
			elseif packet[3] == 20
			then	
				set_text(0,4,"UCS8904")
			elseif packet[3] == 21
			then	
				set_text(0,4,"SM16714")
			elseif packet[3] == 22
			then	
				set_text(0,4,"SM16813")
			elseif packet[3] == 23
			then	
				set_text(0,4,"GS851X")
			elseif packet[3] == 25
			then	
				set_text(0,4,"WS2816")
			elseif packet[3] == 26
			then	
				set_text(0,4,"UCS9812")
			elseif packet[3] == 27
			then	
				set_text(0,4,"SM16803")
			elseif packet[3] == 28
			then	
				set_text(0,4,"SM16804")
			elseif packet[3] == 30
			then	
				set_text(0,4,"UCS2603")
			elseif packet[3] == 31
			then	
				set_text(0,4,"UCS7804")
			elseif packet[3] == 40
			then	
				set_text(0,4,"SM16713_A")
			elseif packet[3] == 41
			then	
				set_text(0,4,"SM16713_B")
			elseif packet[3] == 50
			then	
				set_text(0,4,"HW1002")
			elseif packet[3] == 51
			then	
				set_text(0,4,"HW1603_1")
			elseif packet[3] == 52
			then	
				set_text(0,4,"HW1603_2")
			elseif packet[3] == 53
			then	
				set_text(0,4,"HW1603_3")
			end
		elseif packet[2] == 0xc5--����Ч�� ����ͨ��������
		then	
			if packet[3] == 3 --3ͨ��
			then
				set_value(0,14,0)

				if get_language() == 0--����
				then
					set_text(0,19,"3ͨ��")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(0,19,"3-channel")
				end	

			elseif packet[3] == 4 --4ͨ��
			then
				set_value(0,14,1)

				if get_language() == 0--����
				then
					set_text(0,19,"4ͨ��")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(0,19,"4-channel")
				end	
			end	
		elseif packet[2] == 0xb1--GS851X �ŵ�ַ
		then	
			set_value(28,2,0)		
		elseif packet[2] == 0xb2--GS851X д��ַ
		then	
			set_value(28,3,0)	
		elseif packet[2] == 0xb3--GS851X У���ַ
		then	
			set_value(18,9,0)	
			set_text(18,10,"Set")
		elseif packet[2] == 0xb4--GS851X д���ŵ�ַ
		then	
			set_value(28,1,0)	
			set_text(28,7,"Set")
			
			set_value(61,1,0)	
			set_text(61,7,"Set")
			
			if GSTY == 0x55	--GSͳһ���õ���д�������� 
			then
				set_value(3,12,0)	
				if get_language() == 0--����
				then
					set_text(3,2,"дַ")
				elseif get_language() == 1--Ӣ��
				then
					set_text(3,2,"Write Add")
				end
			end
		elseif packet[2] == 0xb5--GS851X ����Ϊ�޵�ַģʽ
		then	
			set_value(28,2,0)	
			set_text(28,10,"Set")
			
			set_value(61,2,0)	
			set_text(61,10,"Set")
		elseif packet[2] == 0xb6--GS851X ��������֡
		then	
			set_value(28,9,0)	
			set_text(28,23,"Set")
			
			set_value(62,43,0)	
			set_text(62,44,"Set")
		elseif packet[2] == 0xb7--GS851X ���Ͳ���֡
		then	
			set_value(49,13,0)	
			set_text(49,15,"Set")
		elseif packet[2] == 0xb8 --GS851X �����Զ�д�� ����
		then	
			set_value(49,18,0)	
			set_text(49,20,"Set")
			
			set_value(61,18,0)	
			set_text(61,9,"Set")
			
			set_value(64,18,0)	
			set_text(64,20,"Set")
		elseif packet[2] == 0xb9 --GS851X �����ֶ���
		then	
			set_value(49,28,0)	
			set_text(49,29,"Set")
			
			set_value(60,28,0)	
			set_text(60,29,"Set")
			
			set_value(62,28,0)	
			set_text(62,29,"Set")
		elseif packet[2] == 0xba --GS8516B �ϵ�����
		then	
			set_value(60,13,0)	
			set_text(60,45,"Set")
		elseif packet[2] == 0xbb --7804 ���ò���
		then	
			set_value(58,31,0)	
			set_text(58,32,"Set")
		elseif packet[2] == 0xbc --GS8516B �ϵ�����
		then	
			set_value(60,12,0)	
			set_text(60,36,"Set")
		elseif packet[2] == 0xbd --GS8525 ADDI�麸���
		then	
			set_value(62,13,0)	
			set_text(62,15,"Set")
		elseif packet[2] == 0xbe --GS8525 �Ҷ�ƽ��
		then	
			set_value(62,49,0)	
			set_text(62,50,"Set")
		elseif packet[2] == 0xbf --GS8525 ���ź�״̬���ϵ�Ҷ�
		then	
			set_value(63,27,0)	
			set_text(63,19,"Set")
		elseif packet[2] == 0xD0 --7604 ���ò���
		then	
			set_value(66,31,0)	
			set_text(66,32,"Set")
		elseif packet[2] == 0xD1 --GS8525 ͨ����ƽ��
		then	
			set_value(62,37,0)	
			set_text(62,38,"Set")
		elseif packet[2] == 0xD2 --GS8525 �Ҷ�ƽ��Ч��
		then	
			set_value(67,13,0)	
			set_text(67,15,"Set")
		elseif packet[2] == 0xD3 --GS8525 RGBW ����
		then	
			set_value(67,37,0)	
			set_text(67,38,"Set")
		elseif packet[2] == 0xD4 --GS852346д����
		then	
			if packet[3] == 0x00--�����ֶ�
			then
				set_value(70,28,0)	
				set_text(70,29,"Set")
			elseif packet[3] == 0x01--���õ���
			then
				set_value(70,37,0)	
				set_text(70,38,"Set")
			elseif packet[3] == 0x02--�����ϵ�����״̬
			then
				set_value(70,19,0)	
				set_text(70,20,"Set")
			elseif packet[3] == 0x03--����AB�麸
			then
				set_value(70,22,0)	
				set_text(70,21,"Set")
			end
		elseif packet[2] == 0xef--˵���Ǹ��³����
		then
			if packet[3] == 0xf1--�������½���
			then
				set_value(1,2,packet[4])
				local sstt = string.format("%d%%",packet[4])		
		 		set_text(1,3,sstt)		
				
				if get_language() == 0--����
				then
					set_text(1,4,"���ڸ���...")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(1,4,"Updating...")	
				end	
				
				ver_H = packet[5]
				ver_L = packet[6]
				ss = string.format("v%d.%d",ver_H,ver_L)	
				set_text(1,6,ss)	
			elseif packet[3] == 0xf2--SD����������
			then
				set_value(1,2,0)
				set_text(1,3,"0%")
				
				if get_language() == 0--����
				then
					local sstt = string.format("SD��������,������%d",packet[4])		
					set_text(1,4,sstt)	
				elseif get_language() == 1--Ӣ��
				then
					local sstt = string.format("Read SD err%d",packet[4])		
					set_text(1,4,sstt)	
				end		
			elseif packet[3] == 0xf3--���³ɹ�
			then
				set_value(1,2,100)
 				set_value(1,1,0)			
				set_text(1,3,"100%")
				
				if get_language() == 0--����
				then
					set_text(1,5,"�������")
					set_text(1,4,"���³ɹ�����γ�SD��!")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(1,5,"Update success")
					set_text(1,4,"Update complete,take out SD!")	
				end	

				ver_H = packet[5]
				ver_L = packet[6]
				ss = string.format("v%d.%d",ver_H,ver_L)	
				set_text(1,6,ss)	
			elseif packet[3] == 0xf4--����ʧ��
			then
				set_value(1,2,100)
 				set_value(1,1,0)					
				set_text(1,3,"100%")	
			
				if packet[4] == 0 --����ʧ�ܣ��ع��ɹ�
				then
					if get_language() == 0--����
					then
						set_text(1,5,"�������")	
						set_text(1,4,"����ʧ�ܣ��ع��ɹ��������¸���!")	
					elseif get_language() == 1--Ӣ��
					then
						set_text(1,5,"Update fail")	
						set_text(1,4,"Update fail,rollback ok,try again!")	
					end	
				else
					if get_language() == 0--����
					then
						set_text(1,5,"�������")	
						set_text(1,4,"����ʧ�ܣ��ع�ʧ�ܣ������¸���!")	
					elseif get_language() == 1--Ӣ��
					then
						set_text(1,5,"Update fail")	
						set_text(1,4,"Update fail,rollback err,try again!")	
					end	
				end	

				ver_H = packet[5]
				ver_L = packet[6]
				ss = string.format("v%d.%d",ver_H,ver_L)	
				set_text(1,6,ss)	
			end 

			if first_run_2 ==0
			then
				first_run_2 = 0x55

				 time2 = 10000--�������ö�ʱ��1
				 stop_timer(1)
 				-- start_timer(1,time2,1,0)	

				change_screen(1)
			end

			upgrade = 0x55

 		elseif packet[2] == 0xe4--��ȡSD������ ��ʾ��Ϣ
		then
			if first_run ==0
			then
				first_run = 0x55

				time2 = 10000--�������ö�ʱ��1
				stop_timer(1)
 				start_timer(1,time2,1,0)	

				change_screen(27)
			end

			upgrade = 0x55
		elseif packet[2] == 0xee --���������Ϣ
		then
			--[[
			if packet[3] == 0x55--���þ�̬����
			then
				if get_language() == 0--����
				then
					set_text(40,2,"���þ�̬����!")
				elseif get_language() == 1--Ӣ��
				then	
					set_text(40,2,"Set OK!")
				end
			else
				if get_language() == 0--����
				then
					set_text(40,2,"�رվ�̬����!")
				elseif get_language() == 1--Ӣ��
				then	
					set_text(40,2,"Set OK!")
				end
			end
			
			change_screen(40)
			--]]
		end
	end
end

--ϵͳÿ��1�����Զ����ô˻ص�����
function on_systick()
	show_week()
end

--ϵͳ���� �û������޸Ŀؼ���ִ�иûص�����
function on_control_notify(screen,control,value)	
	
	if get_text(3,8)=="GS8511" or 
	   get_text(3,8)=="GS8512" or 
	   get_text(3,8)=="GS8513" or 
	   get_text(3,8)=="GS8515" or 
	   get_text(3,8)=="GS8516" or 
	   get_text(3,8)=="GS8516B"or 
	   get_text(3,8)=="GS8523" or
	   get_text(3,8)=="GS8524" or
	   get_text(3,8)=="GS8525" or
	   get_text(3,8)=="GS8526"  
	then 
		if get_value(3,25)==1 	then GSTY = 0x55 
		else 					     GSTY = 0x00					  end
		if get_value(3,23)~=0	then set_value(3,23,0) chongfu_ch = 0 end
	else
		GSTY = 0
	end
	
	if get_text(3,8)=="UCS512-E" or get_text(3,8)=="SM17500-S" or get_text(3,8)=="UCS512-K-Self" or get_text(3,8)=="SM18500P-S" or get_text(3,8)=="SM18500PS-S"
	then
		if	get_value(3,10)~=1	then set_value(3,10,1)	end
		if	get_value(3,23)~=0	then set_value(3,23,0)	end
		if	get_value(3,25)~=0	then set_value(3,25,0)	end
	end
	
	if get_text(69,27)=="ͳһ��ַ" and get_language() == 0 or get_text(69,27)=="     Unified addr" and get_language() == 1
	then
		set_value(69,23,0)
	elseif get_text(69,27)~="����дַ" and get_language() == 0 or get_text(69,27)~="Conventional" and get_language() == 1
	then
		set_value(69,10,0)
		set_value(69,23,0)
	end
	
	if get_text(3,8) == "GS8523"
	then
		if	get_value(3,10) > 3	then set_value(3,10,3)  end
	end
	
	if get_text(71,30) ~= "GS8526"
	then
		set_visiable(71,1,0)
	else
		set_visiable(71,1,1)
	end

	screen_t = screen
	control_t = control
	value_t = value
	
	if screen == 0	    then	if screen_00()==1	then	return 1	end
	elseif screen == 57 then	if screen_57()==1	then	return 1	end
	elseif screen == 44 then	if screen_44()==1	then	return 1	end
	elseif screen == 42 then	if screen_42()==1	then	return 1	end
	elseif screen == 36 then	if screen_36()==1	then	return 1	end
	elseif screen == 37 then	if screen_37()==1	then	return 1	end
	elseif screen == 2  then	if screen_02()==1	then	return 1	end
	elseif screen == 3  then	if screen_03()==1	then	return 1	end
	elseif screen == 29 then	if screen_29()==1	then	return 1	end
	elseif screen == 4  then	if screen_04()==1	then	return 1	end
	elseif screen == 19 then	if screen_19()==1	then	return 1	end
	elseif screen == 43 then	if screen_43()==1	then	return 1	end
	elseif screen == 59 then	if screen_59()==1	then	return 1	end
	elseif screen == 60 then	if screen_60()==1	then	return 1	end
	elseif screen == 61 then	if screen_61()==1	then	return 1	end
	elseif screen == 62 then	if screen_62()==1	then	return 1	end
	elseif screen == 63 then	if screen_63()==1	then	return 1	end
	elseif screen == 64 then	if screen_64()==1	then	return 1	end
	elseif screen == 65 then	if screen_65()==1	then	return 1	end
	
	elseif screen == 30 then	if screen_30()==1	then	return 1	end
	elseif screen == 31 then	if screen_31()==1	then	return 1	end
	elseif screen == 32 then	if screen_32()==1	then	return 1	end
	elseif screen == 33 then	if screen_33()==1	then	return 1	end
	elseif screen == 34 then	if screen_34()==1	then	return 1	end
	
	elseif screen == 38 then	if screen_38()==1	then	return 1	end
	elseif screen == 39 then	if screen_39()==1	then	return 1	end
	elseif screen == 40 then	if screen_40()==1	then	return 1	end
	
	elseif screen == 5  then	if screen_05()==1	then	return 1	end
	elseif screen == 6  then	if screen_06()==1	then	return 1	end
	elseif screen == 7  then	if screen_07()==1	then	return 1	end
	elseif screen == 8  then	if screen_08()==1	then	return 1	end
	elseif screen == 9  then	if screen_09()==1	then	return 1	end
	elseif screen == 10 then	if screen_10()==1	then	return 1	end
	elseif screen == 11 then	if screen_11()==1	then	return 1	end
	elseif screen == 12 then	if screen_12()==1	then	return 1	end
	elseif screen == 13 then	if screen_13()==1	then	return 1	end
	elseif screen == 14 then	if screen_14()==1	then	return 1	end
	elseif screen == 15 then	if screen_15()==1	then	return 1	end
	elseif screen == 16 then	if screen_16()==1	then	return 1	end
	elseif screen == 17 then	if screen_17()==1	then	return 1	end
	elseif screen == 18 then	if screen_18()==1	then	return 1	end
	elseif screen == 20 then	if screen_20()==1	then	return 1	end
	elseif screen == 21 then	if screen_21()==1	then	return 1	end
	elseif screen == 22 then	if screen_22()==1	then	return 1	end
	elseif screen == 23 then	if screen_23()==1	then	return 1	end
	elseif screen == 24 then	if screen_24()==1	then	return 1	end
	elseif screen == 25 then	if screen_25()==1	then	return 1	end
	elseif screen == 26 then	if screen_26()==1	then	return 1	end
	elseif screen == 27 then	if screen_27()==1	then	return 1	end
	elseif screen == 28 then	if screen_28()==1	then	return 1	end
	
	elseif screen == 35 then	if screen_35()==1	then	return 1	end
	
	elseif screen == 41 then	if screen_41()==1	then	return 1	end
	
	elseif screen == 45 then	if screen_45()==1	then	return 1	end
	elseif screen == 46 then	if screen_46()==1	then	return 1	end
	elseif screen == 47 then	if screen_47()==1	then	return 1	end
	elseif screen == 48 then	if screen_48()==1	then	return 1	end
	elseif screen == 49 then	if screen_49()==1	then	return 1	end
	elseif screen == 50 then	if screen_50()==1	then	return 1	end
	elseif screen == 51 then	if screen_51()==1	then	return 1	end
	elseif screen == 52 then	if screen_52()==1	then	return 1	end
	elseif screen == 53 then	if screen_53()==1	then	return 1	end
	elseif screen == 54 then	if screen_54()==1	then	return 1	end
	elseif screen == 55 then	if screen_55()==1	then	return 1	end
	elseif screen == 56 then	if screen_56()==1	then	return 1	end	
	elseif screen == 58 then	if screen_58()==1	then	return 1	end
	elseif screen == 66 then	if screen_66()==1	then	return 1	end
	elseif screen == 67 then	if screen_67()==1	then	return 1	end
	elseif screen == 68 then	if screen_68()==1	then	return 1	end
	elseif screen == 69 then	if screen_69()==1	then	return 1	end
	elseif screen == 70 then	if screen_70()==1	then	return 1	end
	elseif screen == 71 then	if screen_71()==1	then	return 1	end
	elseif screen == 72 then	if screen_72()==1	then	return 1	end
	elseif screen == 73 then	if screen_73()==1	then	return 1	end
	elseif screen == 74 then	if screen_74()==1	then	return 1	end
	elseif screen == 75 then	if screen_75()==1	then	return 1	end
	elseif screen == 76 then	if screen_76()==1	then	return 1	end
	elseif screen == 77 then	if screen_77()==1	then	return 1	end
	elseif screen == 1  then	if screen_01()==1	then	return 1	end		
	end
end

--ϵͳ���� �û������������ִ�д˻ص����� state  ����״̬��0�ɿ���1���£�2������ѹ 
function on_press(state,x,y)
	--�����������ܣ�һ��ʱ���޲�����������ʱ�ӻ��棬����
	--������ʱ���������޲�����ʱ��
	if state==1   --������Ļ�����¿�ʼ��ʱ
	then
		stop_timer(0) --���ƴ����� 60���޴���ʱ����Ļ�䰵
		start_timer(0,60000,1,1)
		set_backlight(100)
		
		time2 = 10000--���� ������ 10������ ������ ����һ�� ��ѯ����
		stop_timer(1)
		start_timer(1,time2,1,0)	
	
	 	stop_timer(3) --���Ʋ���ģʽ���Ͳ��ַ����
 		start_timer(3,time4,1,0)	

		Touch_over = 0--���¹��������������������
	end
	
	if Save_screen == 0x55 and Save_show == 0x55--ֻ����ģ������״̬���Ż�ִ������
	then
		local cur_screen = get_current_screen() 
	
		if cur_screen == 44  and (x >= 50 and x <= 278) and (y >= 50 and y <= 254)
		then	
			local cur_rgb =  get_pixel(x, y)
			
			draw_select_x = x - 8
			draw_select_y = y - 8
			
			current_x = x
			current_y = y
			
			select_rgb = cur_rgb
			
			TiaoGuang_new()--���͵�������

			redraw()--�����ͼ��ʵʱ��ʾ��ǰѡ����ɫ
		end
	end
end

-- ϵͳ���� �л�����ʱ�Զ��ص�
function on_screen_change(screen)
	last_sreen=current_screen                                           --������һ�εĻ���ID
	current_screen=screen                                               --���浱ǰ����IDend
end

function screen_00()
	screen = screen_t
	control = control_t
	value = value_t
	
	local effect = 0xC4
	
	if control==15 or control==16 
	then
		if control==15 and value==1
		then
			xp = get_value(0,26)
			if xp > 0
			then
				xp = xp -1
			end
			set_value(0,26,xp)
			
		elseif control==15 and value==0
		then
			return 1
		elseif control==16 and value==1
		then
			xp = get_value(0,26)
			if xp < xp_num
			then
				xp = xp + 1
			end
			set_value(0,26,xp)
			
		elseif control==16 and value==0
		then
			return 1
		end
		
		if get_value(0,12) == 0--Ԥ��Ч��
		then
			effect = 0xC4	
		elseif get_value(0,12) == 1--SD��Ч��
		then
			effect = 0xa3				
		end
	
		if xp == 0
		then
			set_text(0,4,"UCS1903")
			Send_cmd(effect,0,0,0,0,0,0,0,0)		
		elseif xp == 1
		then
			set_text(0,4,"DMX 250K")
			Send_cmd(effect,10,0,0,0,0,0,0,0)		
		elseif xp == 2
		then
			set_text(0,4,"DMX 500K")
			Send_cmd(effect,11,0,0,0,0,0,0,0)		
		elseif xp == 3
		then
			set_text(0,4,"GS851X")
			Send_cmd(effect,23,0,0,0,0,0,0,0)		
		elseif xp == 4
		then
			set_text(0,4,"TM1814")
			Send_cmd(effect,17,0,0,0,0,0,0,0)		
		elseif xp == 5
		then
			set_text(0,4,"TM1914")
			Send_cmd(effect,8,0,0,0,0,0,0,0)		
		elseif xp == 6
		then
			set_text(0,4,"UCSX603_T")
			Send_cmd(effect,14,0,0,0,0,0,0,0)		
		elseif xp == 7
		then
			set_text(0,4,"UCS2603")
			Send_cmd(effect,30,0,0,0,0,0,0,0)		
		elseif xp == 8
		then
			set_text(0,4,"UCS5/8603")
			Send_cmd(effect,15,0,0,0,0,0,0,0)		
		elseif xp == 9
		then
			set_text(0,4,"UCS8904")
			Send_cmd(effect,20,0,0,0,0,0,0,0)		
		elseif xp == 10
		then
			set_text(0,4,"UCS9812")
			Send_cmd(effect,26,0,0,0,0,0,0,0)		
		elseif xp == 11
		then
			set_text(0,4,"UCS7604")
			Send_cmd(effect,33,0,0,0,0,0,0,0)		
		elseif xp == 12
		then
			set_text(0,4,"UCS7804")
			Send_cmd(effect,31,0,0,0,0,0,0,0)		
		elseif xp == 13
		then
			set_text(0,4,"SM16212")
			Send_cmd(effect,32,0,0,0,0,0,0,0)		
		elseif xp == 14
		then
			set_text(0,4,"SM16713_A")
			Send_cmd(effect,40,0,0,0,0,0,0,0)		
		elseif xp == 15
		then
			set_text(0,4,"SM16713_B")
			Send_cmd(effect,41,0,0,0,0,0,0,0)		
		elseif xp == 16
		then
			set_text(0,4,"SM16713_C")
			Send_cmd(effect,42,0,0,0,0,0,0,0)		
		elseif xp == 17
		then
			set_text(0,4,"SM16714")
			Send_cmd(effect,21,0,0,0,0,0,0,0)		
		elseif xp == 18
		then
			set_text(0,4,"SM16716")
			Send_cmd(effect,1,0,0,0,0,0,0,0)		
		elseif xp == 19
		then
			set_text(0,4,"SM16803")
			Send_cmd(effect,27,0,0,0,0,0,0,0)		
		elseif xp == 20
		then
			set_text(0,4,"SM16804")
			Send_cmd(effect,28,0,0,0,0,0,0,0)		
		elseif xp == 21
		then
			set_text(0,4,"SM16813")
			Send_cmd(effect,22,0,0,0,0,0,0,0)		
		elseif xp == 22
		then
			set_text(0,4,"WS2816")
			Send_cmd(effect,25,0,0,0,0,0,0,0)		
		elseif xp == 23
		then
			set_text(0,4,"LPD6803")
			Send_cmd(effect,3,0,0,0,0,0,0,0)		
		elseif xp == 24
		then
			set_text(0,4,"HW1002")
			Send_cmd(effect,50,0,0,0,0,0,0,0)		
		elseif xp == 25
		then
			set_text(0,4,"HW1603_1")
			Send_cmd(effect,51,0,0,0,0,0,0,0)		
		elseif xp == 26
		then
			set_text(0,4,"HW1603_2")
			Send_cmd(effect,52,0,0,0,0,0,0,0)		
		elseif xp == 27
		then
			set_text(0,4,"HW1603_3")
			Send_cmd(effect,53,0,0,0,0,0,0,0)		
		elseif xp == 28
		then
			set_text(0,4,"KW5603A")
			Send_cmd(effect,34,0,0,0,0,0,0,0)		
		elseif xp == 29
		then
			set_text(0,4,"KW5604")
			Send_cmd(effect,35,0,0,0,0,0,0,0)		
		elseif xp == 30
		then
			set_text(0,4,"KW5603_T")
			Send_cmd(effect,36,0,0,0,0,0,0,0)	
		elseif xp == 31
		then
			set_text(0,4,"KW5604_T")
			Send_cmd(effect,37,0,0,0,0,0,0,0)
		elseif xp == 32
		then
			set_text(0,4,"QS2633")
			Send_cmd(effect,38,0,0,0,0,0,0,0)
		elseif xp == 33
		then
			set_text(0,4,"QS2639")
			Send_cmd(effect,39,0,0,0,0,0,0,0)
		elseif xp == 34
		then
			set_text(0,4,"WS2814")
			Send_cmd(effect,60,0,0,0,0,0,0,0)
		elseif xp == 35
		then
			set_text(0,4,"MT1885")
			Send_cmd(effect,61,0,0,0,0,0,0,0)
		end
		return 1
	elseif control==15 or control==16 and value==0
	then
		return 1
	-----------SD��Ч��  �л���Ŀ
	elseif control==8 and value==1
	then
		ss = get_text(0,6)--�õ��ַ���
		local zz=0
		local xx=0
		--ȡ���ִ����е�����
		for zz in string.gmatch(ss,"%d+")
		do
			xx = zz
		end	

		xx = tonumber(xx)

		if	xx >1
		then
			xx = xx -1
		end	

		if get_value(0,12) == 0--���� 
		then
			Send_cmd(0xc2,xx-1,0,0,0,0,0,0,0)	
		elseif get_value(0,12) == 1--SD
		then
			Send_cmd(0xa2,xx-1,0,0,0,0,0,0,0)		
		end		

		ss = string.format("Mode%d",xx)	
		set_text(0,6,ss)
		
		return 1
	elseif control==8 and value==0
	then
		return 1
	-----------SD��Ч��  �л���Ŀ
	elseif control==9 and value==1
	then
		ss = get_text(0,6)--�õ��ַ���
		local zz=0
		local xx=0
		--ȡ���ִ����е�����
		for zz in string.gmatch(ss,"%d+")
		do
			xx = zz
		end	

		xx = tonumber(xx)
		xx = xx +1
		
		if get_value(0,12) == 0--���� 
		then
			if	xx >22
			then
				xx=1
			end	
			Send_cmd(0xc2,xx-1,0,0,0,0,0,0,0)	
		elseif get_value(0,12) == 1--SD
		then
			if	xx >32
			then
				xx=1
			end	
			Send_cmd(0xa2,xx-1,0,0,0,0,0,0,0)		
		end		

		ss = string.format("Mode%d",xx)	
		set_text(0,6,ss)
	
		return 1
	elseif control==9 and value==0
	then
		return 1
	------------SD��Ч�� �л��ٶ�
	elseif control==10 and value==1
	then

		ss = get_text(0,7)--�õ��ַ���
		local zz=0
		local xx=0
		--ȡ���ִ����е�����
		for zz in string.gmatch(ss,"%d+")
		do
			xx = zz
		end	

		xx = tonumber(xx)

		if	xx >1
		then
			xx = xx -1
		end	

		if get_value(0,12) == 0--���� 
		then
			Send_cmd(0xc3,xx,0,0,0,0,0,0,0)	
		elseif get_value(0,12) == 1--SD
		then
			Send_cmd(0xa4,xx,0,0,0,0,0,0,0)		
		end		

		ss = string.format("Speed%d",xx)	
		set_text(0,7,ss)
		
		return 1
	elseif control==10 and value==0
	then
		return 1
	------------SD��Ч�� �л��ٶ�
	elseif control==11 and value==1
	then
		ss = get_text(0,7)--�õ��ַ���
		local zz=0
		local xx=0
		--ȡ���ִ����е�����
		for zz in string.gmatch(ss,"%d+")
		do
			xx = zz
		end	

		xx = tonumber(xx)

		if	xx <16
		then
			xx = xx +1
		end	

		if get_value(0,12) == 0--���� 
		then
			Send_cmd(0xc3,xx,0,0,0,0,0,0,0)	
		elseif get_value(0,12) == 1--SD
		then
			Send_cmd(0xa4,xx,0,0,0,0,0,0,0)		
		end		

		
		ss = string.format("Speed%d",xx)	
		set_text(0,7,ss)
		
		return 1
	elseif control==11 and value==0
	then
		return 1
	------------�л�SD��Ч��������Ч��
	elseif control==12 and value==1 --SDЧ��
	then
		if SD_Exist == 0x55--SD������
		then
			set_value(0,12,1)
			Send_cmd(0xa1,0x00,0,0,0,0,0,0,0)

			if get_language() == 0 
			then
				set_text(0,17,"SDЧ��")
			elseif get_language() == 1
			then
				set_text(0,17,"SD")
			end
			set_fore_color(0,17,0x7ff)
		else
			set_value(0,12,0)

			if get_language() == 0 
			then
				set_text(0,17,"Ԥ��Ч��")
			elseif get_language() == 1
			then
				set_text(0,17,"Default")
			end	
			set_fore_color(0,17,0xffff)	
		end
		return 1
	elseif control==12 and value==0 --����Ч��
	then
		Send_cmd(0xc1,0x00,0,0,0,0,0,0,0)	
		set_value(0,12,0)	

		if get_language() == 0 
		then
			set_text(0,17,"Ԥ��Ч��")
		elseif get_language() == 1
		then
			set_text(0,17,"Default")
		end		

		set_fore_color(0,17,0xffff)	
		return 1
	 -----------�л� 3ͨ����4ͨ��
	 -----�л� 3ͨ����4ͨ��
	elseif control==14 and value==1 --4ͨ��
	then
		if get_value(0,12) == 0--��������Ч��ʱ
		then
			Send_cmd(0xc5,4,0,0,0,0,0,0,0)		

			if get_language() == 0 
			then
				set_text(0,19,"4ͨ��")
			elseif get_language() == 1
			then
				set_text(0,19,"4-channel")
			end	
			set_fore_color(0,19,0x7ff)  
		elseif get_value(0,12) == 1--����SD��Ч��ʱ�������һ����ʾ
		then
			set_value(0,14,0)

			if get_language() == 0--����
			then
				set_text(36,2,"�ù���ֻ���Ԥ��Ч����")	
			elseif get_language() == 1--Ӣ��
			then
				set_text(36,2,"this function just for default effects��")	
			end
			
			change_screen(36)--��ʾ��оƬû��д��������			
		end
		return 1
	elseif control==14 and value==0 --3ͨ��
	then
		if get_value(0,12) == 0--��������Ч��ʱ
		then
			Send_cmd(0xc5,3,0,0,0,0,0,0,0)		

			if get_language() == 0 
			then
				set_text(0,19,"3ͨ��")
			elseif get_language() == 1
			then
				set_text(0,19,"3-channel")
			end		
			set_fore_color(0,17,0xffff)	
		elseif get_value(0,12) == 1--����SD��Ч��ʱ�������һ����ʾ
		then
			set_value(0,14,1)

			if get_language() == 0--����
			then
				set_text(36,2,"�ù���ֻ���Ԥ��Ч����")	
			elseif get_language() == 1--Ӣ��
			then
				set_text(36,2,"this function just for default effects��")	
			end
			change_screen(36)--��ʾ��оƬû��д��������		
		end	
		return 1
	------------SD��Ч�� �л������Խ��� ���� ������ͣ״̬
	elseif control==13 and value==1
	then
		--������Ĭ���Ƕ�̬���⣬ֱ����ʾ�Ķ��Ƕ�̬����Ĳ���
	
		if Save_screen == 0x33 --˵������� ��̬����Ľ���  
		then
			set_value(44,2,data[3])--ͨ����
			
			set_value(44,25,0)--�����Ƕ�̬����
			
			set_value(44,22,0)--����Ǿ�׼����
			
			rr = data[5]
			gg = data[6]
			bb = data[7]
			ww = data[8]
			nw = data[9]
			aw = data[10]

			set_visiable(44,15,0)--����
			set_value(44,21,0)--����
			
			set_visiable(44,16,1)--��ʾ
			set_visiable(44,17,1)--��ʾ
			set_visiable(44,19,1)--��ʾ

			set_visiable(44,31,1)--��ʾ
			set_visiable(44,32,1)--��ʾ
			set_visiable(44,33,1)--��ʾ
			set_visiable(44,34,1)--��ʾ
			set_visiable(44,35,1)--��ʾ
			set_visiable(44,36,1)--��ʾ
		
			set_value(44,16,rr)		
			set_value(44,17,gg)			
			set_value(44,19,bb)					
			set_value(44,5,ww)			
			set_value(44,7,nw)		
			set_value(44,9,aw)
		end
		
		if Save_screen == 0x55 --��̬����ʱ 
		then
			if get_value(0,12) == 0--����Ч��
			then
				Send_cmd(0xc1,0x55,0,0,0,0,0,0,0)	
			else
				Send_cmd(0xa1,0x55,0,0,0,0,0,0,0)	
			end
		end
		
		return 1
	elseif control==13 and value==0
	then
		return 1
	------------SD��Ч�� �л������Խ��� ���� ������ͣ״̬
	elseif control==18 and value==1
	then
		if get_value(0,12) == 0--����Ч��
		then
			Send_cmd(0xc1,0x55,0,0,0,0,0,0,0)	
		else
			Send_cmd(0xa1,0x55,0,0,0,0,0,0,0)	
		end
		
		change_screen(37)
		return 1
	elseif control==18 and value==0
	then
		return 1
	-----------ѭ������
	elseif control==21 and value==1 --ѭ��
	then
		Send_cmd(0xa5,0x55,0,0,0,0,0,0,0)		

		if get_language() == 0 
		then
			set_text(0,22,"ѭ��")
		elseif get_language() == 1
		then
			set_text(0,22,"Cycle")
		end	
		
		return 1
	elseif control==21 and value==0 --��ѭ��
	then
		Send_cmd(0xa5,0x00,0,0,0,0,0,0,0)		

		if get_language() == 0 
		then
			set_text(0,22,"��ѭ��")
		elseif get_language() == 1
		then
			set_text(0,22,"No Cycle")
		end	

		return 1
	elseif control==25 and value==1 --ѭ��
	then
		change_screen(57)
		return 1
	elseif control==25 and value==0 --��ѭ��
	then
		return 1
	end
end
--���¹̼�����
function screen_01()
	screen = screen_t
	control = control_t
	value = value_t
	if control==1 and value==1 
	then                      
		if get_language() == 0--����
		then
			set_text(1,5,"������...")
		elseif get_language() == 1--Ӣ��
		then
			set_text(1,5,"Updating...")
		end
		
		Send_cmd(0xef,0,0,0,0,0,0,0,0)	
		return 1
	elseif control==1 and value==0
	then
		return 1
	end
end
--���� дַ ��ť
function screen_02()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==5 and value==1
	then
		DMX_add_param = 0x33
		
		set_text(38,2,"")--��������
		set_text(38,8,"")

		if secret_1 == 0x00--��һ�ε��������ʱ
		then
			change_screen(38)
		else
			--change_screen(3)
			change_screen(29)
		end
		return 1
	elseif control==5 and value==0
	then
		return 1
	
	--���ò��� ��ť	
	elseif  control==7 and value==1
	then
		DMX_add_param = 0x55
		set_text(38,2,"")--��������
		set_text(38,8,"")
		
		if secret_1 == 0x00--��һ�ε��������ʱ
		then
			change_screen(38)
		else
			change_screen(29)
		end		
		return 1
	elseif control==7 and value==0
	then
		return 1
	
	--����Ч��
	elseif  control==6 and value==1
	then
		change_screen(4)
		return 1
	elseif  control==6 and value==0
	then
		return 1
	
	--����Ч��
	elseif  control==8 and value==1
	then
		test_flash = 0x55
		change_screen(19)
		return 1
	elseif  control==8 and value==0
	then
		return 1
	
	--����Ч��
	elseif  control==9 and value==1
	then
		change_screen(37)
		return 1
	elseif  control==9 and value==0
	then
		return 1
	end
end	
	
function screen_03()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control == 11 and value == 1
	then
		qh_chip = 0x33
		change_screen(29)
		return 1
	elseif control == 11 and value ==0
	then
		return 1
	elseif control == 14 and value == 1
	then
		qh_chip = 0
		change_screen(2)
		return 1
	elseif control == 14 and value == 0
	then
		return 1
	end	
	
	if control == 13 and value == 1
	then
		set_value(4,3,get_value(3,10))
		set_value(4,7,0)
		
		change_screen(4)
		return 1
	elseif control == 13 and value ==0
	then
		return 1
	end
	
	if get_value(3,25)==1
	then 
		tongyi = 0x55
		if	get_value(3,23)~=0	then set_value(3,23,0) chongfu_ch = 0 end
	elseif get_value(3,25)==0 and tongyi == 0x55
	then	
		tongyi = 0
	end
	

	--ͳһ��ַ
	if control==25 and value==1
	then
		set_value(3,23,0)--���ÿؼ���ֵ	
			
		tongyi = 0x55
		chongfu_ch = 0
		return 1
	elseif control==25 and value==0
	then
		set_value(3,23,0)--���ÿؼ���ֵ	
		
		tongyi = 0
		chongfu_ch = 0
		return 1
	elseif control==26 and value==1
	then
		return 1
	elseif control==26 and value==0
	then
		return 1
	
	--����дַ����	
	--��ʼͨ��
	elseif control==4 and value==1
	then
		start_ch = get_value(3,9) 
		if start_ch >1 
		then
			start_ch = start_ch - 1--�ı�ؼ���ֵ 
		end	 
		set_value(3,9,start_ch)--���ÿؼ���ֵ		
		return 1
	elseif control==4 and value==0
	then
		return 1
	elseif control==5 and value==1
	then
		start_ch = get_value(3,9) 
		if start_ch <4096 
		then
			start_ch = start_ch + 1--�ı�ؼ���ֵ 
		end	 
		set_value(3,9,start_ch)--���ÿؼ���ֵ		
		return 1
	elseif control==5 and value==0
	then
		return 1
		
	--���ͨ��
	elseif control==6 and value==1
	then
		jiange_ch = get_value(3,10) 
		if jiange_ch >0 
		then
			jiange_ch = jiange_ch - 1--�ı�ؼ���ֵ 
		end	 
		set_value(3,10,jiange_ch)--���ÿؼ���ֵ		
		return 1
	elseif control==6 and value==0
	then
		return 1
	elseif control==7 and value==1
	then
		jiange_ch = get_value(3,10) 
		if jiange_ch <255
		then
			jiange_ch = jiange_ch + 1--�ı�ؼ���ֵ 
		end	 
		set_value(3,10,jiange_ch)--���ÿؼ���ֵ		
		return 1
	elseif control==7 and value==0
	then
		return 1
	
	--�ظ�д��
	elseif control==21 and value==1
	then
		chongfu_ch = get_value(3,23) 
		if chongfu_ch >0
		then
			chongfu_ch = chongfu_ch - 1--�ı�ؼ���ֵ 
		end	 
		set_value(3,23,chongfu_ch)--���ÿؼ���ֵ		
		return 1
	elseif control==21 and value==0
	then
		return 1
	elseif control==22 and value==1
	then
		chongfu_ch = get_value(3,23) 
		if chongfu_ch <2047
		then
			chongfu_ch = chongfu_ch + 1--�ı�ؼ���ֵ 
		end	 
		set_value(3,23,chongfu_ch)--���ÿؼ���ֵ		
		return 1
	elseif control==22 and value==0
	then
		return 1

	--д��
	elseif control==12 and value==1
	then
		if get_text(3,8) == "UCS512-KL"
		then
			set_value(3,12,0)

			if get_language() == 0--����
			then
				set_text(65,7,"UCS512-KL����ȷ��")	
				set_text(65,2,"�Ƿ�رո�оƬ���Զ�д�빦�ܣ�")	
			elseif get_language() == 1--Ӣ��
			then
				set_text(65,7,"UCS512-KL Parameter confirmation")	
				set_text(65,2,"Shutting down automatic coding��")	
			end	
			change_screen(65)--
		elseif get_text(3,8) == "UCS512-KH"
		then
			set_value(3,12,0)

			if get_language() == 0--����
			then
				set_text(65,7,"UCS512-KH����ȷ��")	
				set_text(65,2,"�Ƿ�رո�оƬ���Զ�д�빦�ܣ�")	
			elseif get_language() == 1--Ӣ��
			then
				set_text(65,7,"UCS512-KH Parameter confirmation")	
				set_text(65,2,"Shutting down automatic coding��")	
			end	
			change_screen(65)--
		else
		
			if get_language() == 0--����
			then
				set_text(3,2,"����дַ")
			elseif get_language() == 1--Ӣ��
			then
				set_text(3,2,"Writing")
			end
				
			if GSTY ~= 0x55
			then
				--����дַ����
				local write_addr={}  
			
				write_addr[0] = 0xc3

				write_addr[1] = 0xff --UID
				write_addr[2] = 0xff	
				write_addr[3] = 0xff	
				write_addr[4] = 0xff	
				
				write_addr[5] = 0xc6 --������

				start_ch = get_value(3,9)
				jiange_ch = get_value(3,10)
				
				chongfu_ch = get_value(3,23)

				sel_chip = dmx_ic_Sel()

				if get_value(3,19) == 0 and get_value(3,20) == 1 --���յ���д
				then
					if get_text(3,8)~="GS8523" and get_text(3,8)~="GS8524" and get_text(3,8)~="GS8526"
					then
						start_ch = (start_ch-1)*jiange_ch + 1;
					end
				
					write_addr[6] = 0x00	
					write_addr[7] = math.modf(start_ch/256)	
					write_addr[8] = math.modf(start_ch%256)
				else --����ͨ��д
					write_addr[6] = 0x00	
					write_addr[7] = math.modf(start_ch/256)	
					write_addr[8] = math.modf(start_ch%256)
				end
				
				--���ͨ��
				write_addr[9] = jiange_ch

				--оƬ�ͺ�
				write_addr[10] = sel_chip
				
				--�ظ�д��
				write_addr[11] = math.modf(chongfu_ch/256)	
				write_addr[12] = math.modf(chongfu_ch%256)	
				
				--ͳһ��ַ
				write_addr[13] = tongyi	

				--дַ����
				write_addr[14] = get_value(3,26) * 85

				for i=15,18 do
					write_addr[i] = 0x00
				end

				local check_sum=0	
				for i=1,18 do
					check_sum = check_sum  + write_addr[i]
				end

				check_sum = math.modf(check_sum%256)	
				check_sum = Xor(check_sum,0x39)
			
				write_addr[18]	= check_sum
				write_addr[19] = 0xca	
			
				uart_send_data(write_addr) --��������
			
			else
				start_ch = get_value(3,9)--��ʼͨ�� 
				
				if get_value(3,19) == 0 and get_value(3,20) == 1 --���յ���д
				then
					start_ch = (start_ch-1)*jiange_ch + 1;
					
					tmp_dat[7] = math.modf(start_ch/256)	
					tmp_dat[8] = math.modf(start_ch%256)
				else --����ͨ��д
					
					tmp_dat[7] = math.modf(start_ch/256)	
					tmp_dat[8] = math.modf(start_ch%256)
				end
				
				tmp_dat[9] = get_value(3,10)--���ͨ��
				
				if get_text(3,8)=="GS8523"or get_text(3,8)=="GS8524" or get_text(3,8)=="GS8526"
				
				then
					Send_cmd(0xD4,0x06,tmp_dat[7],tmp_dat[8],tmp_dat[9],0,0,0,0)
				else
					Send_cmd(0xb4,tmp_dat[7],tmp_dat[8],tmp_dat[9],0,0,0,0,0)
				end
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")	
				end
				change_screen(40)
				
			end
			------------------------------
			--��ʾд��󣬵ƾߵ�״̬
			
			stop_timer(4)
			start_timer(4,time5,1,1)
			
			str = get_text(3,8)--�õ���ǰ��IC�ͺ�
			if str == "UCS512-A"
			then
			elseif str == "UCS512-B"
			then
			elseif str == "UCS512-C4"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ���׵�,\r\n����оƬ�����")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst white,\r\nother red")	
				end
				
				change_screen(40)
			elseif str == "UCS512-CN"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ���׵�,\r\n����оƬ�����")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(4,2,"Write ok,\r\nfirst white,\r\nother red")	
				end
				
				change_screen(40)
			elseif str == "UCS512-D"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ���׵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
				end

				change_screen(40)
			elseif str == "UCS512-E"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ���׵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
				end

				change_screen(40)
			elseif str == "UCS512-F"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ���׵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
				end
				
				change_screen(40)
			elseif str == "UCS512-G"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ���׵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
				end
				
				change_screen(40)
			elseif str == "UCS512-G-S"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��ַΪ1�����,\r\n��ַΪ�������̵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst address red,\r\nother address green")	
				end
				
				change_screen(40)
			elseif str == "UCS512-H"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ���׵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
				end
				
				change_screen(40)
			elseif str == "UCS512-H-S"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��ַΪ1�����,\r\n��ַΪ�������̵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst address red,\r\nother address green")	
				end
				
				change_screen(40)
			elseif str == "SM1651X-3CH"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ���׵�,\r\n����оƬ�����")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst white,\r\nother red")	
				end
				
				change_screen(40)
			elseif str == "SM1651X-4CH"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ���׵�,\r\n����оƬ�����")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst white,\r\nother red")	
				end
				
				change_screen(40)
			elseif str == "SM17512"
			then
				DMX_Status_page = 0x55

				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ���̵�,\r\n2S���л����ϵ��Լ���ɫ")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother green")	
				end
				
				change_screen(40)
			elseif str == "SM1752X"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ���̵�,\r\n4S���л����ϵ�Ĭ��̬")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother green")	
				end
				
				change_screen(40)
			elseif str == "SM17500"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ���̵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother green")	
				end

				change_screen(40)
			elseif str == "SM17500-S"
			then
				DMX_Status_page = 0x55
					
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ���̵�")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother green")
				end				

				change_screen(40)
			elseif str == "SM1852X"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ���̵�,\r\n4S���л����ϵ�Ĭ��̬")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother green")	
				end
				
				change_screen(40)
			elseif str == "TM512AB"
			then
			elseif str == "TM512AL"
			then
			elseif str == "TM512AC"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ���׵�,\r\n����оƬ�����")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst white,\r\nother red")	
				end

				change_screen(40)
			elseif str == "TM512AD"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ���׵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
				end
				
				change_screen(40)
			elseif str == "TM512AE"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ���׵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
				end

				change_screen(40)
			elseif str == "Hi512A0"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n����оƬ���׵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nall white")	
				end	

				change_screen(40)
			elseif str == "Hi512A0_Self"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n����оƬ���׵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nall white")	
				end	

				change_screen(40)
			elseif str == "Hi512A4"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ���̵�")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother green")	
				end

				change_screen(40)
			elseif str == "Hi512A6"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ���̵�")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother green")	
				end
				change_screen(40)
			elseif str == "Hi512D"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ���̵�")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother green")	
				end
				change_screen(40)
			elseif str == "GS8511"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")	
				end
				change_screen(40)
			elseif str == "GS8512"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")	
				end
				change_screen(40)
			elseif str == "GS8513"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")	
				end
				change_screen(40)
			elseif str == "GS8515"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")	
				end
				change_screen(40)
			elseif str == "GS8516"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")	
				end
				change_screen(40)
			elseif str == "GS8516B"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")	
				end
				change_screen(40)
			elseif str == "GS8525"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")	
				end
				change_screen(40)
			elseif str == "QED512P"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ���׵�,\r\n����оƬ�����")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst white,\r\nother red")	
				end
				change_screen(40)
			elseif str == "SM1952X"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ���̵�")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother green")	
				end
				change_screen(40)
			
			elseif str == "UCS512-KH" or str == "UCS512-KL" or str == "UCS512-K-Self"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ���׵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
				end
				
				change_screen(40)
			elseif str == "UCS512-KH-S" or str == "UCS512-KL-S"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��ַΪ1�����,\r\n��ַΪ�������̵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst address red,\r\nother address green")	
				end
				
				change_screen(40)
			elseif str == "UCS512-C1"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ���׵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
				end
				change_screen(40)
			elseif str == "KW512A"
			then
			
				DMX_Status_page = 0x55
				
			    if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n����оƬ���̵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nall Green")	
				end	
				
				change_screen(40)
			elseif str == "GS8523" or str == "GS8524" or str == "GS8526"
			then
				DMX_Status_page = 0x55
				
			    if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")	
				end	
				
				change_screen(40)
			elseif str == "SM522" or str == "SM18500P" or str == "SM18500PS" or str == "SM18500P-S" or str == "SM18500PS-S"
			then
				DMX_Status_page = 0x55
				
			    if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ�����,\r\n����оƬ���̵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst red,\r\nother green")	
				end	
				
				change_screen(40)
			end
		end
		return 1
	elseif control==12 and value==0
	then
		return 1
	-----------------------------
	--�л�����Ӧ��д��������
	elseif control==17 and value==1
	then
		--set_value(4,3,get_value(3,10))
		--set_value(4,7,0)
		
		str = get_text(3,8)--�õ���ǰ��IC�ͺ�
		if str == "UCS512-A"
		then
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������
		elseif str == "UCS512-B"
		then
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������
		elseif str == "UCS512-C4"
		then
			set_text(5,5,"UCS512-C4")
			change_screen(5)
			UCS512_param = 0x31	
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "UCS512-CN"
		then
			set_text(5,5,"UCS512-CN")
			change_screen(5)
			UCS512_param = 0x31	
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "UCS512-D"
		then
			set_text(5,5,"UCS512-D")
			change_screen(5)
			UCS512_param = 0x32	
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "UCS512-E"
		then
			set_text(10,17,"UCS512-E")
			change_screen(10)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "UCS512-F"
		then
			set_text(5,5,"UCS512-F")
			change_screen(5)
			UCS512_param = 0x33	
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "UCS512-G" 
		then
			set_text(45,5,"UCS512-G")
			change_screen(45)
			UCS512_param = 0x33	
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "UCS512-G-S" 
		then
			set_text(45,5,"UCS512-G-S")
			change_screen(45)
			UCS512_param = 0x33	
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "UCS512-H" 
		then
			set_text(47,5,"UCS512-H")
			change_screen(47)
			UCS512_param = 0x33	
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "UCS512-H-S" 
		then
			set_text(47,5,"UCS512-H-S")
			change_screen(47)
			UCS512_param = 0x33	
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "SM1651X-3CH"
		then
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������
		elseif str == "SM1651X-4CH"
		then
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������
		elseif str == "SM17512"
		then
			set_text(11,20,"SM17512")
			change_screen(11)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "SM1752X"
		then
			set_text(15,20,"SM1752X")
			change_screen(15)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "SM17500"
		then
			set_text(12,20,"SM17500")
			change_screen(12)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "SM17500-S"
		then
			set_text(12,20,"SM17500-S")
			change_screen(12)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "SM1852X"
		then
			set_text(24,20,"SM1852X")
			change_screen(24)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "TM512AB"
		then
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������
		elseif str == "TM512AL"
		then
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������
		elseif str == "TM512AC"
		then
			set_text(5,5,"TM512AC")
			change_screen(5)
			UCS512_param = 0x31	
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "TM512AD"
		then
			set_text(5,5,"TM512AD")
			change_screen(5)
			UCS512_param = 0x34	
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "TM512AE"
		then
			set_text(10,17,"TM512AE")
			change_screen(10)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "Hi512A0"
		then
			set_text(21,2,"Hi512A0")
			change_screen(21)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "Hi512A0_Self"
		then
			set_text(21,2,"Hi512A0_Self")
			change_screen(21)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "Hi512A4"
		then
			set_text(22,6,"Hi512A4")
			change_screen(22)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "Hi512A6"
		then
			set_text(23,27,"Hi512A6")
			change_screen(23)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "Hi512D"
		then
			set_text(16,27,"Hi512D")
			change_screen(16)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "GS8511"
		then
			set_text(28,27,"GS8511")
			change_screen(28)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "GS8512"
		then
			set_text(28,27,"GS8512")
			change_screen(28)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "GS8513"
		then
			set_text(28,27,"GS8513")
			change_screen(28)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "GS8515"
		then
			set_text(28,27,"GS8515")
			change_screen(28)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "GS8516"
		then
			set_text(49,30,"GS8516")
			change_screen(49)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "QED512P"
		then
			set_text(26,6,"QED512P")
			change_screen(26)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "SM1952X"
		then
			set_text(50,43,"SM1952X")
			change_screen(50)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "SM1952X"
		then
			set_text(50,43,"SM1952X")
			change_screen(50)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "UCS512-KH"
		then
			set_text(53,5,"UCS512-KH")
			change_screen(53)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "UCS512-KL"
		then
			set_text(55,5,"UCS512-KL")
			change_screen(55)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "UCS512-K-Self"
		then
			change_screen(30)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "UCS512-C1"
		then
			set_text(59,27,"UCS512-C1")
			change_screen(59)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "GS8516B"
		then
			set_text(60,30,"GS8516B")
			change_screen(60)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "GS8525"
		then
			set_text(62,30,"GS8525")
			change_screen(62)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "KW512A"
		then
			set_text(68,5,"KW512A")
			change_screen(68)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "GS8523" or  str == "GS8524" or  str == "GS8526"
		then
			set_text(70,30,str)
			change_screen(70)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
			
			Send_cmd(0xd4,0xAA,0,0,0,0,0,0,0)
		elseif str == "SM522" 
		then
			set_text(72,31,"SM522" )
			change_screen(72)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�		
		elseif str == "SM18500P"  or str == "SM18500P-S"
		then
			set_text(73,5,get_text(3,8))
			set_text(74,5,get_text(3,8))
			set_text(75,5,get_text(3,8))
			set_text(77,5,get_text(3,8))
			change_screen(73)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�	
		elseif str == "SM18500PS" or str == "SM18500PS-S"
		then
			set_text(76,5,get_text(3,8))
			set_text(74,5,get_text(3,8))
			set_text(75,5,get_text(3,8))
			set_text(77,5,get_text(3,8))
			change_screen(76)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�	
		end
			return 1	
	elseif control==17 and value==0
	then
		return 1
	elseif control==19 
	then
		set_value(3,19,1)
		set_value(3,20,0)
		
		if get_language() == 0--����
		then
			set_text(3,26,"��ʼͨ����")--�ֶ�	
		elseif get_language() == 1--Ӣ��
		then
			set_text(3,26,"Start Ch:")	
		end	
		return 1
	elseif control==20
	then
		set_value(3,19,0)
		set_value(3,20,1)
		
		if get_language() == 0--����
		then
			set_text(3,26,"��ʼ������")--�ֶ�	
		elseif get_language() == 1--Ӣ��
		then
			set_text(3,26,"Start Num:")	
		end	
		return 1
	end
end	

function screen_04()
	screen = screen_t
	control = control_t
	value = value_t
	if control==2 and value==1
	then
		jiange_ch = get_value(4,3) 
		if jiange_ch >1 
		then
			jiange_ch = jiange_ch - 1--�ı�ؼ���ֵ 
		end	 
		set_value(4,3,jiange_ch)--���ÿؼ���ֵ		
		return 1
	elseif control==2 and value==0
	then
		return 1
	elseif control==4 and value==1
	then
		jiange_ch = get_value(4,3) 
		if jiange_ch <255
		then
			jiange_ch = jiange_ch + 1--�ı�ؼ���ֵ 
		end	 
		set_value(4,3,jiange_ch)--���ÿؼ���ֵ		
		return 1
	elseif control==4 and value==0
	then
		return 1

	--�ֶ����ַ ��
	elseif control==6 and value==1
	then
		test_addr={}  
	
		test_addr[0] = 0xc3

		test_addr[1] = 0xff --UID
		test_addr[2] = 0xff	
		test_addr[3] = 0xff	
		test_addr[4] = 0xff	
		
		test_addr[5] = 0xc8 --������

		--���ͨ��
		jiange_ch = get_value(4,3)	
		test_addr[6] = jiange_ch 

		--��ǰ�ܵ��ĸ�����
		run_num=get_value(4,7)	
		if  run_num > 0
		then
			run_num = run_num - 1
		end		
		set_value(4,7,run_num)
		
		test_addr[7] = math.modf(run_num/256)--����
		test_addr[8] = math.modf(run_num%256)
		
		if get_value(4,21) == 0
		then
			test_addr[9] = 0x00--Ĭ�ϲ����ò��Թ켣
		else
			test_addr[9] = 0x55--���ò��Թ켣
		end
		
		--ָ��������
		test_addr[10] = 0xff
		test_addr[11] = 0xff	
		
		--ָ���˿�
		test_addr[12] = 0xff	

		auto_run = 0

		if get_language() == 0--����
		then
			set_text(4,13,"�� ʼ �� ��")	
		elseif get_language() == 1--Ӣ��
		then
			set_text(4,13,"Start Test")	
		end	

		if (get_text(0,4) == "DMX 500K") or (get_text(3,8) == "Hi512A0") or (get_text(3,8) == "Hi512A0_Self")
		then
			test_addr[13] = 0x55
		else
			test_addr[13] = 0x00	
		end
		
		for i=14,18 do
			test_addr[i] = 0x00
		end
	
		local check_sum = 0	
		for i=1,17 do
			check_sum = check_sum  + test_addr[i]
		end

		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		test_addr[18]	= check_sum
		test_addr[19] = 0xca	
	
		uart_send_data(test_addr) --��������

		set_value(4,10,0)

		return 1
	elseif control==6 and value==2
	then
		test_addr={}  
	
		test_addr[0] = 0xc3

		test_addr[1] = 0xff --UID
		test_addr[2] = 0xff	
		test_addr[3] = 0xff	
		test_addr[4] = 0xff	
		
		test_addr[5] = 0xc8 --������

		--���ͨ��
		jiange_ch = get_value(4,3)	
		test_addr[6] = jiange_ch 

		--��ǰ�ܵ��ĸ�����
		run_num=get_value(4,7)	
		if  run_num > 0
		then
			run_num = run_num - 1
		end		
		set_value(4,7,run_num)
		
		test_addr[7] = math.modf(run_num/256)--����
		test_addr[8] = math.modf(run_num%256)
		
		if get_value(4,21) == 0
		then
			test_addr[9] = 0x00--Ĭ�ϲ����ò��Թ켣
		else
			test_addr[9] = 0x55--���ò��Թ켣
		end
		
		--ָ��������
		test_addr[10] = 0xff
		test_addr[11] = 0xff	
		
		--ָ���˿�
		test_addr[12] = 0xff	

		auto_run = 0

		if get_language() == 0--����
		then
			set_text(4,13,"�� ʼ �� ��")	
		elseif get_language() == 1--Ӣ��
		then
			set_text(4,13,"Start Test")	
		end	

		if (get_text(0,4) == "DMX 500K") or (get_text(3,8) == "Hi512A0") or (get_text(3,8) == "Hi512A0_Self")
		then
			test_addr[13] = 0x55
		else
			test_addr[13] = 0x00	
		end
		
		for i=14,18 do
			test_addr[i] = 0x00
		end
	
		local check_sum = 0	
		for i=1,17 do
			check_sum = check_sum  + test_addr[i]
		end

		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		test_addr[18]	= check_sum
		test_addr[19] = 0xca	
	
		uart_send_data(test_addr) --��������

		set_value(4,10,0)

		return 1
	elseif control==6 and value==0
	then
		return 1

	--�޸������ ���Ͳ��Ե�ַ����
	elseif control==7 or control==21
	then
		test_addr={}  
	
		test_addr[0] = 0xc3

		test_addr[1] = 0xff --UID
		test_addr[2] = 0xff	
		test_addr[3] = 0xff	
		test_addr[4] = 0xff	
		
		test_addr[5] = 0xc8 --������

		--���ͨ��
		jiange_ch = get_value(4,3)	
		test_addr[6] = jiange_ch 

		--��ǰ�ܵ��ĸ�����
		run_num=get_value(4,7)
		if  run_num*jiange_ch > 3072
		then
			run_num = 0
		end		
		
		test_addr[7] = math.modf(run_num/256)--����
		test_addr[8] = math.modf(run_num%256)

		if get_value(4,21) == 0
		then
			test_addr[9] = 0x00--Ĭ�ϲ����ò��Թ켣
		else
			test_addr[9] = 0x55--���ò��Թ켣
		end

		--ָ��������
		test_addr[10] = 0xff
		test_addr[11] = 0xff	
		
		--ָ���˿�
		test_addr[12] = 0xff	

		if (get_text(0,4) == "DMX 500K") or (get_text(3,8) == "Hi512A0") or (get_text(3,8) == "Hi512A0_Self")
		then
			test_addr[13] = 0x55
		else
			test_addr[13] = 0x00	
		end
		
		for i=14,18 do
			test_addr[i] = 0x00
		end
	
		local check_sum = 0	
		for i=1,17 do
			check_sum = check_sum  + test_addr[i]
		end

		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		test_addr[18]	= check_sum
		test_addr[19] = 0xca	
	
		uart_send_data(test_addr) --��������
	
		return 1
		
	--�ֶ����ַ ��
	elseif control==8 and value==1
	then
		test_addr={}  
	
		test_addr[0] = 0xc3

		test_addr[1] = 0xff --UID
		test_addr[2] = 0xff	
		test_addr[3] = 0xff	
		test_addr[4] = 0xff	
		
		test_addr[5] = 0xc8 --������

		--���ͨ��
		jiange_ch = get_value(4,3)	
		test_addr[6] = jiange_ch 

		--��ǰ�ܵ��ĸ�����
		run_num=get_value(4,7)
		run_num=run_num+1	
		if  run_num*jiange_ch > 3072
		then
			run_num = 0
		end		
		set_value(4,7,run_num)
		
		test_addr[7] = math.modf(run_num/256)--����
		test_addr[8] = math.modf(run_num%256)

		if get_value(4,21) == 0
		then
			test_addr[9] = 0x00--Ĭ�ϲ����ò��Թ켣
		else
			test_addr[9] = 0x55--���ò��Թ켣
		end

		--ָ��������
		test_addr[10] = 0xff
		test_addr[11] = 0xff	
		
		--ָ���˿�
		test_addr[12] = 0xff	

		auto_run = 0

		if get_language() == 0--����
		then
			set_text(4,13,"�� ʼ �� ��")	
		elseif get_language() == 1--Ӣ��
		then
			set_text(4,13,"Start Test")	
		end

		if (get_text(0,4) == "DMX 500K") or (get_text(3,8) == "Hi512A0") or (get_text(3,8) == "Hi512A0_Self")
		then
			test_addr[13] = 0x55
		else
			test_addr[13] = 0x00	
		end
		
		for i=14,18 do
			test_addr[i] = 0x00
		end
	
		local check_sum = 0	
		for i=1,17 do
			check_sum = check_sum  + test_addr[i]
		end

		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		test_addr[18]	= check_sum
		test_addr[19] = 0xca	
	
		uart_send_data(test_addr) --��������

		set_value(4,10,0)

		return 1
	elseif control==8 and value==2
	then
		test_addr={}  
	
		test_addr[0] = 0xc3

		test_addr[1] = 0xff --UID
		test_addr[2] = 0xff	
		test_addr[3] = 0xff	
		test_addr[4] = 0xff	
		
		test_addr[5] = 0xc8 --������

		--���ͨ��
		jiange_ch = get_value(4,3)	
		test_addr[6] = jiange_ch 

		--��ǰ�ܵ��ĸ�����
		run_num=get_value(4,7)
		run_num=run_num+1	
		if  run_num*jiange_ch > 3072
		then
			run_num = 0
		end		
		set_value(4,7,run_num)
		
		test_addr[7] = math.modf(run_num/256)--����
		test_addr[8] = math.modf(run_num%256)

		if get_value(4,21) == 0
		then
			test_addr[9] = 0x00--Ĭ�ϲ����ò��Թ켣
		else
			test_addr[9] = 0x55--���ò��Թ켣
		end

		--ָ��������
		test_addr[10] = 0xff
		test_addr[11] = 0xff	
		
		--ָ���˿�
		test_addr[12] = 0xff	

		auto_run = 0

		if get_language() == 0--����
		then
			set_text(4,13,"�� ʼ �� ��")	
		elseif get_language() == 1--Ӣ��
		then
			set_text(4,13,"Start Test")	
		end

		if (get_text(0,4) == "DMX 500K") or (get_text(3,8) == "Hi512A0") or (get_text(3,8) == "Hi512A0_Self")
		then
			test_addr[13] = 0x55
		else
			test_addr[13] = 0x00	
		end
		
		for i=14,18 do
			test_addr[i] = 0x00
		end
	
		local check_sum = 0	
		for i=1,17 do
			check_sum = check_sum  + test_addr[i]
		end

		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		test_addr[18]	= check_sum
		test_addr[19] = 0xca	
	
		uart_send_data(test_addr) --��������

		set_value(4,10,0)

		return 1
	elseif control==8 and value==0
	then
		return 1

	 --���Ե�ַ �Զ����Ե�ַ
	elseif control==10 and value==1
	then
		auto_run = 0x55

		if get_language() == 0--����
		then
			set_text(4,13,"ͣ ֹ �� ��")	
		elseif get_language() == 1--Ӣ��
		then
			set_text(4,13,"Stop Test")	
		end
		
		return 1
	elseif control==10 and value==0
	then
		auto_run = 0

		if get_language() == 0--����
		then
			set_text(4,13,"�� ʼ �� ��")	
		elseif get_language() == 1--Ӣ��
		then
			set_text(4,13,"Start Test")	
		end
		return 1

	--�л�����һ��ҳ��
	elseif control==11 and value==1
	then
		change_screen(last_sreen)	
		return 1
	elseif control==11 and value==0
	then
		auto_run = 0
		buchang_ok = 0	
		set_value(4,12,0)
		return 1
	
	--��������ģʽ
	elseif control==12 and value==1
	then
		buchang_ok = 0x55
		return 1
	elseif control==12 and value==0
	then
		buchang_ok = 0
		return 1
	end
end

function screen_05()
	screen = screen_t
	control = control_t
	value = value_t
	if control==1 and value==1
	then
		if get_text(5,5) == "TM512AB"
		then
			change_screen(32)
		elseif get_text(5,5) == "TM512AL"
		then
			change_screen(32)
		elseif get_text(5,5) == "TM512AC"
		then
			change_screen(32)
		elseif get_text(5,5) == "TM512AD"
		then
			change_screen(32)
		elseif get_text(5,5) == "TM512AE"
		then
			change_screen(32)
		else
			change_screen(30)
		end
		return 1
	elseif control==1 and value==0
	then
		return 1
	
	elseif control==13 and value==1
	then
		set_text(5,15,"Setting")

		tmp_dat[6] = 0x00--оƬ��Ŀ Ĭ��512
		tmp_dat[7] = 0x02
		
		local ch_num = get_value(5,6)
		if ch_num==1 
		then
			tmp_dat[8] = 0xe6
		elseif ch_num==2
		then
			tmp_dat[8] = 0xa6
		elseif ch_num==3 
		then
			tmp_dat[8] = 0x26
		elseif ch_num==4 
		then
			tmp_dat[8] = 0x26
		else
			tmp_dat[8] = 0x26
		end	

		tmp_dat[9] = get_value(5,9)--R
		tmp_dat[10] = get_value(5,10)--G
		tmp_dat[11] = get_value(5,11)--B
		tmp_dat[12] = get_value(5,12)--W
		
		if get_text(5,5) == "UCS512-C4"--C4û�иò���
		then
			tmp_dat[13] = 0xd1
		else
			local no_singal = get_value(5,7)
			if no_singal ==0
			then
				tmp_dat[13] = 0xd1
			elseif no_singal ==1
			then
				tmp_dat[13] = 0xd2
			else
				tmp_dat[13] = 0xd1
			end
		end

		tmp_dat[14] = 0x00
		tmp_dat[15] = 0x00
		tmp_dat[16] = 0x00
		
		if UCS512_param == 0x31--C
		then
			tmp_dat[17] = 0x1c
			cmd_param = 0x02
		elseif UCS512_param == 0x32--D
		then
			tmp_dat[17] = 0x1d
			cmd_param = 0x03
		elseif UCS512_param == 0x33--F
		then	
			tmp_dat[17] = 0x19
			cmd_param = 0x0b
		elseif UCS512_param == 0x34--TM512AD
		then	
			tmp_dat[17] = 0x1d
			cmd_param = 0x03
		end
		
		tmp_dat[18] = 0x00	
		tmp_dat[19] = 0x00

		Send_param_cmd(cmd_param,tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],tmp_dat[13],tmp_dat[17],tmp_dat[19],0,0,0,0)
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		if UCS512_param == 0x31--C
		then
			if get_text(5,5) == "UCS512-C4"
			then
				DMX_Status_page = 0x55
			
				if get_language() == 0--����
				then
					set_text(40,2,"д�����ɹ���,\r\n����оƬ�����")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nall red")	
				end
			
				change_screen(40)
			elseif get_text(5,5) == "UCS512-CN"
			then
				DMX_Status_page = 0x55
			
				if get_language() == 0--����
				then
					set_text(40,2,"д�����ɹ���,\r\n����оƬ��ʾ�ϵ�������ɫ")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nall light power on light status")	
				end

				change_screen(40)
			elseif get_text(5,5) == "TM512AC"
			then
				DMX_Status_page = 0x55
			
				if get_language() == 0--����
				then
					set_text(40,2,"д�����ɹ���,\r\n����оƬ��ʾ�ϵ�������ɫ")
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nall light power on light status")	
				end
				
				change_screen(40)
			end
		elseif UCS512_param == 0x32--D
		then
			DMX_Status_page = 0x55
			
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ��ʾ�ϵ�������ɫ")
			elseif get_language() == 1--Ӣ��
			then
				set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother light power on light status")	
			end	
			
			change_screen(40)
		elseif UCS512_param == 0x33--F
		then	
			DMX_Status_page = 0x55
			
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ��ʾ�ϵ�������ɫ")
			elseif get_language() == 1--Ӣ��
			then
				set_text(40,2,"Write ok,\r\nall light power on light status")	
			end	
			
			change_screen(40)
		elseif UCS512_param == 0x34--TM512AD
		then	
			DMX_Status_page = 0x55
			
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ��ʾ�ϵ�������ɫ")
			elseif get_language() == 1--Ӣ��
			then
				set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother light power on light status")	
			end	
			
			change_screen(40)
		end
		
		return 1	
	elseif control==13 and value==0
	then
		return 1		

	--����д�����
	elseif control==17 and value==1
	then
		set_text(3,8,get_text(5,5))		
		change_screen(3)
		
		DMX_add_param = 0x33
		
		return 1
	elseif control==17 and value==0
	then
		return 1

	--�ı��ϵ�������ɫ UCS512-C 5
	elseif control >= 9 and control <= 11
	then
		rr = get_value(5,9)
		gg = get_value(5,10)
		bb = get_value(5,11)
		
		rr = ((rr>>3)<<11)&0xf800
		gg = ((gg>>2)<<5)&0x07e0
		bb = (bb>>3)&0x001f
	
		draw_pen_color = Or(rr,gg)
		draw_pen_color = Or(draw_pen_color,bb) 
		redraw() 
		
		return 1
	elseif  control == 19 and value==1
	then
		rr = get_value(5,9)
		gg = get_value(5,10)
		bb = get_value(5,11)
		ww = get_value(5,12)
		
		set_value(41,1,rr)
		set_value(41,2,gg)
		set_value(41,3,bb)
		set_value(41,4,ww)
		
		set_value(41,8,rr)
		set_value(41,9,gg)
		set_value(41,10,bb)
		set_value(41,11,ww)
		return 1
	elseif control == 19 and value==0
	then
		return 1

	--UCS512-C д�����Ľ���
	
	--����ͨ����
	elseif control==2 and value==1
	then
		if get_value(5,6) == 1
		then
			set_value(5,6,2)--���ÿؼ���ֵ	
		elseif get_value(5,6) == 2
		then
			set_value(5,6,3)--���ÿؼ���ֵ
		elseif get_value(5,6) == 3
		then
			set_value(5,6,4)--���ÿؼ���ֵ
		elseif get_value(5,6) == 4
		then
			set_value(5,6,1)--���ÿؼ���ֵ	
		end
		return 1
	elseif control==2 and value==0
	then
		return 1

	-- 5,7,16
	elseif control==7 and value==1
	then	
		if get_text(5,5) == "UCS512-C4"
		then
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������
			set_value(5,7,0)
			return 1
		end
	
		if get_language() == 0
		then
			set_text(5,16,"�ָ��ϵ�״̬")
		elseif get_language() == 1
		then
			set_text(5,16,"Restore light status")
		end
		return 1
	elseif control==7 and value==0
	then
		if get_text(5,5) == "UCS512-C4"
		then
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������
			set_value(5,7,1)
			return 1
		end
	
		if get_language() == 0
		then
			set_text(5,16,"�������һ֡")
		elseif get_language() == 1
		then
			set_text(5,16,"Save last frame")
		end
		return 1	

	elseif control==14 and value==1
	then
		if UCS512_param == 0x31
		then
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������
			return 1
		elseif UCS512_param == 0x32
		then
			set_text(9,2,"UCS512-D")
			change_screen(9)
		elseif UCS512_param == 0x33
		then
			set_text(9,2,"UCS512-F")
			change_screen(9)
		elseif UCS512_param == 0x34
		then
			set_text(9,2,"TM512AD")
			change_screen(9)
		end	
		return 1
	elseif control==14 and value==0
	then
		return 1
	end
end

function screen_06()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==1--UCS512-C
	then
		set_visiable(5,14,0)--�޵�������	

		UCS512_param = 0x31	

		set_text(5,5,"UCS512-C")
		return 1
	elseif control==2--UCS512-D
	then
		set_visiable(5,14,1)--�е�������	

		set_visiable(9,4,0)	
		set_visiable(9,5,0)		

		UCS512_param = 0x32 	
		set_text(5,5,"UCS512-D")

		return 1	
	elseif control==3--UCS512-E
	then
		set_text(10,17,"UCS512-E")
		return 1		
	elseif control==4--UCS512-F
	then
		set_enable(5,6,0)--���ֶ�����

		set_visiable(5,14,1)--�е�������			

		set_visiable(9,4,1)	
		set_visiable(9,5,1)		

		UCS512_param = 0x33	

		set_text(5,5,"UCS512-F")
		return 1	
	elseif control==5--GS851X
	then
		set_text(18,27,"GS851X")
		set_text(28,27,"GS851X")
		return 1	
	elseif control==6--Hi512D
	then
		set_text(16,27,"Hi512D")
		return 1
	elseif control==7--SM17512
	then
		set_text(11,20,"SM17512")
		return 1
	elseif control==8--SM1752X
	then
		set_text(15,20,"SM1752X")
		return 1	
	elseif control==9--SM17500
	then
		set_text(12,20,"SM17500")
		return 1	
	elseif control==11--QED512P
	then
		set_text(26,6,"QED512P")
		return 1		
	elseif control==12--SM1852X
	then
		set_text(24,20,"SM1852X")
		return 1		
	elseif control==13--TM512AC
	then
		set_visiable(5,14,0)--�޵�������	

		UCS512_param = 0x31	

		set_text(5,5,"TM512AC")
		return 1	
	elseif control==14--TM512AD
	then
		set_visiable(5,14,1)--�е�������	

		set_visiable(9,4,0)	
		set_visiable(9,5,0)		

		UCS512_param = 0x34	

		set_text(5,5,"TM512AD")
		return 1	
	elseif control==15--Hi512A0
	then
		set_text(21,2,"Hi512A0")
		return 1	
	elseif control==16--Hi512A4
	then
		set_text(22,6,"Hi512A4")
		return 1	
	elseif control==17--Hi512A6
	then
		set_text(23,27,"Hi512A6")
		return 1		
	end	
end

function screen_07()
	screen = screen_t
	control = control_t
	value = value_t

	if control==1 and value==1
	then
		set_text(3,8,'UCS512-A/B')		
		change_screen(last_sreen)
		return 1
	elseif control==1 and value==0
	then
		return 1
	elseif control==2 and value==1
	then
		set_text(3,8,'UCS512-C')		
		change_screen(last_sreen)
		return 1
	elseif control==2 and value==0
	then
		return 1
	elseif control==3 and value==1
	then
		set_text(3,8,'UCS512-D')		
		change_screen(last_sreen)
		return 1
	elseif control==3 and value==0
	then
		return 1
	elseif control==4 and value==1
	then
		set_text(3,8,'QED512P')		
		change_screen(last_sreen)
		return 1
	elseif control==4 and value==0
	then
		return 1
	elseif control==5 and value==1
	then
		set_text(3,8,'UCS512-F')		
		change_screen(last_sreen)
		return 1
	elseif control==5 and value==0
	then
		return 1
	elseif control==6 and value==1
	then	
		set_text(28,27,'GS851X')	
		change_screen(28)
		return 1
	elseif control==6 and value==0
	then
		return 1
	elseif control==7 and value==1
	then
		set_text(3,8,'SM1651X-3CH')		
		change_screen(last_sreen)
		return 1
	elseif control==7 and value==0
	then
		return 1
	elseif control==8 and value==1
	then
		set_text(3,8,'SM1651X-4CH')		
		change_screen(last_sreen)
		return 1
	elseif control==8 and value==0
	then
		return 1
	elseif control==9 and value==1
	then
		set_text(3,8,'SM17512')		
		change_screen(last_sreen)
		return 1
	elseif control==9 and value==0
	then
		return 1
	elseif control==10 and value==1
	then
		set_text(3,8,'SM1752X')		
		change_screen(last_sreen) 
		return 1
	elseif control==10 and value==0
	then
		return 1
	elseif control==11 and value==1
	then
		set_text(3,8,'SM17500')		
		change_screen(last_sreen)
		return 1
	elseif control==11 and value==0
	then
		return 1
	elseif control==12 and value==1
	then
		set_text(3,8,'Hi512D')		
		change_screen(last_sreen)
		return 1
	elseif control==12 and value==0
	then
		return 1
	elseif control==14 and value==1
	then
		set_text(3,8,'SM1852X')		
		change_screen(last_sreen)
		return 1
	elseif control==14 and value==0
	then
		return 1
	elseif control==15 and value==1
	then
		set_text(3,8,'TM512AB/AL')		
		change_screen(last_sreen)
		return 1
	elseif control==15 and value==0
	then
		return 1
	elseif control==16 and value==1
	then
		set_text(3,8,'TM512AC')		
		change_screen(last_sreen)
		return 1
	elseif control==16 and value==0
	then
		return 1
	elseif control==17 and value==1
	then
		set_text(3,8,'Hi512A0')		
		change_screen(last_sreen)
		return 1
	elseif control==17 and value==0
	then
		return 1
	elseif control==18 and value==1
	then
		set_text(3,8,'Hi512A4')		
		change_screen(last_sreen)
		return 1
	elseif control==18 and value==0
	then
		return 1
	elseif control==19 and value==1
	then
		set_text(3,8,'Hi512A6')		
		change_screen(last_sreen)
		return 1
	elseif control==19 and value==0
	then
		return 1
	end
end

function screen_08()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==7
	then
		test_flash = 0x55
		return 1
	elseif control==8
	then
		set_value(8,1,get_value(8,8))
		TiaoGuang()
		return 1
	elseif control==9
	then
		set_value(8,2,get_value(8,9))
		TiaoGuang()	
		return 1
	elseif control==10
	then
		set_value(8,3,get_value(8,10))
		TiaoGuang()	
		return 1
	elseif control==11
	then
		set_value(8,4,get_value(8,11))
		TiaoGuang()
		return 1
	elseif control==12
	then
		set_value(8,5,get_value(8,12))
		TiaoGuang()
		return 1
	elseif control==13
	then
		set_value(8,6,get_value(8,13))
		TiaoGuang()
		return 1	
	elseif control==1
	then
		set_value(8,8,get_value(8,1))
		TiaoGuang()
		return 1	
	elseif control==2
	then
		set_value(8,9,get_value(8,2))
		TiaoGuang()
		return 1	
	elseif control==3
	then
		set_value(8,10,get_value(8,3))
		TiaoGuang()
		return 1	
	elseif control==4
	then
		set_value(8,11,get_value(8,4))
		TiaoGuang()
		return 1	
	elseif control==5
	then
		set_value(8,12,get_value(8,5))
		TiaoGuang()
		return 1	
	elseif control==6
	then
		set_value(8,13,get_value(8,6))
		TiaoGuang()
		return 1	
	elseif control==22 and value==1 or control==22 and value==2
	then
		local num = get_value(8,1)
		
		if num > 0
		then
			num = num - 1
		end
		
		set_value(8,1,num)
		set_value(8,8,num)
			
		TiaoGuang()
		return 1
	elseif control==22 and value==0
	then
		return 1
	elseif control==23 and value==1 or control==23 and value==2
	then
		local num = get_value(8,1)
		
		if num < 255
		then
			num = num + 1
		end
		
		set_value(8,1,num)
		set_value(8,8,num)
		
		TiaoGuang()
		return 1
	elseif control==23 and value==0
	then
		return 1
	elseif control==24 and value==1 or control==24 and value==2
	then
		local num = get_value(8,2)
		
		if num > 0
		then
			num = num - 1
		end
		
		set_value(8,2,num)
		set_value(8,9,num)
		
		TiaoGuang()
		return 1
	elseif control==24 and value==0
	then
		return 1
	elseif control==25 and value==1 or control==25 and value==2
	then
		local num = get_value(8,2)
		
		if num < 255
		then
			num = num + 1
		end
		
		set_value(8,2,num)
		set_value(8,9,num)
		
		TiaoGuang()
		return 1
	elseif control==25 and value==0
	then
		return 1
	elseif control==26 and value==1 or control==26 and value==2
	then
		local num = get_value(8,3)
		
		if num > 0
		then
			num = num - 1
		end
		
		set_value(8,3,num)
		set_value(8,10,num)
		
		TiaoGuang()
		return 1
	elseif control==26 and value==0
	then
		return 1
		elseif control==27 and value==1 or control==27 and value==2
	then
		local num = get_value(8,3)
		
		if num < 255
		then
			num = num + 1
		end
		
		set_value(8,3,num)
		set_value(8,10,num)
			
		TiaoGuang()
		return 1
	elseif control==27 and value==0
	then
		return 1
	elseif control==28 and value==1 or control==28 and value==2
	then
		local num = get_value(8,4)
		
		if num > 0
		then
			num = num - 1
		end
		
		set_value(8,4,num)
		set_value(8,11,num)
		
		TiaoGuang()
		return 1
	elseif control==28 and value==0
	then
		return 1
	elseif control==29 and value==1 or control==29 and value==2
	then
		local num = get_value(8,4)
		
		if num < 255
		then
			num = num + 1
		end
		
		set_value(8,4,num)
		set_value(8,11,num)
			
		TiaoGuang()
		return 1
	elseif control==29 and value==0
	then
		return 1
	elseif control==30 and value==1 or control==30 and value==2
	then
		local num = get_value(8,5)
		
		if num > 0
		then
			num = num - 1
		end
		
		set_value(8,5,num)
		set_value(8,12,num)
			
		TiaoGuang()
		return 1
	elseif control==30 and value==0
	then
		return 1
	elseif control==31 and value==1 or control==31 and value==2
	then
		local num = get_value(8,5)
		
		if num < 255
		then
			num = num + 1
		end
		
		set_value(8,5,num)
		set_value(8,12,num)
			
		TiaoGuang()
		return 1
	elseif control==31 and value==0
	then
		return 1
	elseif control==32 and value==1 or control==32 and value==2
	then
		local num = get_value(8,6)
		
		if num > 0
		then
			num = num - 1
		end
		
		set_value(8,6,num)
		set_value(8,13,num)
			
		TiaoGuang()
		return 1
	elseif control==32 and value==0
	then
		return 1
	elseif control==33 and value==1 or control==33 and value==2
	then
		local num = get_value(8,6)
		
		if num < 255
		then
			num = num + 1
		end
		
		set_value(8,6,num)
		set_value(8,13,num)
			
		TiaoGuang()
		return 1
	elseif control==33 and value==0
	then
		return 1
	end
end

function screen_09()
	screen = screen_t
	control = control_t
	value = value_t
	if control==5 and value==1
	then
		if UCS512_param == 0x32 --UCS512-Dû�иù���
		then
			set_value(9,5,0)
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������		
		
			return 1
		end 
	
		if UCS512_param == 0x34 --TM512ADû�иù���
		then
			set_value(9,5,0)
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������			

			return 1
		end 
	
	
		if get_language() ==0
		then
			set_text(9,14,"�Զ�дַ")
		elseif get_language() == 1
		then
			set_text(9,14,"Auto Write")
		end

		return 1
	elseif control==5 and value==0
	then
		if UCS512_param == 0x32 --UCS512-Dû�иù���
		then
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			
			change_screen(40)--��ʾ��оƬû��д��������		
			
			set_value(9,5,1)
			return 1
		end 
	
		if UCS512_param == 0x34 --TM512ADû�иù���
		then
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	

			change_screen(40)--��ʾ��оƬû��д��������	
			
			set_value(9,5,1)	
			return 1
		end 
	
		if get_language() ==0
		then
			set_text(9,14,"�ֶ�дַ")
		elseif get_language() == 1
		then
			set_text(9,14,"Manual Write")
		end		

		return 1
	
	--UCS512-D F��д���� ����
	elseif control==13 and value==1
	then
		--9 13 7
		set_text(9,7,"Setting")

		tmp_dat[6] = 0x00--оƬ��Ŀ Ĭ��512
		tmp_dat[7] = 0x02
	
		tmp_dat[8] = get_value(9,9)-1--R
		tmp_dat[9] = get_value(9,10)-1--G
		tmp_dat[10] = get_value(9,11)-1--B
		tmp_dat[11] = get_value(9,12)-1--W

		tmp_dat[12] = 0x00
		tmp_dat[13] = 0x00
		tmp_dat[14] = 0x00
		tmp_dat[15] = 0x00
		tmp_dat[16] = 0x00	

		if UCS512_param == 0x32--D
		then
			cmd_param = 0x04
		elseif UCS512_param == 0x33--F
		then	
			cmd_param = 0x0d
		elseif UCS512_param == 0x34--TM512AD
		then	
			cmd_param = 0x04
		end

		Send_param_cmd(cmd_param,tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[16],0,0,0,0,0,0)
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		if UCS512_param == 0x32--D
		then
			DMX_Status_page = 0x55
			
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ�����")
			elseif get_language() == 1--Ӣ��
			then
				set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother red")	
			end	
	
			change_screen(40)
		elseif UCS512_param == 0x33--F
		then	
			DMX_Status_page = 0x55
			
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ���׵�")
			elseif get_language() == 1--Ӣ��
			then
				set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
			end	
			
			change_screen(40)
		elseif UCS512_param == 0x34--TM512AD
		then	
			DMX_Status_page = 0x55
			
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ�����")
			elseif get_language() == 1--Ӣ��
			then
				set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother red")	
			end	
			
			change_screen(40)
		end

		return 1	
	elseif control==13 and value==0
	then
		return 1	

	----------------------------------
	--UCS512-F��д �ֶ����Զ�дַ
	elseif control==4 and value==1
	then
		if UCS512_param == 0x32 --UCS512-Dû�иù���
		then
			set_text(9,4,0)
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������		
			return 1
		end 
		
		if UCS512_param == 0x34 --TM512ADû�иù���
		then
			set_text(9,4,0)
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������		
			return 1
		end 

		set_text(9,8,"Setting")

		tmp_dat[6] = 0x00--оƬ��Ŀ Ĭ��512
		tmp_dat[7] = 0x02
		
		tmp_dat[8] = 0

		tmp_dat[9] = 0
		tmp_dat[10] = 0
		tmp_dat[11] = 0
		tmp_dat[12] = 0

		local auto_wrt_addr = get_value(9,5)--�Զ�or�ֶ�д��
		if auto_wrt_addr ==0--�����ֶ�д��
		then
			tmp_dat[13]=0x55
		else
			tmp_dat[13]=0xaa--���£��Զ�д��
		end

		tmp_dat[14] = 0x00
		tmp_dat[15] = 0x00
		tmp_dat[16] = 0x00
		tmp_dat[17] = 0x18
		tmp_dat[18] = 0x00
		tmp_dat[19] = 0x00	

		Send_param_cmd(0x0c,tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],tmp_dat[13],tmp_dat[17],tmp_dat[19],0,0,0)
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"�ֶ����Զ������,\r\n�Զ����ֶ����׹�")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"manual to auto red,\r\nauto to manual white")	
		end	
			
		change_screen(40)
		----
		
		return 1	
	elseif control==4 and value==0
	then
		return 1	
	end
end

function screen_10()
	screen = screen_t
	control = control_t
	value = value_t
	if control==1 and value==1
	then
		if get_text(10,17) == "TM512AE"
		then
			change_screen(32)
		else
			change_screen(30)
		end
		return 1
	elseif control==1 and value==0
	then
		return 1

	--10,7,18
	elseif control==7 and value==1
	then
		if get_language() == 0
		then
			set_text(10,18,"�ָ��ϵ�״̬")
		elseif get_language() == 1
		then
			set_text(10,18,"Restore light status")
		end

		return 1
	elseif control==7 and value==0
	then
		if get_language() == 0
		then
			set_text(10,18,"�������һ֡")
		elseif get_language() == 1
		then
			set_text(10,18,"Save last frame")
		end

		return 1

	--UCS512-E ת������
	elseif control==2 and value==1
	then
		S5C3 = get_text(10,6)--��ȡ��ǰֵ

		if get_language() == 0--����
		then
			if S5C3 == "1��"
			then
				set_text(10,6,"2��")--���ÿؼ���ֵ	
			elseif S5C3 == "2��"
			then
				set_text(10,6,"3��")--���ÿؼ���ֵ
			elseif S5C3 == "3��"
			then
				set_text(10,6,"W3��")--���ÿؼ���ֵ
			elseif S5C3 == "W3��"
			then
				set_text(10,6,"1��")--���ÿؼ���ֵ	
			end
		elseif get_language() == 1 --Ӣ��
		then
			if S5C3 == "1 times"
			then
				set_text(10,6,"2 times")--���ÿؼ���ֵ	
			elseif S5C3 == "2 times"
			then
				set_text(10,6,"3 times")--���ÿؼ���ֵ
			elseif S5C3 == "3 times"
			then
				set_text(10,6,"W3 times")--���ÿؼ���ֵ
			elseif S5C3 == "W3 times"
			then
				set_text(10,6,"1 times")--���ÿؼ���ֵ	
			end
		end
		return 1
	elseif control==2 and value==0
	then
		return 1

	--������ɫ����
	elseif control==5 and value==1
	then
		S5C3 = get_text(10,16)--��ȡ��ǰֵ

		if get_language() == 0--����
		then
			if S5C3 == "1ɫ"
			then
				set_text(10,16,"2ɫ")--���ÿؼ���ֵ	
			elseif S5C3 == "2ɫ"
			then
				set_text(10,16,"3ɫ")--���ÿؼ���ֵ
			elseif S5C3 == "3ɫ"
			then
				set_text(10,16,"4ɫ")--���ÿؼ���ֵ
			elseif S5C3 == "4ɫ"
			then
				set_text(10,16,"1ɫ")--���ÿؼ���ֵ	
			end
		elseif get_language() == 1--Ӣ��
		then
			if S5C3 == "1 color"
			then
				set_text(10,16,"2 color")--���ÿؼ���ֵ	
			elseif S5C3 == "2 color"
			then
				set_text(10,16,"3 color")--���ÿؼ���ֵ
			elseif S5C3 == "3 color"
			then
				set_text(10,16,"4 color")--���ÿؼ���ֵ
			elseif S5C3 == "4 color"
			then
				set_text(10,16,"1 color")--���ÿؼ���ֵ	
			end
		end

		return 1
	elseif control==5 and value==0
	then
		return 1		

	elseif control==14 and value==1
	then
		if get_text(10,17) == "TM512AE"
		then
			set_text(13,2,"TM512AE")
		else
			set_text(13,2,"UCS512-E")
		end
		return 1
	elseif control==14 and value==0
	then
		return 1
	
	--�ı��ϵ�������ɫ UCS512-E 10
	elseif control >= 9 and control <= 11
	then
		rr = get_value(10,9)
		gg = get_value(10,10)
		bb = get_value(10,11)
		
		rr = ((rr>>3)<<11)&0xf800
		gg = ((gg>>2)<<5)&0x07e0
		bb = (bb>>3)&0x001f
	
		draw_pen_color = Or(rr,gg)
		draw_pen_color = Or(draw_pen_color,bb) 
		redraw() 
		
		return 1
	elseif control == 25 and value==1
	then
		rr = get_value(10,9)
		gg = get_value(10,10)
		bb = get_value(10,11)
		ww = get_value(10,12)
		
		set_value(41,1,rr)
		set_value(41,2,gg)
		set_value(41,3,bb)
		set_value(41,4,ww)
		
		set_value(41,8,rr)
		set_value(41,9,gg)
		set_value(41,10,bb)
		set_value(41,11,ww)
		return 1
	elseif control == 25 and value==0
	then
		return 1
	
		--UCS512E д���� ����
	
	elseif control==13 and value==1
	then
		set_text(10,19,"Setting")	

		tmp_dat[6] = 0x00--оƬ��Ŀ Ĭ��512
		tmp_dat[7] = 0x02
		
		tmp_dat[8]=0

		tmp_dat[9] = get_value(10,9)--R
		tmp_dat[10] = get_value(10,10)--G
		tmp_dat[11] = get_value(10,11)--B
		tmp_dat[12] = get_value(10,12)--W
		
		local no_singal = get_value(10,7)--���ź�״̬
		if no_singal ==0
		then
			tmp_dat[13] =0xd1
		elseif no_singal ==1
		then
			tmp_dat[13] = 0xd2
		else
			tmp_dat[13] = 0xd1
		end

		ss = get_text(10,6)--ת������
		if ss == "1��"
		then
			tmp_dat[14] = 0xd3
		elseif ss == "1 times"
		then
			tmp_dat[14] = 0xd3
		elseif ss == "2��"
		then
			tmp_dat[14] = 0xd4
		elseif ss == "2 times"
		then
			tmp_dat[14] = 0xd4
		elseif ss == "3��"
		then
			tmp_dat[14] = 0xd5
		elseif ss == "3 times"
		then
			tmp_dat[14] = 0xd5
		elseif ss == "W3��"
		then
			tmp_dat[14] = 0xd6
		elseif ss == "W3 times"
		then
			tmp_dat[14] = 0xd6
		else
			tmp_dat[14] = 0xd3
		end	

		ss = get_text(10,16)
		if ss =="1ɫ"
		then
			tmp_dat[15] = 0xd7
		elseif ss =="1 color"
		then
			tmp_dat[15] = 0xd7
		elseif ss =="2ɫ"
		then
			tmp_dat[15] = 0xd8
		elseif ss =="2 color"
		then
			tmp_dat[15] = 0xd8
		elseif ss =="3ɫ"
		then
			tmp_dat[15] = 0xd9
		elseif ss =="3 color"
		then
			tmp_dat[15] = 0xd9
		elseif ss =="4ɫ"
		then	
			tmp_dat[15] = 0xda
		elseif ss =="4 color"
		then	
			tmp_dat[15] = 0xda
		else
			tmp_dat[15] = 0xd9
		end
		
		tmp_dat[16] = 0x00
		tmp_dat[17] = 0x1e
		tmp_dat[18] = 0x00	
		tmp_dat[19] = 0x00	

		Send_param_cmd(0x05,tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],tmp_dat[13],tmp_dat[14],tmp_dat[15],tmp_dat[17],0,0,0)
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ��ʾ�ϵ�������ɫ")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother light power on light status")
		end		
		
		change_screen(40)
		----
		return 1	
	elseif control==13 and value==0
	then
		return 1	

	--����д�����
	elseif control==20 and value==1
	then
		set_text(3,8,get_text(10,17))		
		change_screen(3)
		
		DMX_add_param = 0x33	
		return 1
	elseif control==20 and value==0
	then
		return 1
	end
end

function screen_11()
	screen = screen_t
	control = control_t
	value = value_t
	if control==7 and value==1
	then
		if get_language() == 0
		then
			set_text(11,21,"�ָ��ϵ�״̬")
		elseif get_language() == 1
		then
			set_text(11,21,"Restore light status")
		end
		return 1
	elseif control==7 and value==0
	then
		if get_language() == 0
		then
			set_text(11,21,"�������һ֡")
		elseif get_language() == 1
		then
			set_text(11,21,"Save last frame")
		end
		return 1

	--11,16,23
	elseif control==16 and value==1
	then
		if get_language() == 0
		then
			set_text(11,23,"����")
		elseif get_language() == 1
		then
			set_text(11,23,"Open")
		end
		return 1
	elseif control==16 and value==0
	then
		if get_language() == 0
		then
			set_text(11,23,"�ر�")
		elseif get_language() == 1
		then
			set_text(11,23,"Close")
		end
		return 1

	--SM17512 ����ͨ����
	elseif control==2 and value==1
	then
		if get_value(11,6) == 1
		then
			set_value(11,6,2)--���ÿؼ���ֵ	
		elseif get_value(11,6) == 2
		then
			set_value(11,6,3)--���ÿؼ���ֵ
		elseif get_value(11,6) == 3
		then
			set_value(11,6,4)--���ÿؼ���ֵ
		elseif get_value(11,6) == 4
		then
			set_value(11,6,1)--���ÿؼ���ֵ	
		end
			
		return 1
	elseif control==2 and value==0
	then
		return 1
	
	--�ı��ϵ�������ɫ SM17512 11
	elseif control >= 9 and control <= 11
	then
		rr = get_value(11,9)
		gg = get_value(11,10)
		bb = get_value(11,11)
		
		rr = ((rr>>3)<<11)&0xf800
		gg = ((gg>>2)<<5)&0x07e0
		bb = (bb>>3)&0x001f
	
		draw_pen_color = Or(rr,gg)
		draw_pen_color = Or(draw_pen_color,bb) 
		redraw() 
		
		return 1
	elseif control == 26 and value==1
	then
		rr = get_value(11,9)
		gg = get_value(11,10)
		bb = get_value(11,11)
		ww = get_value(11,12)
		
		set_value(41,1,rr)
		set_value(41,2,gg)
		set_value(41,3,bb)
		set_value(41,4,ww)
		
		set_value(41,8,rr)
		set_value(41,9,gg)
		set_value(41,10,bb)
		set_value(41,11,ww)
		return 1
	elseif control == 26 and value==0
	then
		return 1
	
	--SM17512д���� ����
	
	elseif control==13 and value==1
	then
		set_text(11,22,"Setting")	

		tmp_dat[6] = 0x00--оƬ��Ŀ Ĭ��512
		tmp_dat[7] = 0x02
		
		local no_singal = get_value(11,7)--���ź�״̬
		if no_singal ==0
		then
			tmp_dat[8]=0
		elseif no_singal ==1
		then
			tmp_dat[8]=0x04
		else
			tmp_dat[8]=0
		end

		local ch_num = get_value(11,6)-1
		tmp_dat[8] = Or(tmp_dat[8],ch_num)--ͨ�����
			
		tmp_dat[9] = get_value(11,9)--R
		tmp_dat[10] = get_value(11,10)--G
		tmp_dat[11] = get_value(11,11)--B
		tmp_dat[12] = get_value(11,12)--W
		
		tmp_dat[13] = 0

		local auto_wrt_addr = get_value(11,16)
		if auto_wrt_addr==0 --�ر��Զ���ַ
		then
			tmp_dat[14] = 0x01
		elseif auto_wrt_addr==1 --���Զ���ַ
		then
			tmp_dat[14] = 0x00
		else
			tmp_dat[14] = 0x01
		end
			
		tmp_dat[15] =0
		tmp_dat[16] =0	

		tmp_dat[17] =0x23--���λ

		tmp_dat[18] = get_value(11,14)-1--R����
		tmp_dat[19] = get_value(11,17)-1--G
		tmp_dat[20] = get_value(11,18)-1--B
		tmp_dat[21] = get_value(11,19)-1--W

		tmp_dat[18] = tmp_dat[18]*16+tmp_dat[19]
		tmp_dat[20] = tmp_dat[20]*16+tmp_dat[21]	
	
		tmp_dat[22] = 0x00	

		Send_param_cmd(0x08,tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],tmp_dat[17],tmp_dat[18],tmp_dat[20],tmp_dat[14],0,0)
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ������,\r\n2S���л����ϵ��Լ���ɫ")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst blue,\r\nother light power on light status")
		end	
		
		change_screen(40)
		----
		return 1	
	elseif control==13 and value==0
	then
		return 1				
	
	--����д�����
	elseif control==24 and value==1
	then
		set_text(3,8,get_text(11,20))		
		change_screen(3)
		
		DMX_add_param = 0x33	
		return 1
	elseif control==24 and value==0
	then
		return 1
	end
end

function screen_12()
	screen = screen_t
	control = control_t
	value = value_t
	if control==7 and value==1
	then
		if get_language() == 0
		then
			set_text(12,21,"�ָ��ϵ�״̬")
		elseif get_language() == 1
		then
			set_text(12,21,"Restore light status")
		end

		return 1
	elseif control==7 and value==0
	then
		if get_language() == 0
		then
			set_text(12,21,"�������һ֡")
		elseif get_language() == 1
		then
			set_text(12,21,"Save last frame")
		end

		return 1
	--12,6,23
	elseif control==6 and value==1
	then
		set_text(12,23,"other")
		return 1
	elseif control==6 and value==0
	then
		set_text(12,23,"SM16813")
		return 1
	--12,18,24
	elseif control==18 and value==1
	then
		if get_language() == 0--����
		then
			set_text(12,24,"4ɫ")
		elseif get_language() == 1--Ӣ��
		then
			set_text(12,24,"4 color")
		end
		return 1
	elseif control==18 and value==0
	then
		if get_language() == 0--����
		then
			set_text(12,24,"3ɫ")
		elseif get_language() == 1--Ӣ��
		then
			set_text(12,24,"3 color")
		end
		return 1
	--12,5,25
	elseif control==5 and value==1
	then
		set_text(12,25,"DMX512")
		return 1
	elseif control==5 and value==0
	then
		if get_language() == 0--����
		then
			set_text(12,25,"������")
		elseif get_language() == 1--Ӣ��
		then
			set_text(12,25,"Return zero")
		end
		return 1
	--SM17500 ��������ѡ��
	elseif control==17 and value==1
	then
		S5C3 = get_text(12,19)--��ȡ��ǰֵ

		if get_language() == 0--����
		then
			if S5C3 == "�޵�������"
			then
				set_text(12,19,"4λ��������")--���ÿؼ���ֵ	
				
				set_value(14,9,15)
				set_value(14,10,15)
				set_value(14,11,15)
				set_value(14,12,15)
				
				SM1722_param = 0x55

			elseif S5C3 == "4λ��������"
			then
				set_text(12,19,"5λ��������")--���ÿؼ���ֵ

				set_value(14,9,31)
				set_value(14,10,31)
				set_value(14,11,31)
				set_value(14,12,31)	

				SM1722_param = 0xaa	
			elseif S5C3 == "5λ��������"
			then
				set_text(12,19,"6λ��������")--���ÿؼ���ֵ

				set_value(14,9,63)
				set_value(14,10,63)
				set_value(14,11,63)
				set_value(14,12,63)	

				SM1722_param = 0xcc	
			elseif S5C3 == "6λ��������"
			then
				set_text(12,19,"�޵�������")--���ÿؼ���ֵ	

				set_value(14,9,0)
				set_value(14,10,0)
				set_value(14,11,0)
				set_value(14,12,0)	

				SM1722_param = 0x11	
			end
		elseif get_language() == 1--Ӣ��
		then
			if S5C3 == "No"
			then
				set_text(12,19,"4 bit")--���ÿؼ���ֵ	
				
				set_value(14,9,15)
				set_value(14,10,15)
				set_value(14,11,15)
				set_value(14,12,15)
				
				SM1722_param = 0x55

			elseif S5C3 == "4 bit"
			then
				set_text(12,19,"5 bit")--���ÿؼ���ֵ

				set_value(14,9,31)
				set_value(14,10,31)
				set_value(14,11,31)
				set_value(14,12,31)	

				SM1722_param = 0xaa	
			elseif S5C3 == "5 bit"
			then
				set_text(12,19,"6 bit")--���ÿؼ���ֵ

				set_value(14,9,63)
				set_value(14,10,63)
				set_value(14,11,63)
				set_value(14,12,63)	

				SM1722_param = 0xcc	
			elseif S5C3 == "6 bit"
			then
				set_text(12,19,"No")--���ÿؼ���ֵ	

				set_value(14,9,0)
				set_value(14,10,0)
				set_value(14,11,0)
				set_value(14,12,0)	

				SM1722_param = 0x11	
			end
		end
		return 1
	elseif control==17 and value==0
	then
		return 1	

	 elseif control==14 and value==1
	 then
		S5C3 = get_text(12,19)--��ȡ��ǰֵ

		if get_language() == 0--����
		then
			if S5C3 == "�޵�������"
			then
				set_value(14,9,0)
				set_value(14,10,0)
				set_value(14,11,0)
				set_value(14,12,0)	

				SM1722_param = 0x11	
			elseif S5C3 == "4λ��������"
			then
				set_value(14,9,15)
				set_value(14,10,15)
				set_value(14,11,15)
				set_value(14,12,15)
				
				SM1722_param = 0x55
			elseif S5C3 == "5λ��������"
			then
				set_value(14,9,31)
				set_value(14,10,31)
				set_value(14,11,31)
				set_value(14,12,31)	

				SM1722_param = 0xaa	
			elseif S5C3 == "6λ��������"
			then
				set_value(14,9,63)
				set_value(14,10,63)
				set_value(14,11,63)
				set_value(14,12,63)	

				SM1722_param = 0xcc	
			end
		elseif get_language() == 1--Ӣ��
		then
			if S5C3 == "No"
			then
				set_value(14,9,0)
				set_value(14,10,0)
				set_value(14,11,0)
				set_value(14,12,0)	

				SM1722_param = 0x11	
			elseif S5C3 == "4 bit"
			then
				set_value(14,9,15)
				set_value(14,10,15)
				set_value(14,11,15)
				set_value(14,12,15)
				
				SM1722_param = 0x55
			elseif S5C3 == "5 bit"
			then
				set_value(14,9,31)
				set_value(14,10,31)
				set_value(14,11,31)
				set_value(14,12,31)	

				SM1722_param = 0xaa	
			elseif S5C3 == "6 bit"
			then
				set_value(14,9,63)
				set_value(14,10,63)
				set_value(14,11,63)
				set_value(14,12,63)	

				SM1722_param = 0xcc	
			end
		end

		SM1722_current = 0xcc	

		set_text(14,2,get_text(12,20))--���ÿؼ���ֵ

		return 1
	elseif control==14 and value==0
	then
		return 1
	--SM1752X SM17500 ���õ��� ����
	
	--���õ������Ĳ���
	elseif control==9
	then
		if SM1722_param == 0x11
		then
			if get_language() == 0--����
			then
				set_text(36,2,"��ǰ�޵������棡")	
			elseif get_language() == 1--Ӣ��
			then
				set_text(36,2,"No current gain��")
			end	
			change_screen(36)--��ʾ��оƬû��д��������		
		elseif SM1722_param == 0x55
		then
			if get_value(14,9) >15
			then
				set_value(14,9,15)
			end
		elseif SM1722_param == 0xaa
		then
			if get_value(14,9) >31
			then
				set_value(14,9,31)
			end	
		elseif SM1722_param == 0xcc
		then
			if get_value(14,9) >63
			then
				set_value(14,9,63)
			end		
		end
	elseif control==10
	then
		if SM1722_param == 0x11
		then
			if get_language() == 0--����
			then
				set_text(36,2,"��ǰ�޵������棡")	
			elseif get_language() == 1--Ӣ��
			then
				set_text(36,2,"No current gain��")
			end
			change_screen(36)--��ʾ��оƬû��д��������		
		elseif SM1722_param == 0x55
		then
			if get_value(14,10) >15
			then
				set_value(14,10,15)
			end
		elseif SM1722_param == 0xaa
		then
			if get_value(14,10) >31
			then
				set_value(14,10,31)
			end	
		elseif SM1722_param == 0xcc
		then
			if get_value(14,10) >63
			then
				set_value(14,10,63)
			end		
		end
	elseif control==11
	then
		if SM1722_param == 0x11
		then
			if get_language() == 0--����
			then
				set_text(36,2,"��ǰ�޵������棡")	
			elseif get_language() == 1--Ӣ��
			then
				set_text(36,2,"No current gain��")
			end
			change_screen(36)--��ʾ��оƬû��д��������		
		elseif SM1722_param == 0x55
		then
			if get_value(14,11) >15
			then
				set_value(14,11,15)
			end
		elseif SM1722_param == 0xaa
		then
			if get_value(14,11) >31
			then
				set_value(14,11,31)
			end	
		elseif SM1722_param == 0xcc
		then
			if get_value(14,11) >63
			then
				set_value(14,11,63)
			end		
		end
	elseif control==12
	then
		if SM1722_param == 0x11
		then
			if get_language() == 0--����
			then
				set_text(36,2,"��ǰ�޵������棡")	
			elseif get_language() == 1--Ӣ��
			then
				set_text(36,2,"No current gain��")
			end
			change_screen(36)--��ʾ��оƬû��д��������		
		elseif SM1722_param == 0x55
		then
			if get_value(14,12) >15
			then
				set_value(14,12,15)
			end
		elseif SM1722_param == 0xaa
		then
			if get_value(14,12) >31
			then
				set_value(14,12,31)
			end	
		elseif SM1722_param == 0xcc
		then
			if get_value(14,12) >63
			then
				set_value(14,12,63)
			end		
		end

	--������һ��
	elseif control==1 and value==1
	then
		if get_text(14,2) == "SM1752X"
		then
			change_screen(15)
		elseif get_text(14,2) == "SM17500" 
		then
			change_screen(12)
		elseif get_text(14,2) == "SM17500-S" 
		then
			change_screen(12)
		end
		return 1
	elseif control==1 and value==0
	then
		return 1
	
	--�ı��ϵ�������ɫ SM17500 12
	elseif control >= 9 and control <= 11
	then
		rr = get_value(12,9)
		gg = get_value(12,10)
		bb = get_value(12,11)
		
		rr = ((rr>>3)<<11)&0xf800
		gg = ((gg>>2)<<5)&0x07e0
		bb = (bb>>3)&0x001f
	
		draw_pen_color = Or(rr,gg)
		draw_pen_color = Or(draw_pen_color,bb) 
		redraw() 
		
		return 1
	elseif control == 26 and value==1
	then
		rr = get_value(12,9)
		gg = get_value(12,10)
		bb = get_value(12,11)
		ww = get_value(12,12)
		
		set_value(41,1,rr)
		set_value(41,2,gg)
		set_value(41,3,bb)
		set_value(41,4,ww)
		
		set_value(41,8,rr)
		set_value(41,9,gg)
		set_value(41,10,bb)
		set_value(41,11,ww)
		return 1
	elseif control == 26 and value==0
	then
		return 1

	--SM17500д���� ����
	
	elseif control==13 and value==1
	then
		set_text(12,22,"Setting")

		tmp_dat[6] = 0x00--оƬ��Ŀ Ĭ��512
		tmp_dat[7] = 0x02
		
		--���ź�״̬
		local no_singal = get_value(12,7)
		if no_singal ==0--�������һ֡
		then
			tmp_dat[8]=0
		else
			tmp_dat[8]=0x40
		end
		
		--��������ģʽ
		local cc = get_text(12,19)
		
		if get_language() == 0--����
		then
			if cc == '�޵�������'
			then
				tmp_dat[8]=tmp_dat[8]
			elseif cc ==  '4λ��������'
			then
				tmp_dat[8]= Or(tmp_dat[8],0x04)
			elseif cc ==  '5λ��������'
			then
				tmp_dat[8]= Or(tmp_dat[8],0x02)
			elseif cc ==  '6λ��������'
			then
				tmp_dat[8]= Or(tmp_dat[8],0x06)
			else
				tmp_dat[8]=tmp_dat[8]
			end
		elseif get_language() == 1--Ӣ��
		then
			if cc == 'No'
			then
				tmp_dat[8]=tmp_dat[8]
			elseif cc ==  '4 bit'
			then
				tmp_dat[8]= Or(tmp_dat[8],0x04)
			elseif cc ==  '5 bit'
			then
				tmp_dat[8]= Or(tmp_dat[8],0x02)
			elseif cc ==  '6 bit'
			then
				tmp_dat[8]= Or(tmp_dat[8],0x06)
			else
				tmp_dat[8]=tmp_dat[8]
			end
		end

		--������ɫ 3ɫ��4ɫ
		local color_num = get_value(12,18)
		if color_num ==0--3ɫ
		then
			tmp_dat[8]=tmp_dat[8]
		else
			tmp_dat[8]=Or(tmp_dat[8],0x10)
		end

		--DAOת�����Э��ѡ��
		local out_xy = get_value(12,5)
		if out_xy ==0--������Э��
		then
			tmp_dat[8]=tmp_dat[8]
		else
			tmp_dat[8]=Or(tmp_dat[8],0x08)
		end

		--�ϵ�����״̬
		tmp_dat[9] = get_value(12,9)--R
		tmp_dat[10] = get_value(12,10)--G
		tmp_dat[11] = get_value(12,11)--B
		tmp_dat[12] = get_value(12,12)--W

		--���������洮��оƬѡ��
		local out_xy = get_value(12,6)
		if out_xy ==0--SM16813
		then
			tmp_dat[13]=0x01
		else
			tmp_dat[13]=0x00
		end

		tmp_dat[17] = 0x25--SM17500д�����ı��

		Send_param_cmd(0x11,tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],tmp_dat[13],tmp_dat[17],0,0,0,0)
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ��ʾ�ϵ�������ɫ")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother light power on light status")
		end	

		change_screen(40)
		----
		return 1	
	elseif control==13 and value==0
	then
		return 1	
	
	--����д�����
	elseif control==28 and value==1
	then
		set_text(3,8,get_text(12,20))		
		change_screen(3)
		
		DMX_add_param = 0x33	
		return 1
	elseif control==28 and value==0
	then
		return 1
	end
end

function screen_13()
	screen = screen_t
	control = control_t
	value = value_t
	if control==13 and value==1
	then
		set_text(13,7,"Setting")		

		tmp_dat[6] = 0x00--оƬ��Ŀ Ĭ��512
		tmp_dat[7] = 0x02
		
		tmp_dat[8] = get_value(13,9)-1--R����
		tmp_dat[9] = get_value(13,10)-1--G
		tmp_dat[10] = get_value(13,11)-1--B
		tmp_dat[11] = get_value(13,12)-1--W
	
		tmp_dat[12] =0
		tmp_dat[13] =0
		tmp_dat[14] =0
		tmp_dat[15] =0	
		tmp_dat[16] = 0	

		Send_param_cmd(0x07,tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],0,0,0,0,0,0,0)
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ�����")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother red")
		end					
		
		change_screen(40)
		----
		return 1	
	elseif control==13 and value==0
	then
		return 1			
	------------------------------------------
	--UCS512E д��ͨ����
	elseif control==4 and value==1
	then
		ztd_flag = 0x33
		
		set_text(39,2,"")--��������
		set_text(39,8,"")

		if secret_2 == 0x00--��һ�ε��������ʱ
		then
			change_screen(39)
		else
			if get_language() == 0--����
			then
				set_text(36,2,"��ȷ��Ҫ���øò�����")	
				set_text(36,7,"д�ɹ����׵����Ƶƣ��������̵�")
			elseif get_language() == 1--Ӣ��
			then
				set_text(36,2,"Are you sure set param��")			
				set_text(36,7,"Write ok,first yellow,other green")
			end		
			
			change_screen(36)
		end
		return 1	
	elseif control==4 and value==0
	then
		return 1
	end
end

function screen_14()
	screen = screen_t
	control = control_t
	value = value_t
	if control==13 and value==1
	then
		set_text(14,22,"Setting")	

		if SM1722_current == 0xaa --SM1752Xд����
		then
			tmp_dat[6] = 0x00--оƬ��Ŀ Ĭ��512
			tmp_dat[7] = 0x02
			
			tmp_dat[17] =0x2a--SM1752Xд�������
	
			tmp_dat[18] = get_value(14,9)--R����
			tmp_dat[19] = get_value(14,10)--G
			tmp_dat[20] = get_value(14,11)--B
			tmp_dat[21] = get_value(14,12)--W
	
			Send_param_cmd(0x0a,tmp_dat[17],tmp_dat[18],tmp_dat[19],tmp_dat[20],tmp_dat[21],0,0,0,0,0,0)
		elseif SM1722_current == 0xcc --SM17500д����
		then
			tmp_dat[6] = 0x00--оƬ��Ŀ Ĭ��512
			tmp_dat[7] = 0x02
			
			tmp_dat[17] =0x21--SM17500д��������
	
			tmp_dat[18] = get_value(14,9)--R����
			tmp_dat[19] = get_value(14,10)--G
			tmp_dat[20] = get_value(14,11)--B
			tmp_dat[21] = get_value(14,12)--W
	
			Send_param_cmd(0x14,tmp_dat[17],tmp_dat[18],tmp_dat[19],tmp_dat[20],tmp_dat[21],0,0,0,0,0,0)
		end
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		----
		DMX_Status_page = 0x55
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ���Ƶ�")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"write ok,\r\nfirst red,\r\nother yellow")
		end				

		change_screen(40)
		----
		return 1	
	elseif control==13 and value==0
	then
		return 1			


	----------------------------------------------------
	--SM17500 д��ͨ����
	elseif control==4 and value==1
	then
		if get_text(14,2) == "SM1752X"
		then
			if last_sreen == 36
			then
			
			else
				Need_FH = last_sreen
			end
		
			set_value(14,4,0)
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������		

			return 1
		end
		
		if get_text(14,2) == "SM17500"
		then
			if last_sreen == 36
			then
			
			else
				Need_FH = last_sreen
			end	
		end
	
		ztd_flag = 0x55
		
		set_text(39,2,"")--��������
		set_text(39,8,"")

		if secret_2 == 0x00--��һ�ε��������ʱ
		then
			change_screen(39)
		else
			if get_language() == 0--����
			then
				set_text(36,2,"��ȷ��Ҫ���øò�����")	
				set_text(36,7,"д�ɹ����׵�����ƣ��������ϵ�")
			elseif get_language() == 1--Ӣ��
			then
				set_text(36,2,"Are you sure set param��")			
				set_text(36,7,"Write ok,first red,other violet")
			end	

			change_screen(36)
		end
		return 1	
	elseif control==4 and value==0
	then
		return 1
	elseif control==1 and value==1
	then
		if get_text(14,2)=="SM17500-S" or get_text(14,2)=="SM17500"
		then
			change_screen(12)
		elseif get_text(14,2)=="SM1752X"
		then
			change_screen(15)
		end
		
		return 1
	elseif control==1 and value==0
	then
		return 1
	end
end

function screen_15()
	screen = screen_t
	control = control_t
	value = value_t
	if control==7 and value==1
	then
		if get_language() == 0
		then
			set_text(15,21,"�ָ��ϵ�״̬")
		elseif get_language() == 1
		then
			set_text(15,21,"Restore light status")
		end

		return 1
	elseif control==7 and value==0
	then
		if get_language() == 0
		then
			set_text(15,21,"�������һ֡")
		elseif get_language() == 1
		then
			set_text(15,21,"Save last frame")
		end

		return 1

	--15,16,23
	elseif control==16 and value==1
	then
		if get_language() == 0
		then
			set_text(15,23,"����")
		elseif get_language() == 1
		then
			set_text(15,23,"Open")
		end

		return 1
	elseif control==16 and value==0
	then
		if get_language() == 0
		then
			set_text(15,23,"�ر�")
		elseif get_language() == 1
		then
			set_text(15,23,"Close")
		end

		return 1

	--����SM1752X��ͨ����
	elseif control==2 and value==1
	then
		if get_value(15,6) == 1
		then
			set_value(15,6,2)--���ÿؼ���ֵ	
		elseif get_value(15,6) == 2
		then
			set_value(15,6,3)--���ÿؼ���ֵ
		elseif get_value(15,6) == 3
		then
			set_value(15,6,4)--���ÿؼ���ֵ
		elseif get_value(15,6) == 4
		then
			set_value(15,6,1)--���ÿؼ���ֵ	
		end	
		return 1
	elseif control==2 and value==0
	then
		return 1
	--SM1752X�Զ���ַ����
	elseif control==16 and value==1
	then
		set_enable(15,14,1)	
		return 1
	elseif control==16 and value==0
	then
		set_enable(15,14,0)	
		return 1

	elseif control==17 and value==1
	then
		set_value(14,9,31)
		set_value(14,10,31)
		set_value(14,11,31)
		set_value(14,12,31)
	
		SM1722_param = 0xaa --SM1752X

		SM1722_current = 0xaa	

		set_text(14,2,"SM1752X")--���ÿؼ���ֵ

		return 1
	elseif control==17 and value==0
	then
		return 1

	--�ı��ϵ�������ɫ SM1752X 15
	elseif control >= 9 and control <= 11
	then
		rr = get_value(15,9)
		gg = get_value(15,10)
		bb = get_value(15,11)
		
		rr = ((rr>>3)<<11)&0xf800
		gg = ((gg>>2)<<5)&0x07e0
		bb = (bb>>3)&0x001f
	
		draw_pen_color = Or(rr,gg)
		draw_pen_color = Or(draw_pen_color,bb) 
		redraw() 
		
		return 1
	elseif control == 26 and value==1
	then
		rr = get_value(15,9)
		gg = get_value(15,10)
		bb = get_value(15,11)
		ww = get_value(15,12)
		
		set_value(41,1,rr)
		set_value(41,2,gg)
		set_value(41,3,bb)
		set_value(41,4,ww)
		
		set_value(41,8,rr)
		set_value(41,9,gg)
		set_value(41,10,bb)
		set_value(41,11,ww)
		return 1
	elseif control == 26 and value==0
	then
		return 1
	
	--SM1752Xд���� ����

	elseif control==13 and value==1
	then
		set_text(15,22,"Setting")	

		tmp_dat[6] = 0x00--оƬ��Ŀ Ĭ��512
		tmp_dat[7] = 0x02
		
		--���ź�״̬
		local no_singal = get_value(15,7)
		if no_singal ==0--�������һ֡
		then
			tmp_dat[8]=0
		elseif no_singal ==1
		then
			tmp_dat[8]=0x40
		else
			tmp_dat[8]=0
		end

		--ͨ������
		local ch_num = get_value(15,6)-1
		if ch_num==0--1ch
		then
			tmp_dat[8] = tmp_dat[8]
		elseif ch_num==1--2ch
		then
			tmp_dat[8] = Or(tmp_dat[8],0x20)
		elseif ch_num==2--3ch
		then
			tmp_dat[8] = Or(tmp_dat[8],0x10)
		elseif ch_num==3--4ch
		then
			tmp_dat[8] = Or(tmp_dat[8],0x30)
		else
			tmp_dat[8] = Or(tmp_dat[8],0x10)
		end

		local auto_wrt_addr = get_value(15,16)
		if auto_wrt_addr==0--���𣬹ر��Զ�����
		then
			tmp_dat[8] = Or(tmp_dat[8],0x00)
		else--���£������Զ�����
			tmp_dat[8] = Or(tmp_dat[8],0x80)
		end

		tmp_dat[9] = get_value(15,9)--R
		tmp_dat[10] = get_value(15,10)--G
		tmp_dat[11] = get_value(15,11)--B
		tmp_dat[12] = get_value(15,12)--W
		
		tmp_dat[13] = get_value(15,14)--�Զ���ַ����

		tmp_dat[17] = 0x25--SM1752X�ı��

		Send_param_cmd(0x09,tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],tmp_dat[13],tmp_dat[17],0,0,0,0)
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ������")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother blue")
		end	
			
		change_screen(40)
		----
		return 1	
	elseif control==13 and value==0
	then
		return 1	

	
	--����д�����
	elseif control==18 and value==1
	then
		set_text(3,8,get_text(15,20))		
		change_screen(3)
		
		DMX_add_param = 0x33	
		return 1
	elseif control==18 and value==0
	then
		return 1
	end
end

function screen_16()
	screen = screen_t
	control = control_t
	value = value_t
	if control==6 and value==1
	then
		if get_value(16,21) == 1
		then
			set_value(16,21,2)--���ÿؼ���ֵ	
		elseif get_value(16,21) == 2
		then
			set_value(16,21,3)--���ÿؼ���ֵ
		elseif get_value(16,21) == 3
		then
			set_value(16,21,4)--���ÿؼ���ֵ
		elseif get_value(16,21) == 4
		then
			set_value(16,21,5)--���ÿؼ���ֵ	
		elseif get_value(16,21) == 5
		then
			set_value(16,21,1)--���ÿؼ���ֵ		
		end
			
		return 1
	elseif control==6 and value==0
	then
		return 1

	--ˢ��������
	elseif control==7 and value==1
	then
		S5C3 = get_text(16,22)--��ȡ��ǰֵ

		if S5C3 == "250Hz"
		then
			set_text(16,22,"4KHz")--���ÿؼ���ֵ	
		elseif S5C3 == "4KHz"
		then
			set_text(16,22,"8KHz")--���ÿؼ���ֵ
		elseif S5C3 == "8KHz"
		then
			set_text(16,22,"16KHz")--���ÿؼ���ֵ
		elseif S5C3 == "16KHz"
		then
			set_text(16,22,"250Hz")--���ÿؼ���ֵ	
		end

		return 1
	elseif control==7 and value==0
	then
		return 1	

	--Gramma����
	elseif control==18 and value==1
	then
		S5C2 = get_text(16,23)--��ȡ��ǰֵ

		if S5C2 == "1.0"
		then
			set_text(16,23,"2.0")--���ÿؼ���ֵ	
		elseif S5C2 == "2.0"
		then
			set_text(16,23,"2.2")--���ÿؼ���ֵ
		elseif S5C2 == "2.2"
		then
			set_text(16,23,"2.4")--���ÿؼ���ֵ
		elseif S5C2 == "2.4"
		then
			set_text(16,23,"1.0")--���ÿؼ���ֵ	
		end
			
		return 1
	elseif control==18 and value==0
	then
		return 1

	--PWM����
	elseif control==17 and value==1
	then
		S5C3 = get_text(16,19)--��ȡ��ǰֵ

		if get_language() == 0--����
		then
			if S5C3 == "������"
			then
				set_text(16,19,"����250ns")--���ÿؼ���ֵ	
			elseif S5C3 == "����250ns"
			then
				set_text(16,19,"����500ns")--���ÿؼ���ֵ
			elseif S5C3 == "����500ns"
			then
				set_text(16,19,"����1us")--���ÿؼ���ֵ
			elseif S5C3 == "����1us"
			then
				set_text(16,19,"������")--���ÿؼ���ֵ	
			end
		elseif get_language() == 1--Ӣ��
		then
			if S5C3 == "No"
			then
				set_text(16,19,"add 250ns")--���ÿؼ���ֵ	
			elseif S5C3 == "add 250ns"
			then
				set_text(16,19,"add 500ns")--���ÿؼ���ֵ
			elseif S5C3 == "add 500ns"
			then
				set_text(16,19,"add 1us")--���ÿؼ���ֵ
			elseif S5C3 == "add 1us"
			then
				set_text(16,19,"No")--���ÿؼ���ֵ	
			end
		end

		return 1
	elseif control==17 and value==0
	then
		return 1

	--���ź�״̬
	elseif control==25 and value==1
	then
		S5C3 = get_text(16,24)--��ȡ��ǰֵ

		if get_language() == 0--����
		then
			if S5C3 == "�������һ֡"
			then
				set_text(16,24,"Ĭ�ϻҶ�")--���ÿؼ���ֵ	
			elseif S5C3 == "Ĭ�ϻҶ�"
			then
				set_text(16,24,"RGB�Լ�") --���ÿؼ���ֵ
			elseif S5C3 == "RGB�Լ�"
			then
				set_text(16,24,"��ɫ����")--���ÿؼ���ֵ
			elseif S5C3 == "��ɫ����"
			then
				set_text(16,24,"��ɫ����")--���ÿؼ���ֵ	
			elseif S5C3 == "��ɫ����"
			then
				set_text(16,24,"KTV����")--���ÿؼ���ֵ	
			elseif S5C3 == "KTV����"
			then
				set_text(16,24,"��/����+����")--���ÿؼ���ֵ	
			elseif S5C3 == "��/����+����"
			then
				set_text(16,24,"�������һ֡")--���ÿؼ���ֵ	
			end
		elseif get_language() == 1--Ӣ��
		then
			if S5C3 == "Last frame"
		then
			set_text(16,24,"Default")--���ÿؼ���ֵ	
			elseif S5C3 == "Default"
			then
				set_text(16,24,"RGB run") --���ÿؼ���ֵ
			elseif S5C3 == "RGB run"
			then
				set_text(16,24,"Color change")--���ÿؼ���ֵ
			elseif S5C3 == "Color change"
			then
				set_text(16,24,"Color gradient")--���ÿؼ���ֵ	
			elseif S5C3 == "Color gradient"
			then
				set_text(16,24,"KTV light")--���ÿؼ���ֵ	
			elseif S5C3 == "KTV light"
			then
				set_text(16,24,"Loop play")--���ÿؼ���ֵ	
			elseif S5C3 == "Loop play"
			then
				set_text(16,24,"Last frame")--���ÿؼ���ֵ	
			end
		end

		return 1
	elseif control==25 and value==0
	then
		return 1

	elseif control==14 and value==1
	then
		set_text(17,2,"Hi512D")--���ÿؼ���ֵ
		return 1
	elseif control==14 and value==0
	then
		return 1
	--16,5,28
	elseif control==5 and value==1
	then
		if get_language() == 0
		then
			set_text(16,28,"����")
		elseif get_language() == 1
		then
			set_text(16,28,"Open")
		end

		return 1
	elseif control==5 and value==0
	then
		if get_language() == 0
		then
			set_text(16,28,"�ر�")
		elseif get_language() == 1
		then
			set_text(16,28,"Close")
		end

		return 1
			--�ı��ϵ�������ɫ Hi512D 16
	elseif control >= 9 and control <= 11
	then
		rr = get_value(16,9)
		gg = get_value(16,10)
		bb = get_value(16,11)
		
		rr = ((rr>>3)<<11)&0xf800
		gg = ((gg>>2)<<5)&0x07e0
		bb = (bb>>3)&0x001f
	
		draw_pen_color = Or(rr,gg)
		draw_pen_color = Or(draw_pen_color,bb) 
		redraw() 
		
		return 1
	elseif control == 31 and value==1
	then
		rr = get_value(16,9)
		gg = get_value(16,10)
		bb = get_value(16,11)
		ww = get_value(16,12)
		nw = get_value(16,26)
		
		set_value(41,1,rr)
		set_value(41,2,gg)
		set_value(41,3,bb)
		set_value(41,4,ww)
		set_value(41,5,nw)
		
		set_value(41,8,rr)
		set_value(41,9,gg)
		set_value(41,10,bb)
		set_value(41,11,ww)
		set_value(41,12,nw)
		return 1
	elseif control == 31 and value==0
	then
		return 1
	--Hi512D д���� ����
	
	elseif control==13 and value==1
	then
		set_text(16,29,"Setting")

		tmp_dat[6] = 0x00--оƬ��Ŀ Ĭ��512
		tmp_dat[7] = 0x02
		
		tmp_dat[8] = get_value(16,21)-1--�ֶ�ѡ��

		ss = get_text(16,22)--ˢ����
		if ss == "250Hz"
		then
			tmp_dat[9] = 0
		elseif ss == "4KHz"
		then
			tmp_dat[9] = 1
		elseif  ss == "8KHz"
		then
			tmp_dat[9] = 2
		elseif  ss == "16KHz"
		then		
			tmp_dat[9] = 3
		end

		ss = get_text(16,23)--Gramma����
		if ss == "1.0"
		then
			tmp_dat[10] = 0
		elseif ss == "2.0"
		then
			tmp_dat[10] = 1
		elseif ss == "2.2"
		then
			tmp_dat[10] = 2
		elseif ss == "2.4"
		then		
			tmp_dat[10] = 3
		end

		tmp_dat[11] = get_value(16,5)--Grammaƽ��

		ss = get_text(16,19)--PWM����
		if ss == "������"
		then
			tmp_dat[12] = 0
		elseif ss == "No"
		then
			tmp_dat[12] = 0
		elseif ss == "����250ns"
		then
			tmp_dat[12] = 1
		elseif ss == "add 250ns"
		then
			tmp_dat[12] = 1
		elseif ss == "����500ns"
		then
			tmp_dat[12] = 2
		elseif ss == "add 500ns"
		then
			tmp_dat[12] = 2
		elseif ss == "����1us"
		then		
			tmp_dat[12] = 3
		elseif ss == "add 1us"
		then		
			tmp_dat[12] = 3
		end

		ss = get_text(16,24)--���ź�״̬
		if ss == "�������һ֡"
		then
			tmp_dat[13] = 0
		elseif ss == "Last frame"
		then
			tmp_dat[13] = 0
		elseif ss == "Ĭ�ϻҶ�"
		then
			tmp_dat[13] = 1
		elseif ss == "Default"
		then
			tmp_dat[13] = 1
		elseif ss == "RGB�Լ�"
		then
			tmp_dat[13] = 2
		elseif ss == "RGB run"
		then
			tmp_dat[13] = 2
		elseif ss == "��ɫ����"
		then		
			tmp_dat[13] = 3
		elseif ss == "Color change"
		then		
			tmp_dat[13] = 3
		elseif ss == "��ɫ����"
		then		
			tmp_dat[13] = 4
		elseif ss == "Color gradient"
		then		
			tmp_dat[13] = 4
		elseif ss == "KTV����"
		then		
			tmp_dat[13] = 5
		elseif ss == "KTV light"
		then		
			tmp_dat[13] = 5
		elseif ss == "��/����+����"
		then
			tmp_dat[13] = 6
		elseif ss == "Loop play"
		then
			tmp_dat[13] = 6
		end

		--�ϵ�����״̬
		tmp_dat[14] = get_value(16,9)--R
		tmp_dat[15] = get_value(16,10)--G
		tmp_dat[16] = get_value(16,11)--B
		tmp_dat[17] = get_value(16,12)--W
		tmp_dat[18] = get_value(16,26)--A	

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		send_cmd_xb[6] = 0x15--ָʾHi512D��д��������
		send_cmd_xb[7] = tmp_dat[8]--�ֶ���
		send_cmd_xb[8] = tmp_dat[9]--ˢ����
		send_cmd_xb[9] = tmp_dat[10]--Gramma����
		send_cmd_xb[10] =tmp_dat[11]--Grammaƽ������
		send_cmd_xb[11] =tmp_dat[12]--PWM����
		send_cmd_xb[12] =tmp_dat[13]--���ź�״̬
		send_cmd_xb[13] =tmp_dat[14]--R
		send_cmd_xb[14] =tmp_dat[15]--G
		send_cmd_xb[15] =tmp_dat[16]--B
		send_cmd_xb[16] =tmp_dat[17]--W
		send_cmd_xb[17] =tmp_dat[18]--A	
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	
			
		uart_send_data(send_cmd_xb) --��������

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
							
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ���̵�")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother green")
		end	
		
		change_screen(40)
		----

		return 1	
	elseif control==13 and value==0
	then
		return 1	

	--����д�����
	elseif control==30 and value==1
	then
		set_text(3,8,get_text(16,27))		
		change_screen(3)
		
		DMX_add_param = 0x33	
		return 1
	elseif control==30 and value==0
	then
		return 1
	end
end

function screen_17()
	screen = screen_t
	control = control_t
	value = value_t
	if control==9 and value==1
	then
		if get_language() == 0
		then
			set_text(17,28,"����")
		elseif get_language() == 1
		then
			set_text(17,28,"Open")
		end
		return 1
	elseif control==9 and value==0
	then
		if get_language() == 0
		then
			set_text(17,28,"�ر�")
		elseif get_language() == 1
		then
			set_text(17,28,"Close")
		end
		return 1

	--17,10,22
	elseif control==10 and value==1
	then
		if get_language() == 0
		then
			set_text(17,22,"д��EEPROM")
		elseif get_language() == 1
		then
			set_text(17,22,"Save to EEPROM")
		end

		return 1
	elseif control==10 and value==0
	then
		if get_language() == 0
		then
			set_text(17,22,"��д��EEPROM")
		elseif get_language() == 1
		then
			set_text(17,22,"No Save")
		end

		return 1
			--Hi512D �������� ����
	
	--Hi512D ��ַ�ر�
	elseif control==7 and value==1
	then
		set_text(17,29,"Setting")

		local old_add = get_value(17,5)--ԭʼ��ַ
		tmp_dat[7] = math.modf(old_add/256)
		tmp_dat[8] = math.modf(old_add%256)	
		
		local new_add = get_value(17,6)--�µ�ַ
		tmp_dat[9] = math.modf(new_add/256)
		tmp_dat[10] = math.modf(new_add%256)	

		tmp_dat[11] = math.modf(4095/256)--оƬ��Ŀ
		tmp_dat[12] = math.modf(4095%256)	

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		send_cmd_xb[6] = 0x17--ָʾHi512D ���ĵ��ŵ�ַ
		send_cmd_xb[7] = tmp_dat[7]
		send_cmd_xb[8] = tmp_dat[8]
		send_cmd_xb[9] = tmp_dat[9]
		send_cmd_xb[10] =tmp_dat[10]
		send_cmd_xb[11] =0
		send_cmd_xb[12] =0
		send_cmd_xb[13] =0
		send_cmd_xb[14] =0
		send_cmd_xb[15] =0
		send_cmd_xb[16] =0
		send_cmd_xb[17] =0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	
			
		uart_send_data(send_cmd_xb) --��������
	
		stop_timer(4)
		start_timer(4,time5,1,1)
	
		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ���̵�")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother green")
		end	

		change_screen(40)
		----
	
		return 1	
	elseif control==7 and value==0
	then
		return 1	

	----------------------------------------------------
	--Hi512D �Զ���ַ
	elseif control==13 and value==1
	then
		set_text(17,23,"Setting")

		tmp_dat[7]  = get_value(17,9)--�ر�/����
		tmp_dat[8]  = get_value(17,10)--�Ƿ�дeeprom
		
		tmp_dat[9] = get_value(17,12)--����

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		send_cmd_xb[6] = 0x18--ָʾHi512D �Զ���ַ
		send_cmd_xb[7] = tmp_dat[7]
		send_cmd_xb[8] = tmp_dat[8]
		send_cmd_xb[9] = tmp_dat[9]
		send_cmd_xb[10] =0
		send_cmd_xb[11] =0
		send_cmd_xb[12] =0
		send_cmd_xb[13] =0
		send_cmd_xb[14] =0
		send_cmd_xb[15] =0
		send_cmd_xb[16] =0
		send_cmd_xb[17] =0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	
			
		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ���̵�")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother green")
		end	
		
		change_screen(40)
		----

		return 1	
	elseif control==13 and value==0
	then
		return 1	

	------------------------------------------
	--Hi512D д��������
	elseif control==20 and value==1
	then
		set_text(17,24,"Setting")

		tmp_dat[8] = get_value(17,15)--R����
		tmp_dat[9] = get_value(17,16)--G
		tmp_dat[10] = get_value(17,17)--B
		tmp_dat[11] = get_value(17,18)--W
		tmp_dat[12] = get_value(17,19)--A	
				
		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		send_cmd_xb[6] = 0x16--ָʾHi512D д��������
		send_cmd_xb[7] = tmp_dat[8]
		send_cmd_xb[8] = tmp_dat[9]
		send_cmd_xb[9] = tmp_dat[10]
		send_cmd_xb[10] =tmp_dat[11]
		send_cmd_xb[11] =tmp_dat[12]
		send_cmd_xb[12] =0
		send_cmd_xb[13] =0
		send_cmd_xb[14] =0
		send_cmd_xb[15] =0
		send_cmd_xb[16] =0
		send_cmd_xb[17] =0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	
			
		uart_send_data(send_cmd_xb) --��������	
		
		stop_timer(4)
		start_timer(4,time5,1,1)
			
		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ���̵�")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother green")
		end	
		
		change_screen(40)
		----
			
		return 1	
	elseif control==20 and value==0
	then
		return 1			
	end
end

function screen_19()
	screen = screen_t
	control = control_t
	value = value_t
	if control==2 and value==1
	then
		S5C2 = get_value(19,4)
		S5C2 = S5C2 + 1	
		if S5C2>6
		then
			S5C2 = 1
		end
		set_value(19,4,S5C2)

		if get_language() == 0
		then
			if get_text(19,5) == "����"
			then
				mode = 12
			else
				mode = 0
				set_text(19,5,"ͨ��һ")
			end
		elseif get_language() == 1
		then
			if get_text(19,5) == "Count"
			then
				mode = 12
			else
				mode = 0
				set_text(19,5,"CH1")
			end
		end

		Test_chip_sel()

		brightness = get_value(19,8)--��������

		if mode == 12--����ģʽ
		then
			run_num_tt=get_value(19,19)	
			Send_cmd(0xe2,ic_sel_test,S5C2,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)
		else
			Send_cmd(0xe2,ic_sel_test,S5C2,mode,brightness,0,0,0,0)--�л�ͨ����Ĭ�ϻص���ͨ���Ľ�Ŀ1	
		end	
		return 1
	elseif control==2 and value==0
	then
		return 1

	--ͨ������ 
	--e2�����ʽ  e2 chip ͨ���� ��Ŀ�� �������� 0 0 0 0 
	elseif control==3 and value==1
	then
		ch = get_value(19,4)--ͨ����
		brightness = get_value(19,8)--��������	

		Test_chip_sel()

		ss = get_text(19,5)--ģʽѡ��

		if get_language() == 0
		then
			if ss == "����"
			then
				--����Ҫ����������еı��
				auto_run_tt = 0
				set_value(19,14,0)
				set_text(19,15,"�� �� �� ��")	
			
				set_text(19,5,"ͨ��һ")	
				Send_cmd(0xe2,ic_sel_test,ch,0,brightness,0,0,0,0)	
			else
				if test_flash == 0x55 --�ոս���������棬��һ���л�Ч����ͨ�������ܱ�
				then
					test_flash = 0
					
					if ss == "ͨ��һ"
					then
						Send_cmd(0xe2,ic_sel_test,ch,0,brightness,0,0,0,0)					
					elseif ss == "ͨ����"
					then
						Send_cmd(0xe2,ic_sel_test,ch,1,brightness,0,0,0,0)
					elseif ss == "ͨ����"
					then
						Send_cmd(0xe2,ic_sel_test,ch,2,brightness,0,0,0,0)
					elseif ss == "ͨ����"
					then
						Send_cmd(0xe2,ic_sel_test,ch,3,brightness,0,0,0,0)		
					elseif ss == "ͨ����"
					then
						Send_cmd(0xe2,ic_sel_test,ch,4,brightness,0,0,0,0)	
					elseif ss == "ͨ����"
					then
						Send_cmd(0xe2,ic_sel_test,ch,5,brightness,0,0,0,0)	
					elseif ss == "ȫ��"
					then
						Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)
					elseif ss == "ȫ��"
					then
						Send_cmd(0xe2,ic_sel_test,ch,7,brightness,0,0,0,0)			
					elseif ss == "ȫ��ȫ��������"	
					then
						Send_cmd(0xe2,ic_sel_test,ch,8,brightness,0,0,0,0)		
					elseif ss == "ȫͨ����������"
					then
						Send_cmd(0xe2,ic_sel_test,ch,9,brightness,0,0,0,0)	
					elseif ss == "ȫͨ�����潥��"
					then
						Send_cmd(0xe2,ic_sel_test,ch,13,brightness,0,0,0,0)	
					elseif ss == "ȫͨ�����彥��"
					then
						Send_cmd(0xe2,ic_sel_test,ch,14,brightness,0,0,0,0)	
					elseif ss == "����ɨ��"
					then
						Send_cmd(0xe2,ic_sel_test,ch,10,brightness,0,0,0,0)		
					end
				else
					if ss == "ͨ��һ"
					then
						if ch == 1
						then
							set_text(19,5,"ȫ��")
							Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
						else
							set_text(19,5,"ͨ����")
							Send_cmd(0xe2,ic_sel_test,ch,1,brightness,0,0,0,0)
						end					
					elseif ss == "ͨ����"
					then
						if ch == 2
						then
							set_text(19,5,"ȫ��")
							Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
						else
							set_text(19,5,"ͨ����")
							Send_cmd(0xe2,ic_sel_test,ch,2,brightness,0,0,0,0)		
						end
					elseif ss == "ͨ����"
					then
						if ch == 3
						then
							set_text(19,5,"ȫ��")
							Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
						else
							set_text(19,5,"ͨ����")
							Send_cmd(0xe2,ic_sel_test,ch,3,brightness,0,0,0,0)		
						end	
					elseif ss == "ͨ����"
					then
						if ch == 4
						then
							set_text(19,5,"ȫ��")
							Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
						else
							set_text(19,5,"ͨ����")
							Send_cmd(0xe2,ic_sel_test,ch,4,brightness,0,0,0,0)		
						end		
					elseif ss == "ͨ����"
					then
						if ch == 5
						then
							set_text(19,5,"ȫ��")
							Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
						else
							set_text(19,5,"ͨ����")
							Send_cmd(0xe2,ic_sel_test,ch,5,brightness,0,0,0,0)		
						end	
					elseif ss == "ͨ����"
					then
						set_text(19,5,"ȫ��")
						Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)				
					elseif ss == "ȫ��"
					then
						set_text(19,5,"ȫ��")	
						Send_cmd(0xe2,ic_sel_test,ch,7,brightness,0,0,0,0)	
					elseif ss == "ȫ��"
					then
						set_text(19,5,"ȫ��ȫ��������")	
						Send_cmd(0xe2,ic_sel_test,ch,8,brightness,0,0,0,0)				
					elseif ss == "ȫ��ȫ��������"	
					then
						set_text(19,5,"ȫͨ����������")	
						Send_cmd(0xe2,ic_sel_test,ch,9,brightness,0,0,0,0)	
					elseif ss == "ȫͨ����������"
					then
						set_text(19,5,"ȫͨ�����潥��")	
						Send_cmd(0xe2,ic_sel_test,ch,13,brightness,0,0,0,0)		
					elseif ss == "ȫͨ�����潥��"
					then
						set_text(19,5,"ȫͨ�����彥��")	
						Send_cmd(0xe2,ic_sel_test,ch,14,brightness,0,0,0,0)		
					elseif ss == "ȫͨ�����彥��"
					then
						set_text(19,5,"����ɨ��")	
						Send_cmd(0xe2,ic_sel_test,ch,10,brightness,0,0,0,0)			
					elseif ss == "����ɨ��"
					then
						set_text(19,5,"ͨ��һ")	
						Send_cmd(0xe2,ic_sel_test,ch,0,brightness,0,0,0,0)			
					end	
				end
			end
		elseif get_language() == 1
		then
			if ss == "Count"
			then
				--����Ҫ����������еı��
				auto_run_tt = 0
				set_value(19,14,0)
				set_text(19,15,"Auto Count")		
			
				set_text(19,5,"CH1")	
				Send_cmd(0xe2,ic_sel_test,ch,0,brightness,0,0,0,0)	
			else
				if test_flash == 0x55 --�ոս���������棬��һ���л�Ч����ͨ�������ܱ�
				then
					test_flash = 0
					
					if ss == "CH1"
					then
						Send_cmd(0xe2,ic_sel_test,ch,0,brightness,0,0,0,0)					
					elseif ss == "CH2"
					then
						Send_cmd(0xe2,ic_sel_test,ch,1,brightness,0,0,0,0)
					elseif ss == "CH3"
					then
						Send_cmd(0xe2,ic_sel_test,ch,2,brightness,0,0,0,0)
					elseif ss == "CH4"
					then
						Send_cmd(0xe2,ic_sel_test,ch,3,brightness,0,0,0,0)		
					elseif ss == "CH5"
					then
						Send_cmd(0xe2,ic_sel_test,ch,4,brightness,0,0,0,0)	
					elseif ss == "CH6"
					then
						Send_cmd(0xe2,ic_sel_test,ch,5,brightness,0,0,0,0)	
					elseif ss == "All bright"
					then
						Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)
					elseif ss == "All black"
					then
						Send_cmd(0xe2,ic_sel_test,ch,7,brightness,0,0,0,0)			
					elseif ss == "Bright black change"	
					then
						Send_cmd(0xe2,ic_sel_test,ch,8,brightness,0,0,0,0)		
					elseif ss == "All ch change"
					then
						Send_cmd(0xe2,ic_sel_test,ch,9,brightness,0,0,0,0)	
					elseif ss == "All ch gradient"
					then
						Send_cmd(0xe2,ic_sel_test,ch,13,brightness,0,0,0,0)	
					elseif ss == "All gradient"
					then
						Send_cmd(0xe2,ic_sel_test,ch,14,brightness,0,0,0,0)	
					elseif ss == "Single light run"
					then
						Send_cmd(0xe2,ic_sel_test,ch,10,brightness,0,0,0,0)		
					end
				else
					if ss == "CH1"
					then
						if ch == 1
						then
							set_text(19,5,"All bright")
							Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
						else
							set_text(19,5,"CH2")
							Send_cmd(0xe2,ic_sel_test,ch,1,brightness,0,0,0,0)
						end					
					elseif ss == "CH2"
					then
						if ch == 2
						then
							set_text(19,5,"All bright")
							Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
						else
							set_text(19,5,"CH3")
							Send_cmd(0xe2,ic_sel_test,ch,2,brightness,0,0,0,0)		
						end
					elseif ss == "CH3"
					then
						if ch == 3
						then
							set_text(19,5,"All bright")
							Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
						else
							set_text(19,5,"CH4")
							Send_cmd(0xe2,ic_sel_test,ch,3,brightness,0,0,0,0)		
						end	
					elseif ss == "CH4"
					then
						if ch == 4
						then
							set_text(19,5,"All bright")
							Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
						else
							set_text(19,5,"CH5")
							Send_cmd(0xe2,ic_sel_test,ch,4,brightness,0,0,0,0)		
						end		
					elseif ss == "CH5"
					then
						if ch == 5
						then
							set_text(19,5,"All bright")
							Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
						else
							set_text(19,5,"CH6")
							Send_cmd(0xe2,ic_sel_test,ch,5,brightness,0,0,0,0)		
						end	
					elseif ss == "CH6"
					then
						set_text(19,5,"All bright")
						Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)				
					elseif ss == "All bright"
					then
						set_text(19,5,"All black")	
						Send_cmd(0xe2,ic_sel_test,ch,7,brightness,0,0,0,0)	
					elseif ss == "All black"
					then
						set_text(19,5,"Bright black change")	
						Send_cmd(0xe2,ic_sel_test,ch,8,brightness,0,0,0,0)				
					elseif ss == "Bright black change"	
					then
						set_text(19,5,"All ch change")	
						Send_cmd(0xe2,ic_sel_test,ch,9,brightness,0,0,0,0)	
					elseif ss == "All ch change"
					then
						set_text(19,5,"All ch gradient")	
						Send_cmd(0xe2,ic_sel_test,ch,13,brightness,0,0,0,0)	
					elseif ss == "All ch gradient"
					then
						set_text(19,5,"All gradient")	
						Send_cmd(0xe2,ic_sel_test,ch,14,brightness,0,0,0,0)
					elseif ss == "All gradient"
					then
						set_text(19,5,"Single light run")	
						Send_cmd(0xe2,ic_sel_test,ch,10,brightness,0,0,0,0)	
					elseif ss == "Single light run"
					then
						set_text(19,5,"CH1")	
						Send_cmd(0xe2,ic_sel_test,ch,0,brightness,0,0,0,0)			
					end	
				end
			end
		end
		return 1
	elseif control==3 and value==0
	then
		return 1

	--�ı����Ⱥ󣬷���һ������
	elseif control==8
	then
		ch = get_value(19,4)--ͨ����
		brightness = get_value(19,8)--��������	

		ss = get_text(19,5)--ģʽѡ��
		
		Test_chip_sel()
		
		if get_language() == 0
		then
			if ss == "ͨ��һ"
			then
				mode = 0
			elseif ss == "ͨ����"
			then
				mode = 1
			elseif ss == "ͨ����"
			then
				mode = 2
			elseif ss == "ͨ����"
			then
				mode = 3
			elseif ss == "ͨ����"
			then
				mode = 4
			elseif ss == "ͨ����"
			then
				mode = 5
			elseif ss == "ȫ��"
			then
				mode = 6
			elseif ss == "ȫ��"
			then
				mode = 7
			elseif ss == "ȫ��ȫ��������"
			then
				mode = 8
			elseif ss == "ȫͨ����������"
			then
				mode = 9
			elseif ss == "ȫͨ�����潥��"
			then
				mode = 13
			elseif ss == "ȫͨ�����彥��"
			then
				mode = 14
			elseif ss == "����ɨ��"
			then
				mode = 10
			elseif ss == "����"
			then
				mode = 12
			end
		elseif get_language() == 1
		then
			if ss == "CH1"
			then
				mode = 0
			elseif ss == "CH2"
			then
				mode = 1
			elseif ss == "CH3"
			then
				mode = 2
			elseif ss == "CH4"
			then
				mode = 3
			elseif ss == "CH5"
			then
				mode = 4
			elseif ss == "CH6"
			then
				mode = 5
			elseif ss == "All bright"
			then
				mode = 6
			elseif ss == "All black"
			then
				mode = 7
			elseif ss == "Bright black change"
			then
				mode = 8
			elseif ss == "All ch change"
			then
				mode = 9
			elseif ss == "All ch gradient"
			then
				mode = 13
			elseif ss == "All gradient"
			then
				mode = 14
			elseif ss == "Single light run"
			then
				mode = 10
			elseif ss == "Count"
			then
				mode = 12
			end
		end

		if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
		then
			run_num_tt=get_value(19,19)	
			Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
		else
			Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
		end

		return 1

	elseif control==12
	then
		change_screen(43)
		return 1
	--����� ��
	elseif control==16 and value==1
	then	
		ch = get_value(19,4)--ͨ����
		brightness = get_value(19,8)--��������	

		Test_chip_sel()
	
		if get_language() == 0--����
		then
			--set_text(19,5,"����")	
			set_text(19,15,"�� �� �� ��")	
		elseif get_language() == 1--Ӣ��
		then
			--set_text(19,5,"Count")	
			set_text(19,15,"Auto Count")	
		end
	
		auto_run_tt = 0
		set_value(19,14,0)

		run_num_tt=get_value(19,19)	
		if  run_num_tt > 0
		then
			run_num_tt = run_num_tt - 1
		end		
		set_value(19,19,run_num_tt)
	
		if get_value(19,21) == 0
		then
			sd_guiji = 0x00--Ĭ�ϲ���������켣
		else
			sd_guiji = 0x55--��������켣
		end
		
		ss = get_text(19,5)--ģʽѡ��
		if get_language() == 0
		then
			if ss == "ͨ��һ"
			then
				mode = 0
			elseif ss == "ͨ����"
			then
				mode = 1
			elseif ss == "ͨ����"
			then
				mode = 2
			elseif ss == "ͨ����"
			then
				mode = 3
			elseif ss == "ͨ����"
			then
				mode = 4
			elseif ss == "ͨ����"
			then
				mode = 5
			elseif ss == "ȫ��"
			then
				mode = 6
			end
		elseif get_language() == 1
		then
			if ss == "CH1"
			then
				mode = 0
			elseif ss == "CH2"
			then
				mode = 1
			elseif ss == "CH3"
			then
				mode = 2
			elseif ss == "CH4"
			then
				mode = 3
			elseif ss == "CH5"
			then
				mode = 4
			elseif ss == "CH6"
			then
				mode = 5
			elseif ss == "All bright"
			then
				mode = 6
			end
	    end
		
		Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),sd_guiji,mode)	
		return 1
	elseif control==16 and value==2
	then	
		ch = get_value(19,4)--ͨ����
		brightness = get_value(19,8)--��������	

		Test_chip_sel()
	
		if get_language() == 0--����
		then
			--set_text(19,5,"����")	
			set_text(19,15,"�� �� �� ��")	
		elseif get_language() == 1--Ӣ��
		then
			--set_text(19,5,"Count")	
			set_text(19,15,"Auto Count")	
		end
	
		auto_run_tt = 0
		set_value(19,14,0)

		run_num_tt=get_value(19,19)	
		if  run_num_tt > 0
		then
			run_num_tt = run_num_tt - 1
		end		
		set_value(19,19,run_num_tt)
	
		if get_value(19,21) == 0
		then
			sd_guiji = 0x00--Ĭ�ϲ���������켣
		else
			sd_guiji = 0x55--��������켣
		end
		
		ss = get_text(19,5)--ģʽѡ��
		if get_language() == 0
		then
			if ss == "ͨ��һ"
			then
				mode = 0
			elseif ss == "ͨ����"
			then
				mode = 1
			elseif ss == "ͨ����"
			then
				mode = 2
			elseif ss == "ͨ����"
			then
				mode = 3
			elseif ss == "ͨ����"
			then
				mode = 4
			elseif ss == "ͨ����"
			then
				mode = 5
			elseif ss == "ȫ��"
			then
				mode = 6
			end
		elseif get_language() == 1
		then
			if ss == "CH1"
			then
				mode = 0
			elseif ss == "CH2"
			then
				mode = 1
			elseif ss == "CH3"
			then
				mode = 2
			elseif ss == "CH4"
			then
				mode = 3
			elseif ss == "CH5"
			then
				mode = 4
			elseif ss == "CH6"
			then
				mode = 5
			elseif ss == "All bright"
			then
				mode = 6
			end
	    end
	
		Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),sd_guiji,mode)	
		return 1
	elseif control==16 and value==0
	then	
		return 1

	--����� ��
	elseif control==17 and value==1
	then	
		ch = get_value(19,4)--ͨ����
		brightness = get_value(19,8)--��������	
	
		if get_language() == 0--����
		then
			--set_text(19,5,"����")	
			set_text(19,15,"�� �� �� ��")	
		elseif get_language() == 1--Ӣ��
		then
			--set_text(19,5,"Count")	
			set_text(19,15,"Auto Count")	
		end
	
		auto_run_tt = 0
		set_value(19,14,0)
	
		run_num_tt=get_value(19,19)
		run_num_tt=run_num_tt+1	
		if  run_num_tt*ch > 3072
		then
			run_num_tt = 0
		end		
		set_value(19,19,run_num_tt)
	
		if get_value(19,21) == 0
		then
			sd_guiji = 0x00--Ĭ�ϲ���������켣
		else
			sd_guiji = 0x55--��������켣
		end
		
		ss = get_text(19,5)--ģʽѡ��
		if get_language() == 0
		then
			if ss == "ͨ��һ"
			then
				mode = 0
			elseif ss == "ͨ����"
			then
				mode = 1
			elseif ss == "ͨ����"
			then
				mode = 2
			elseif ss == "ͨ����"
			then
				mode = 3
			elseif ss == "ͨ����"
			then
				mode = 4
			elseif ss == "ͨ����"
			then
				mode = 5
			elseif ss == "ȫ��"
			then
				mode = 6
			end
		elseif get_language() == 1
		then
			if ss == "CH1"
			then
				mode = 0
			elseif ss == "CH2"
			then
				mode = 1
			elseif ss == "CH3"
			then
				mode = 2
			elseif ss == "CH4"
			then
				mode = 3
			elseif ss == "CH5"
			then
				mode = 4
			elseif ss == "CH6"
			then
				mode = 5
			elseif ss == "All bright"
			then
				mode = 6
			end
	    end

		Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),sd_guiji,mode)	
		return 1
	elseif control==17 and value==2
	then	
		ch = get_value(19,4)--ͨ����
		brightness = get_value(19,8)--��������	

		Test_chip_sel()
	
		if get_language() == 0--����
		then
			--set_text(19,5,"����")	
			set_text(19,15,"�� �� �� ��")	
		elseif get_language() == 1--Ӣ��
		then
			--set_text(19,5,"Count")	
			set_text(19,15,"Auto Count")	
		end
	
		auto_run_tt = 0
		set_value(19,14,0)
	
		run_num_tt=get_value(19,19)
		run_num_tt=run_num_tt+1	
		if  run_num_tt*ch > 3072
		then
			run_num_tt = 0
		end		
		set_value(19,19,run_num_tt)

		if get_value(19,21) == 0
		then
			sd_guiji = 0x00--Ĭ�ϲ���������켣
		else
			sd_guiji = 0x55--��������켣
		end
		
		ss = get_text(19,5)--ģʽѡ��
		if get_language() == 0
		then
			if ss == "ͨ��һ"
			then
				mode = 0
			elseif ss == "ͨ����"
			then
				mode = 1
			elseif ss == "ͨ����"
			then
				mode = 2
			elseif ss == "ͨ����"
			then
				mode = 3
			elseif ss == "ͨ����"
			then
				mode = 4
			elseif ss == "ͨ����"
			then
				mode = 5
			elseif ss == "ȫ��"
			then
				mode = 6
			end
		elseif get_language() == 1
		then
			if ss == "CH1"
			then
				mode = 0
			elseif ss == "CH2"
			then
				mode = 1
			elseif ss == "CH3"
			then
				mode = 2
			elseif ss == "CH4"
			then
				mode = 3
			elseif ss == "CH5"
			then
				mode = 4
			elseif ss == "CH6"
			then
				mode = 5
			elseif ss == "All bright"
			then
				mode = 6
			end
	    end

		Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),sd_guiji,mode)	
		return 1
	elseif control==17 and value==0
	then	
		return 1

	 --���Ե�ַ �Զ����Ե�ַ
	elseif control==14 and value==1
	then
		auto_run_tt = 0x55

		if get_language() == 0--����
		then
			--set_text(19,5,"����")
			set_text(19,15,"ͣ ֹ �� ��")	
		elseif get_language() == 1--Ӣ��
		then
			--set_text(19,5,"Count")	
			set_text(19,15,"Stop Count")	
		end
		
		return 1
	elseif control==14 and value==0
	then
		auto_run_tt = 0

		if get_language() == 0--����
		then
			--set_text(19,5,"����")
			set_text(19,15,"�� �� �� ��")	
		elseif get_language() == 1--Ӣ��
		then
			--set_text(19,5,"Count")
			set_text(19,15,"Auto Count")	
		end
		return 1

	--���ص�������2ʱ��Ҫ��ͣ����
	elseif control==18 and value==1
	then	
		Send_cmd(0xb0,0,0,0,0,0,0,0,0)	
		change_screen(2)
		return 1
	elseif control==18 and value==0
	then
		auto_run_tt = 0
	
		set_value(19,14,0)
		if get_language() == 0--����
		then
			set_text(19,15,"�� �� �� ��")	
		elseif get_language() == 1--Ӣ��
		then
			set_text(19,15,"Auto Count")	
		end
		return 1
	
	--�л����޼����� ����
	elseif control==6 and value==1
	then	
		auto_run_tt = 0
		
		set_value(19,14,0)
		if get_language() == 0--����
		then
			set_text(19,15,"�� �� �� ��")	
		elseif get_language() == 1--Ӣ��
		then
			set_text(19,15,"Auto Count")	
		end
		return 1
	elseif control==6 and value==0
	then	
		return 1

	--�޸������ ���Ͳ��Ե�ַ����
	elseif control==19 or control==21
	then
		ch = get_value(19,4)--ͨ����
		brightness = get_value(19,8)--��������	

		Test_chip_sel()
	
		run_num_tt=get_value(19,19)

		if get_value(19,21) == 0
		then
			sd_guiji = 0x00--Ĭ�ϲ���������켣
		else
			sd_guiji = 0x55--��������켣
		end
		
		ss = get_text(19,5)--ģʽѡ��
		if get_language() == 0
		then
			if ss == "ͨ��һ"
			then
				mode = 0
			elseif ss == "ͨ����"
			then
				mode = 1
			elseif ss == "ͨ����"
			then
				mode = 2
			elseif ss == "ͨ����"
			then
				mode = 3
			elseif ss == "ͨ����"
			then
				mode = 4
			elseif ss == "ͨ����"
			then
				mode = 5
			elseif ss == "ȫ��"
			then
				mode = 6
			end
		elseif get_language() == 1
		then
			if ss == "CH1"
			then
				mode = 0
			elseif ss == "CH2"
			then
				mode = 1
			elseif ss == "CH3"
			then
				mode = 2
			elseif ss == "CH4"
			then
				mode = 3
			elseif ss == "CH5"
			then
				mode = 4
			elseif ss == "CH6"
			then
				mode = 5
			elseif ss == "All bright"
			then
				mode = 6
			end
        end
		Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),sd_guiji,mode)	
	
		return 1
	elseif control==22 and value==1
	then
		S5C2 = get_value(19,4)
		if S5C2>1
		then
			S5C2 = S5C2 -1
		else
			S5C2 = 1
		end
		
		set_value(19,4,S5C2)

		if get_language() == 0
		then
			if get_text(19,5) == "����"
			then
				mode = 12
			else
				mode = 0
				set_text(19,5,"ͨ��һ")
			end
		elseif get_language() == 1
		then
			if get_text(19,5) == "Count"
			then
				mode = 12
			else
				mode = 0
				set_text(19,5,"CH1")
			end
		end

		Test_chip_sel()
		
		brightness = get_value(19,8)--��������
		
		if mode == 12--����ģʽ
		then
			run_num_tt=get_value(19,19)	
			Send_cmd(0xe2,ic_sel_test,S5C2,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)
		else
			Send_cmd(0xe2,ic_sel_test,S5C2,mode,brightness,0,0,0,0)--�л�ͨ����Ĭ�ϻص���ͨ���Ľ�Ŀ1	
		end	
		return 1
	elseif control==22 and value==0
	then
		return 1
	elseif control==23 and value==1
	then
		S5C2 = get_value(19,4)
		S5C2 = S5C2 + 1	
		if S5C2>6
		then
			S5C2 = 6
		end
	
		set_value(19,4,S5C2)

		if get_language() == 0
		then
			if get_text(19,5) == "����"
			then
				mode = 12
			else
				mode = 0
				set_text(19,5,"ͨ��һ")
			end
		elseif get_language() == 1
		then
			if get_text(19,5) == "Count"
			then
				mode = 12
			else
				mode = 0
				set_text(19,5,"CH1")
			end
		end

		Test_chip_sel()
		
		brightness = get_value(19,8)--��������
		
		if mode == 12--����ģʽ
		then
			run_num_tt=get_value(19,19)	
			Send_cmd(0xe2,ic_sel_test,S5C2,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)
		else
			Send_cmd(0xe2,ic_sel_test,S5C2,mode,brightness,0,0,0,0)--�л�ͨ����Ĭ�ϻص���ͨ���Ľ�Ŀ1	
		end	
		return 1
	elseif control==23 and value==0
	then
		return 1
	elseif control==24 and value==1
	then
		ch = get_value(19,4)--ͨ����
		brightness = get_value(19,8)--��������	

		Test_chip_sel()

		ss = get_text(19,5)--ģʽѡ��

		if get_language() == 0
		then
			if ss == "����"
			then
				--����Ҫ����������еı��
				auto_run_tt = 0
				set_value(19,14,0)
				set_text(19,15,"�� �� �� ��")	
			
				set_text(19,5,"ͨ��һ")	
				Send_cmd(0xe2,ic_sel_test,ch,0,brightness,0,0,0,0)	
			else
				if ss == "����ɨ��"
				then
					set_text(19,5,"ȫͨ�����彥��")	
					Send_cmd(0xe2,ic_sel_test,ch,14,brightness,0,0,0,0)	
				elseif ss == "ȫͨ�����彥��"
				then
					set_text(19,5,"ȫͨ�����潥��")	
					Send_cmd(0xe2,ic_sel_test,ch,13,brightness,0,0,0,0)	
				elseif ss == "ȫͨ�����潥��"
				then
					set_text(19,5,"ȫͨ����������")	
					Send_cmd(0xe2,ic_sel_test,ch,9,brightness,0,0,0,0)
				elseif ss == "ȫͨ����������"	
				then
					set_text(19,5,"ȫ��ȫ��������")	
					Send_cmd(0xe2,ic_sel_test,ch,8,brightness,0,0,0,0)	
				elseif ss == "ȫ��ȫ��������"	
				then
					set_text(19,5,"ȫ��")	
					Send_cmd(0xe2,ic_sel_test,ch,7,brightness,0,0,0,0)			
				elseif ss == "ȫ��"	
				then
					set_text(19,5,"ȫ��")
					Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)
				elseif ss == "ȫ��"	
				then
					if ch == 6
					then
						set_text(19,5,"ͨ����")
						Send_cmd(0xe2,ic_sel_test,ch,5,brightness,0,0,0,0)	
					elseif ch == 5
					then
						set_text(19,5,"ͨ����")
						Send_cmd(0xe2,ic_sel_test,ch,4,brightness,0,0,0,0)
					elseif ch == 4
					then
						set_text(19,5,"ͨ����")
						Send_cmd(0xe2,ic_sel_test,ch,3,brightness,0,0,0,0)
					elseif ch == 3
					then
						set_text(19,5,"ͨ����")
						Send_cmd(0xe2,ic_sel_test,ch,2,brightness,0,0,0,0)
					elseif ch == 2
					then
						set_text(19,5,"ͨ����")
						Send_cmd(0xe2,ic_sel_test,ch,1,brightness,0,0,0,0)
					elseif ch == 1
					then
						set_text(19,5,"ͨ��һ")
						Send_cmd(0xe2,ic_sel_test,ch,0,brightness,0,0,0,0)	
					end
				elseif ss == "ͨ����"
				then
					set_text(19,5,"ͨ����")
					Send_cmd(0xe2,ic_sel_test,ch,4,brightness,0,0,0,0)
				elseif ss == "ͨ����"
				then
					set_text(19,5,"ͨ����")
					Send_cmd(0xe2,ic_sel_test,ch,3,brightness,0,0,0,0)
				elseif ss == "ͨ����"
				then
					set_text(19,5,"ͨ����")
					Send_cmd(0xe2,ic_sel_test,ch,2,brightness,0,0,0,0)
				elseif ss == "ͨ����"
				then
					set_text(19,5,"ͨ����")
					Send_cmd(0xe2,ic_sel_test,ch,1,brightness,0,0,0,0)
				elseif ss == "ͨ����"
				then
					set_text(19,5,"ͨ��һ")
					Send_cmd(0xe2,ic_sel_test,ch,0,brightness,0,0,0,0)
				elseif ss == "ͨ��һ"
				then
					set_text(19,5,"ͨ��һ")
					Send_cmd(0xe2,ic_sel_test,ch,0,brightness,0,0,0,0)	
				end	
			end
		elseif get_language() == 1
		then
			if ss == "Count"
			then
				--����Ҫ����������еı��
				auto_run_tt = 0
				set_value(19,14,0)
				set_text(19,15,"Auto Count")		
			
				set_text(19,5,"CH1")	
				Send_cmd(0xe2,ic_sel_test,ch,0,brightness,0,0,0,0)	
			else
				if ss == "Single light run"
				then
					set_text(19,5,"All gradient")		
					Send_cmd(0xe2,ic_sel_test,ch,14,brightness,0,0,0,0)	
				elseif ss == "All gradient"
				then
					set_text(19,5,"All ch gradient")
					Send_cmd(0xe2,ic_sel_test,ch,13,brightness,0,0,0,0)	
				elseif ss == "All ch gradient"
				then
					set_text(19,5,"All ch change")	
					Send_cmd(0xe2,ic_sel_test,ch,9,brightness,0,0,0,0)
				elseif ss == "All ch change"	
				then
					set_text(19,5,"Bright black change")	
					Send_cmd(0xe2,ic_sel_test,ch,8,brightness,0,0,0,0)	
				elseif ss == "Bright black change"	
				then
					set_text(19,5,"All black")	
					Send_cmd(0xe2,ic_sel_test,ch,7,brightness,0,0,0,0)			
				elseif ss == "All black"	
				then
					set_text(19,5,"bright")
					Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)
				elseif ss == "bright"	
				then
					if ch == 6
					then
						set_text(19,5,"CH6")
						Send_cmd(0xe2,ic_sel_test,ch,5,brightness,0,0,0,0)	
					elseif ch == 5
					then
						set_text(19,5,"CH5")
						Send_cmd(0xe2,ic_sel_test,ch,4,brightness,0,0,0,0)
					elseif ch == 4
					then
						set_text(19,5,"CH4")
						Send_cmd(0xe2,ic_sel_test,ch,3,brightness,0,0,0,0)
					elseif ch == 3
					then
						set_text(19,5,"CH3")
						Send_cmd(0xe2,ic_sel_test,ch,2,brightness,0,0,0,0)
					elseif ch == 2
					then
						set_text(19,5,"CH2")
						Send_cmd(0xe2,ic_sel_test,ch,1,brightness,0,0,0,0)
					elseif ch == 1
					then
						set_text(19,5,"CH1")
						Send_cmd(0xe2,ic_sel_test,ch,0,brightness,0,0,0,0)	
					end
				elseif ss == "CH6"
				then
					set_text(19,5,"CH5")
					Send_cmd(0xe2,ic_sel_test,ch,4,brightness,0,0,0,0)
				elseif ss == "CH5"
				then
					set_text(19,5,"CH4")
					Send_cmd(0xe2,ic_sel_test,ch,3,brightness,0,0,0,0)
				elseif ss == "CH4"
				then
					set_text(19,5,"CH3")
					Send_cmd(0xe2,ic_sel_test,ch,2,brightness,0,0,0,0)
				elseif ss == "CH3"
				then
					set_text(19,5,"CH2")
					Send_cmd(0xe2,ic_sel_test,ch,1,brightness,0,0,0,0)
				elseif ss == "CH2"
				then
					set_text(19,5,"CH1")
					Send_cmd(0xe2,ic_sel_test,ch,0,brightness,0,0,0,0)
				elseif ss == "CH1"
				then
					set_text(19,5,"CH1")
					Send_cmd(0xe2,ic_sel_test,ch,0,brightness,0,0,0,0)	
				end	
			end
		end
		return 1
	elseif control==24 and value==0
	then
		return 1
	elseif control==25 and value==1
	then
		ch = get_value(19,4)--ͨ����
		brightness = get_value(19,8)--��������	

		Test_chip_sel()

		ss = get_text(19,5)--ģʽѡ��

		if get_language() == 0
		then
			if ss == "����"
			then
				--����Ҫ����������еı��
				auto_run_tt = 0
				set_value(19,14,0)
				set_text(19,15,"�� �� �� ��")	
			
				set_text(19,5,"ͨ��һ")	
				Send_cmd(0xe2,ic_sel_test,ch,0,brightness,0,0,0,0)	
			else
				if ss == "ͨ��һ"
				then
					if ch == 1
					then
						set_text(19,5,"ȫ��")
						Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
					else
						set_text(19,5,"ͨ����")
						Send_cmd(0xe2,ic_sel_test,ch,1,brightness,0,0,0,0)
					end					
				elseif ss == "ͨ����"
				then
					if ch == 2
					then
						set_text(19,5,"ȫ��")
						Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
					else
						set_text(19,5,"ͨ����")
						Send_cmd(0xe2,ic_sel_test,ch,2,brightness,0,0,0,0)		
					end
				elseif ss == "ͨ����"
				then
					if ch == 3
					then
						set_text(19,5,"ȫ��")
						Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
					else
						set_text(19,5,"ͨ����")
						Send_cmd(0xe2,ic_sel_test,ch,3,brightness,0,0,0,0)		
					end	
				elseif ss == "ͨ����"
				then
					if ch == 4
					then
						set_text(19,5,"ȫ��")
						Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
					else
						set_text(19,5,"ͨ����")
						Send_cmd(0xe2,ic_sel_test,ch,4,brightness,0,0,0,0)		
					end		
				elseif ss == "ͨ����"
				then
					if ch == 5
					then
						set_text(19,5,"ȫ��")
						Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
					else
						set_text(19,5,"ͨ����")
						Send_cmd(0xe2,ic_sel_test,ch,5,brightness,0,0,0,0)		
					end	
				elseif ss == "ͨ����"
				then
					set_text(19,5,"ȫ��")
					Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)				
				elseif ss == "ȫ��"
				then
					set_text(19,5,"ȫ��")	
					Send_cmd(0xe2,ic_sel_test,ch,7,brightness,0,0,0,0)	
				elseif ss == "ȫ��"
				then
					set_text(19,5,"ȫ��ȫ��������")	
					Send_cmd(0xe2,ic_sel_test,ch,8,brightness,0,0,0,0)				
				elseif ss == "ȫ��ȫ��������"	
				then
					set_text(19,5,"ȫͨ����������")	
					Send_cmd(0xe2,ic_sel_test,ch,9,brightness,0,0,0,0)	
				elseif ss == "ȫͨ����������"
				then
					set_text(19,5,"ȫͨ�����潥��")	
					Send_cmd(0xe2,ic_sel_test,ch,13,brightness,0,0,0,0)		
				elseif ss == "ȫͨ�����潥��"
				then
					set_text(19,5,"ȫͨ�����彥��")	
					Send_cmd(0xe2,ic_sel_test,ch,14,brightness,0,0,0,0)		
				elseif ss == "ȫͨ�����彥��"
				then
					set_text(19,5,"����ɨ��")	
					Send_cmd(0xe2,ic_sel_test,ch,10,brightness,0,0,0,0)			
				elseif ss == "����ɨ��"
				then
					set_text(19,5,"����ɨ��")	
					Send_cmd(0xe2,ic_sel_test,ch,10,brightness,0,0,0,0)				
				end	
			end
		elseif get_language() == 1
		then
			if ss == "Count"
			then
				--����Ҫ����������еı��
				auto_run_tt = 0
				set_value(19,14,0)
				set_text(19,15,"Auto Count")		
			
				set_text(19,5,"CH1")	
				Send_cmd(0xe2,ic_sel_test,ch,0,brightness,0,0,0,0)	
			else
				if ss == "CH1"
				then
					if ch == 1
					then
						set_text(19,5,"All bright")
						Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
					else
						set_text(19,5,"CH2")
						Send_cmd(0xe2,ic_sel_test,ch,1,brightness,0,0,0,0)
					end					
				elseif ss == "CH2"
				then
					if ch == 2
					then
						set_text(19,5,"All bright")
						Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
					else
						set_text(19,5,"CH3")
						Send_cmd(0xe2,ic_sel_test,ch,2,brightness,0,0,0,0)		
					end
				elseif ss == "CH3"
				then
					if ch == 3
					then
						set_text(19,5,"All bright")
						Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
					else
						set_text(19,5,"CH4")
						Send_cmd(0xe2,ic_sel_test,ch,3,brightness,0,0,0,0)		
					end	
				elseif ss == "CH4"
				then
					if ch == 4
					then
						set_text(19,5,"All bright")
						Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
					else
						set_text(19,5,"CH5")
						Send_cmd(0xe2,ic_sel_test,ch,4,brightness,0,0,0,0)		
					end		
				elseif ss == "CH5"
				then
					if ch == 5
					then
						set_text(19,5,"All bright")
						Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)	
					else
						set_text(19,5,"CH6")
						Send_cmd(0xe2,ic_sel_test,ch,5,brightness,0,0,0,0)		
					end	
				elseif ss == "CH6"
				then
					set_text(19,5,"All bright")
					Send_cmd(0xe2,ic_sel_test,ch,6,brightness,0,0,0,0)				
				elseif ss == "All bright"
				then
					set_text(19,5,"All black")	
					Send_cmd(0xe2,ic_sel_test,ch,7,brightness,0,0,0,0)	
				elseif ss == "All black"
				then
					set_text(19,5,"Bright black change")	
					Send_cmd(0xe2,ic_sel_test,ch,8,brightness,0,0,0,0)				
				elseif ss == "Bright black change"	
				then
					set_text(19,5,"All ch change")	
					Send_cmd(0xe2,ic_sel_test,ch,9,brightness,0,0,0,0)	
				elseif ss == "All ch change"
				then
					set_text(19,5,"All ch gradient")	
					Send_cmd(0xe2,ic_sel_test,ch,13,brightness,0,0,0,0)	
				elseif ss == "All ch gradient"
				then
					set_text(19,5,"All gradient")	
					Send_cmd(0xe2,ic_sel_test,ch,14,brightness,0,0,0,0)
				elseif ss == "All gradient"
				then
					set_text(19,5,"Single light run")	
					Send_cmd(0xe2,ic_sel_test,ch,10,brightness,0,0,0,0)	
				elseif ss == "Single light run"
				then
					set_text(19,5,"Single light run")	
					Send_cmd(0xe2,ic_sel_test,ch,10,brightness,0,0,0,0)			
				end	
			end
		end
		return 1
	elseif control==25 and value==0
	then
		return 1
	elseif control==26 and value==1 or control==26 and value==2
	then	
		ch = get_value(19,4)--ͨ����
		brightness = get_value(19,8)--��������	
		
		if	brightness > 0
		then 
			brightness=brightness-1
		end
		
		ss = get_text(19,5)--ģʽѡ��
		
		Test_chip_sel()
		
		if get_language() == 0
		then
			if ss == "ͨ��һ"
			then
				mode = 0
			elseif ss == "ͨ����"
			then
				mode = 1
			elseif ss == "ͨ����"
			then
				mode = 2
			elseif ss == "ͨ����"
			then
				mode = 3
			elseif ss == "ͨ����"
			then
				mode = 4
			elseif ss == "ͨ����"
			then
				mode = 5
			elseif ss == "ȫ��"
			then
				mode = 6
			elseif ss == "ȫ��"
			then
				mode = 7
			elseif ss == "ȫ��ȫ��������"
			then
				mode = 8
			elseif ss == "ȫͨ����������"
			then
				mode = 9
			elseif ss == "ȫͨ�����潥��"
			then
				mode = 13
			elseif ss == "ȫͨ�����彥��"
			then
				mode = 14
			elseif ss == "����ɨ��"
			then
				mode = 10
			elseif ss == "����"
			then
				mode = 12
			end
		elseif get_language() == 1
		then
			if ss == "CH1"
			then
				mode = 0
			elseif ss == "CH2"
			then
				mode = 1
			elseif ss == "CH3"
			then
				mode = 2
			elseif ss == "CH4"
			then
				mode = 3
			elseif ss == "CH5"
			then
				mode = 4
			elseif ss == "CH6"
			then
				mode = 5
			elseif ss == "All bright"
			then
				mode = 6
			elseif ss == "All black"
			then
				mode = 7
			elseif ss == "Bright black change"
			then
				mode = 8
			elseif ss == "All ch change"
			then
				mode = 9
			elseif ss == "All ch gradient"
			then
				mode = 13
			elseif ss == "All gradient"
			then
				mode = 14
			elseif ss == "Single light run"
			then
				mode = 10
			elseif ss == "Count"
			then
				mode = 12
			end
		end

		if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
		then
			run_num_tt=get_value(19,19)	
			Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
		else
			Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
		end
		
		set_value(19,8,brightness) 
		return 1
	elseif control==26 and value==0
	then	
		return 1
	elseif control==27 and value==1 or control==27 and value==2
	then	
		ch = get_value(19,4)--ͨ����
		brightness = get_value(19,8)--��������	
		
		if	brightness < 255
		then 
			brightness=brightness+1
		end
		
		ss = get_text(19,5)--ģʽѡ��
		
		Test_chip_sel()
		
		if get_language() == 0
		then
			if ss == "ͨ��һ"
			then
				mode = 0
			elseif ss == "ͨ����"
			then
				mode = 1
			elseif ss == "ͨ����"
			then
				mode = 2
			elseif ss == "ͨ����"
			then
				mode = 3
			elseif ss == "ͨ����"
			then
				mode = 4
			elseif ss == "ͨ����"
			then
				mode = 5
			elseif ss == "ȫ��"
			then
				mode = 6
			elseif ss == "ȫ��"
			then
				mode = 7
			elseif ss == "ȫ��ȫ��������"
			then
				mode = 8
			elseif ss == "ȫͨ����������"
			then
				mode = 9
			elseif ss == "ȫͨ�����潥��"
			then
				mode = 13
			elseif ss == "ȫͨ�����彥��"
			then
				mode = 14
			elseif ss == "����ɨ��"
			then
				mode = 10
			elseif ss == "����"
			then
				mode = 12
			end
		elseif get_language() == 1
		then
			if ss == "CH1"
			then
				mode = 0
			elseif ss == "CH2"
			then
				mode = 1
			elseif ss == "CH3"
			then
				mode = 2
			elseif ss == "CH4"
			then
				mode = 3
			elseif ss == "CH5"
			then
				mode = 4
			elseif ss == "CH6"
			then
				mode = 5
			elseif ss == "All bright"
			then
				mode = 6
			elseif ss == "All black"
			then
				mode = 7
			elseif ss == "Bright black change"
			then
				mode = 8
			elseif ss == "All ch change"
			then
				mode = 9
			elseif ss == "All ch gradient"
			then
				mode = 13
			elseif ss == "All gradient"
			then
				mode = 14
			elseif ss == "Single light run"
			then
				mode = 10
			elseif ss == "Count"
			then
				mode = 12
			end
		end

		if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
		then
			run_num_tt=get_value(19,19)	
			Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
		else
			Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
		end
		
		set_value(19,8,brightness) 
		return 1
	elseif control==27 and value==0
	then	
		return 1
	end
end

function screen_21()
	screen = screen_t
	control = control_t
	value = value_t
	if control==4 and value==1
	then
		ztd_flag = 0xaa
		
		set_text(39,2,"")--��������
		set_text(39,8,"")

		if secret_2 == 0x00--��һ�ε��������ʱ
		then
			change_screen(39)
		else
			if get_language() == 0--����
			then
				set_text(36,2,"��ȷ��Ҫ���øò�����")	
				set_text(36,7,"д�ɹ������е����׹�")
			elseif get_language() == 1--Ӣ��
			then
				set_text(36,2,"Are you sure set param��")			
				set_text(36,7,"Write ok,all white")
			end	
			
			change_screen(36)
		end
		return 1
	elseif control==4 and value==0
	then
		return 1
		
	--Hi512A0 ��ͨ��дַ
	elseif control==7 and value==1
	then
		set_text(21,17,"Setting")	

		--����дַ����
		local write_addr={}  
	
		write_addr[0] = 0xc3

		write_addr[1] = 0xff --UID
		write_addr[2] = 0xff	
		write_addr[3] = 0xff	
		write_addr[4] = 0xff	
		
		write_addr[5] = 0xc6 --������

		start_ch = get_value(21,6)

		--��ʼͨ��
		write_addr[6] = 0x00	
		write_addr[7] = math.modf(start_ch/256)	
		write_addr[8] = math.modf(start_ch%256)

		--���ͨ��
		write_addr[9] = 1

		--оƬ�ͺ�
		write_addr[10] = 24

		--ָ��������
		write_addr[11]=0x00
		write_addr[12]=0xff	
		write_addr[13]=0xff	
		
		--ָ���˿�
		write_addr[14]=0xff	

		for i=15,18 do
			write_addr[i] = 0x00
		end

		local check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + write_addr[i]
		end

		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)
	
		write_addr[18]	= check_sum
		write_addr[19] = 0xca	
	
		uart_send_data(write_addr) --��������
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�ɹ���,\r\n���е����׹�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nall white")
		end	
		change_screen(40)
		----
		return 1
	elseif control==7 and value==0
	then
		return 1
	end
end

function screen_22()
	screen = screen_t
	control = control_t
	value = value_t
	if control >= 9 and control <= 11
	then
		rr = get_value(22,9)
		gg = get_value(22,10)
		bb = get_value(22,11)
		
		rr = ((rr>>3)<<11)&0xf800
		gg = ((gg>>2)<<5)&0x07e0
		bb = (bb>>3)&0x001f
	
		draw_pen_color = Or(rr,gg)
		draw_pen_color = Or(draw_pen_color,bb) 
		redraw() 
		
		return 1
	elseif control == 26 and value==1
	then
		rr = get_value(22,9)
		gg = get_value(22,10)
		bb = get_value(22,11)
		ww = get_value(22,12)
		
		set_value(41,1,rr)
		set_value(41,2,gg)
		set_value(41,3,bb)
		set_value(41,4,ww)
		
		set_value(41,8,rr)
		set_value(41,9,gg)
		set_value(41,10,bb)
		set_value(41,11,ww)
		return 1
	elseif control == 26 and value==0
	then
		return 1
	
	--Hi512A4 д���� ����
	
	--Hi512A4 д����
	elseif control==4 and value==1
	then
		set_text(22,1,"Setting")

		tmp_dat[6] = 0x00--оƬ��Ŀ Ĭ��512
		tmp_dat[7] = 0x02

		ss = get_text(22,22)--ˢ����
		if ss == "4KHz"
		then
			tmp_dat[8] = 0
		elseif ss == "1KHz"
		then
			tmp_dat[8] = 1
		elseif  ss == "800Hz"
		then
			tmp_dat[8] = 2
		elseif  ss == "500Hz"
		then		
			tmp_dat[8] = 3
		end

		ss = get_text(22,23)--Gramma����
		if ss == "1.0"
		then
			tmp_dat[9] = 0
		elseif ss == "2.0"
		then
			tmp_dat[9] = 1
		elseif ss == "2.2"
		then
			tmp_dat[9] = 2
		elseif ss == "2.4"
		then		
			tmp_dat[9] = 3
		end

		tmp_dat[10] = get_value(22,13)--���ź�״̬
		tmp_dat[11] = get_value(22,5)--�ϵ��Լ칦��	

		--�ϵ�����״̬
		tmp_dat[12] = get_value(22,9)--R
		tmp_dat[13] = get_value(22,10)--G
		tmp_dat[14] = get_value(22,11)--B
		tmp_dat[15] = get_value(22,12)--W

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		send_cmd_xb[6] = 0x31--ָʾHi512A4��д��������
		send_cmd_xb[7] = tmp_dat[8]--ˢ����
		send_cmd_xb[8] = tmp_dat[9]--Gramma����
		send_cmd_xb[9] = tmp_dat[10]--���ź�״̬
		send_cmd_xb[10] =tmp_dat[11]--�ϵ��Լ칦��	
		send_cmd_xb[11] =tmp_dat[12]--R
		send_cmd_xb[12] =tmp_dat[13]--G
		send_cmd_xb[13] =tmp_dat[14]--B
		send_cmd_xb[14] =tmp_dat[15]--W
		send_cmd_xb[15] =0
		send_cmd_xb[16] =0
		send_cmd_xb[17] =0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	
			
		uart_send_data(send_cmd_xb) --��������

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55		
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ���̵�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother green")
		end
		change_screen(40)
		----

		return 1
	elseif control==4 and value==0
	then
		return 1

	--����д�����
	elseif control==17 and value==1
	then
		set_text(3,8,get_text(22,6))		
		change_screen(3)
		
		DMX_add_param = 0x33	
		return 1
	elseif control==17 and value==0
	then
		return 1

	--Hi512A4�������� ����
	
	--ˢ��������
	elseif control==7 and value==1
	then
		S5C3 = get_text(22,22)--��ȡ��ǰֵ

		if S5C3 == "500Hz"
		then
			set_text(22,22,"800Hz")--���ÿؼ���ֵ	
		elseif S5C3 == "800Hz"
		then
			set_text(22,22,"1KHz")--���ÿؼ���ֵ
		elseif S5C3 == "1KHz"
		then
			set_text(22,22,"4KHz")--���ÿؼ���ֵ
		elseif S5C3 == "4KHz"
		then
			set_text(22,22,"500Hz")--���ÿؼ���ֵ	
		end

		return 1
	elseif control==7 and value==0
	then
		return 1	
		
	--Gramma����
	elseif control==18 and value==1
	then
		S5C2 = get_text(22,23)--��ȡ��ǰֵ

		if S5C2 == "1.0"
		then
			set_text(22,23,"2.0")--���ÿؼ���ֵ	
		elseif S5C2 == "2.0"
		then
			set_text(22,23,"2.2")--���ÿؼ���ֵ
		elseif S5C2 == "2.2"
		then
			set_text(22,23,"2.4")--���ÿؼ���ֵ
		elseif S5C2 == "2.4"
		then
			set_text(22,23,"1.0")--���ÿؼ���ֵ	
		end	
		return 1
	elseif control==18 and value==0
	then
		return 1

	--���ź�״̬ 22,13,24
	elseif control==13 and value==1
	then
		if get_language() == 0
		then
			set_text(22,14,"�ָ��ϵ�״̬")
		elseif get_language() == 1
		then
			set_text(22,14,"Restore light status")
		end
		return 1
	elseif control==13 and value==0
	then
		if get_language() == 0
		then
			set_text(22,14,"�������һ֡")
		elseif get_language() == 1
		then
			set_text(22,14,"Save last frame")
		end

		return 1

	--�ϵ��Լ� 22,5,28
	elseif control==5 and value==1
	then
		if get_language() == 0
		then
			set_text(22,28,"����")
		elseif get_language() == 1
		then
			set_text(22,28,"Open")
		end

		return 1
	elseif control==5 and value==0
	then
		if get_language() == 0
		then
			set_text(22,28,"�ر�")
		elseif get_language() == 1
		then
			set_text(22,28,"Close")
		end

		return 1
	end
end

function screen_23()
	screen = screen_t
	control = control_t
	value = value_t
	if control >= 9 and control <= 11
	then
		rr = get_value(23,9)
		gg = get_value(23,10)
		bb = get_value(23,11)
		
		rr = ((rr>>3)<<11)&0xf800
		gg = ((gg>>2)<<5)&0x07e0
		bb = (bb>>3)&0x001f
	
		draw_pen_color = Or(rr,gg)
		draw_pen_color = Or(draw_pen_color,bb) 
		redraw() 
		
		return 1
	elseif control == 35 and value==1
	then
		rr = get_value(23,9)
		gg = get_value(23,10)
		bb = get_value(23,11)
		ww = get_value(23,12)
		nw = get_value(23,26)
		aw = get_value(23,14)
		
		set_value(41,1,rr)
		set_value(41,2,gg)
		set_value(41,3,bb)
		set_value(41,4,ww)
		set_value(41,5,nw)
		set_value(41,6,aw)
		
		set_value(41,8,rr)
		set_value(41,9,gg)
		set_value(41,10,bb)
		set_value(41,11,ww)
		set_value(41,12,nw)
		set_value(41,13,aw)
		return 1
	elseif control == 35 and value==0
	then
		return 1
	
	--Hi512A6 д���� ����

	--Hi512A6�������� 23 13 29
	elseif control==13 and value==1
	then
		set_text(23,29,"Setting")

		tmp_dat[6] = 0x00--оƬ��Ŀ Ĭ��512
		tmp_dat[7] = 0x02

		tmp_dat[8] = get_value(23,6)--ͨ��ģʽ 0:6ͨ��  1:4ͨ��

		ss = get_text(23,22)--ˢ����
		if ss == "4KHz"
		then
			tmp_dat[9] = 0
		elseif ss == "1KHz"
		then
			tmp_dat[9] = 1
		elseif  ss == "800Hz"
		then
			tmp_dat[9] = 2
		elseif  ss == "500Hz"
		then		
			tmp_dat[9] = 3
		end

		tmp_dat[10] = get_value(23,18)--�ͻ���ǿ 0:����  1:����
		tmp_dat[11] = get_value(23,5)--�ͻҲ��� 0:����  1:����	

		tmp_dat[12] = get_value(23,17)--���ź�״̬
		tmp_dat[13] = get_value(23,19)--�ϵ��Լ칦��	

		ss = get_text(23,25)--Gramma����
		if ss == "1.0"
		then
			tmp_dat[14] = 0
		elseif ss == "2.0"
		then
			tmp_dat[14] = 1
		elseif ss == "2.2"
		then
			tmp_dat[14] = 2
		elseif ss == "2.4"
		then		
			tmp_dat[14] = 3
		end

		--�ϵ�����״̬
		tmp_dat[15] = get_value(23,9)--R
		tmp_dat[16] = get_value(23,10)--G
		tmp_dat[17] = get_value(23,11)--B
		tmp_dat[18] = get_value(23,12)--W
		tmp_dat[19] = get_value(23,26)--A
		tmp_dat[20] = get_value(23,14)--C
		

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = tmp_dat[19]--A
		send_cmd_xb[2] = tmp_dat[20]--C
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		send_cmd_xb[6] = 0x32--ָʾHi512A6��д��������
		send_cmd_xb[7] = tmp_dat[8]--ͨ��ģʽ
		send_cmd_xb[8] = tmp_dat[9]--ˢ����
		send_cmd_xb[9] = tmp_dat[10]--�ͻ���ǿ
		send_cmd_xb[10] =tmp_dat[11]--�ͻҲ���	
		send_cmd_xb[11] =tmp_dat[12]--���ź�״̬
		send_cmd_xb[12] =tmp_dat[13]--�ϵ��Լ�
		send_cmd_xb[13] =tmp_dat[14]--Gramma
		send_cmd_xb[14] =tmp_dat[15]--R
		send_cmd_xb[15] =tmp_dat[16]--G
		send_cmd_xb[16] =tmp_dat[17]--B
		send_cmd_xb[17] =tmp_dat[18]--W
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ���̵�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother green")
		end
		change_screen(40)
		----

		return 1
	elseif control==13 and value==0
	then
		return 1

	--����д�����
	elseif control==30 and value==1
	then
		set_text(3,8,get_text(23,27))		
		change_screen(3)
		
		DMX_add_param = 0x33	
		return 1
	elseif control==30 and value==0
	then
		return 1
	
	--Hi512A6�������� ����
	
	--ͨ��ģʽ 23,6,21
	elseif control==6 and value==1
	then
		if get_language() == 0
		then
			set_text(23,21,"4ͨ��")
		elseif get_language() == 1
		then
			set_text(23,21,"4channel")
		end
		return 1
	elseif control==6 and value==0
	then
		if get_language() == 0
		then
			set_text(23,21,"6ͨ��")
		elseif get_language() == 1
		then
			set_text(23,21,"6channel")
		end
		return 1

	--ˢ�������� 23 7 22
	elseif control==7 and value==1
	then
		S5C3 = get_text(23,22)--��ȡ��ǰֵ

		if S5C3 == "500Hz"
		then
			set_text(23,22,"800Hz")--���ÿؼ���ֵ	
		elseif S5C3 == "800Hz"
		then
			set_text(23,22,"1KHz")--���ÿؼ���ֵ
		elseif S5C3 == "1KHz"
		then
			set_text(23,22,"4KHz")--���ÿؼ���ֵ
		elseif S5C3 == "4KHz"
		then
			set_text(23,22,"500Hz")--���ÿؼ���ֵ	
		end

		return 1
	elseif control==7 and value==0
	then
		return 1

	--�ͻ���ǿ 23 18 23
	elseif control==18 and value==1
	then
		if get_language() == 0
		then
			set_text(23,23,"����")
		elseif get_language() == 1
		then
			set_text(23,23,"Open")
		end
		return 1
	elseif control==18 and value==0
	then
		if get_language() == 0
		then
			set_text(23,23,"����")
		elseif get_language() == 1
		then
			set_text(23,23,"Close")
		end
		return 1

	--�ͻҲ��� 23 5 28
	elseif control==5 and value==1
	then
		if get_language() == 0
		then
			set_text(23,28,"����")
		elseif get_language() == 1
		then
			set_text(23,28,"Open")
		end

		return 1
	elseif control==5 and value==0
	then
		if get_language() == 0
		then
			set_text(23,28,"����")
		elseif get_language() == 1
		then
			set_text(23,28,"Close")
		end

		return 1

	--���ź�״̬ 23 17 19
	elseif control==17 and value==1
	then
		if get_language() == 0
		then
			set_text(23,33,"�ָ��ϵ�״̬")
		elseif get_language() == 1
		then
			set_text(23,33,"Restore light status")
		end
		return 1
	elseif control==17 and value==0
	then
		if get_language() == 0
		then
			set_text(23,33,"�������һ֡")
		elseif get_language() == 1
		then
			set_text(23,33,"Save last frame")
		end

		return 1
	 --�ϵ��Լ� 23 19 24
	elseif control==19 and value==1
	then
		if get_language() == 0
		then
			set_text(23,24,"����")
		elseif get_language() == 1
		then
			set_text(23,24,"Open")
		end
		return 1
	elseif control==19 and value==0
	then
		if get_language() == 0
		then
			set_text(23,24,"����")
		elseif get_language() == 1
		then
			set_text(23,24,"Close")
		end

		return 1

	--Gramma���� 23 31 30
	elseif control==31 and value==1
	then
		S5C2 = get_text(23,25)--��ȡ��ǰֵ

		if S5C2 == "1.0"
		then
			set_text(23,25,"2.0")--���ÿؼ���ֵ	
		elseif S5C2 == "2.0"
		then
			set_text(23,25,"2.2")--���ÿؼ���ֵ
		elseif S5C2 == "2.2"
		then
			set_text(23,25,"2.4")--���ÿؼ���ֵ
		elseif S5C2 == "2.4"
		then
			set_text(23,25,"1.0")--���ÿؼ���ֵ	
		end
			
		return 1
	elseif control==31 and value==0
	then
		return 1
	end
end

function screen_24()
	screen = screen_t
	control = control_t
	value = value_t
	if control >= 9 and control <= 11
	then
		rr = get_value(24,9)
		gg = get_value(24,10)
		bb = get_value(24,11)
		
		rr = ((rr>>3)<<11)&0xf800
		gg = ((gg>>2)<<5)&0x07e0
		bb = (bb>>3)&0x001f
	
		draw_pen_color = Or(rr,gg)
		draw_pen_color = Or(draw_pen_color,bb) 
		redraw() 
		
		return 1
	elseif control == 30 and value==1
	then
		rr = get_value(24,9)
		gg = get_value(24,10)
		bb = get_value(24,11)
		ww = get_value(24,12)
		
		set_value(41,1,rr)
		set_value(41,2,gg)
		set_value(41,3,bb)
		set_value(41,4,ww)
		
		set_value(41,8,rr)
		set_value(41,9,gg)
		set_value(41,10,bb)
		set_value(41,11,ww)
		return 1
	elseif control == 30 and value==0
	then
		return 1
	
		--SM1852Xд���� ����
	--SM1852Xд���� 24 13 22
	elseif control==13 and value==1
	then
		set_text(24,22,"Setting")
		
		tmp_dat[6] = 0x00--оƬ��Ŀ Ĭ��512
		tmp_dat[7] = 0x02

		tmp_dat[8] = 0		

		---------
		local dd =0	
		dd = get_value(24,16)--Gramma Ĭ��2.2
		if dd ==1
		then
			tmp_dat[8]  = Or(tmp_dat[8],0x80)
		else
			tmp_dat[8] = 0		
		end
		-------------
		ss = get_text(24,19)--�˿��ӳ�
		if ss == "��"
		then
			tmp_dat[8] = tmp_dat[8]
		elseif ss == "No"
		then
			tmp_dat[8] = tmp_dat[8]
		elseif ss == "260ns"
		then
			tmp_dat[8] = Or(tmp_dat[8],0x20)
		elseif  ss == "520ns"
		then
			tmp_dat[8] = Or(tmp_dat[8],0x10)
		elseif  ss == "780ns"
		then		
			tmp_dat[8] = Or(tmp_dat[8],0x30)
		elseif  ss == "1.04us"
		then		
			tmp_dat[8] = Or(tmp_dat[8],0x08)
		elseif  ss == "1.30us"
		then		
			tmp_dat[8] = Or(tmp_dat[8],0x28)
		elseif  ss == "1.56us"
		then		
			tmp_dat[8] = Or(tmp_dat[8],0x18)
		end	
		------------------
		dd = get_value(24,6)--ͨ����
		if dd == 1
		then
			tmp_dat[8] = tmp_dat[8]
		elseif dd == 2
		then
			tmp_dat[8] = Or(tmp_dat[8],0x04)
		elseif  dd == 3
		then
			tmp_dat[8] = Or(tmp_dat[8],0x02)
		elseif  dd == 4
		then		
			tmp_dat[8] = Or(tmp_dat[8],0x06)
		end	

		-------------------

		tmp_dat[9] = 0
		dd = get_value(24,7)--���ź�״̬
		if dd ==1
		then
			tmp_dat[9] = Or(tmp_dat[9],0x40)
		end
		
		dd = get_value(24,25)--��ַ�߿�·���		
		if dd ==1
		then
			tmp_dat[9] = Or(tmp_dat[9],0x20)
		end

		tmp_dat[10] = get_value(24,14)--�Զ���ַ����		

		--�ϵ�����״̬
		tmp_dat[11] = get_value(24,9)--R
		tmp_dat[12] = get_value(24,10)--G
		tmp_dat[13] = get_value(24,11)--B
		tmp_dat[14] = get_value(24,12)--W

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		send_cmd_xb[6] = 0x33--ָʾSM1852X��д����
		send_cmd_xb[7] = tmp_dat[8]--Gramma iout ch
		send_cmd_xb[8] = tmp_dat[9]--redis check
		send_cmd_xb[9] = tmp_dat[10]--�Զ���ַ����
		send_cmd_xb[10] =tmp_dat[11]--R
		send_cmd_xb[11] =tmp_dat[12]--G
		send_cmd_xb[12] =tmp_dat[13]--B
		send_cmd_xb[13] =tmp_dat[14]--W
		send_cmd_xb[14] =0
		send_cmd_xb[15] =0
		send_cmd_xb[16] =0
		send_cmd_xb[17] =0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ������")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother blue")
		end
		change_screen(40)
		----


		return 1
	elseif control==13 and value==1
	then
		return 1


	--����д�����
	elseif control==27 and value==1
	then
		set_text(3,8,get_text(24,20))		
		change_screen(3)
		
		DMX_add_param = 0x33	
		return 1
	elseif control==27 and value==0
	then
		return 1

	--SM1852X д���� ����

	--�ֶ�����
	elseif control==2 and value==1
	then
		if get_value(24,6) == 1
		then
			set_value(24,6,2)--���ÿؼ���ֵ	
		elseif get_value(24,6) == 2
		then
			set_value(24,6,3)--���ÿؼ���ֵ
		elseif get_value(24,6) == 3
		then
			set_value(24,6,4)--���ÿؼ���ֵ
		elseif get_value(24,6) == 4
		then
			set_value(24,6,1)--���ÿؼ���ֵ	
		end
		return 1
	elseif control==2 and value==0
	then
		return 1

	--�˿��ӳ� 24 18 19
	elseif control==18 and value==1
	then
		S5C3 = get_text(24,19)--��ȡ��ǰֵ
		
		if get_language() == 0--����
		then
			if S5C3 == "��"
			then
				set_text(24,19,"260ns")--���ÿؼ���ֵ	
			elseif S5C3 == "260ns"
			then
				set_text(24,19,"520ns")--���ÿؼ���ֵ
			elseif S5C3 == "520ns"
			then
				set_text(24,19,"780ns")--���ÿؼ���ֵ
			elseif S5C3 == "780ns"
			then
				set_text(24,19,"1.04us")--���ÿؼ���ֵ
			elseif S5C3 == "1.04us"
			then
				set_text(24,19,"1.30us")--���ÿؼ���ֵ
			elseif S5C3 == "1.30us"
			then
				set_text(24,19,"1.56us")--���ÿؼ���ֵ	
			elseif S5C3 == "1.56us"
			then
				set_text(24,19,"��")--���ÿؼ���ֵ		
			end
		elseif get_language() == 1--Ӣ��
		then
			if S5C3 == "No"
			then
				set_text(24,19,"260ns")--���ÿؼ���ֵ	
			elseif S5C3 == "260ns"
			then
				set_text(24,19,"520ns")--���ÿؼ���ֵ
			elseif S5C3 == "520ns"
			then
				set_text(24,19,"780ns")--���ÿؼ���ֵ
			elseif S5C3 == "780ns"
			then
				set_text(24,19,"1.04us")--���ÿؼ���ֵ
			elseif S5C3 == "1.04us"
			then
				set_text(24,19,"1.30us")--���ÿؼ���ֵ
			elseif S5C3 == "1.30us"
			then
				set_text(24,19,"1.56us")--���ÿؼ���ֵ	
			elseif S5C3 == "1.56us"
			then
				set_text(24,19,"No")--���ÿؼ���ֵ		
			end
		end
		return 1
	elseif control==18 and value==0
	then
		return 1	

	--���ź�״̬ 24 7 21
	elseif control==7 and value==1
	then
		if get_language() == 0
		then
			set_text(24,21,"�ָ��ϵ�״̬")
		elseif get_language() == 1
		then
			set_text(24,21,"Restore light status")
		end
		return 1
	elseif control==7 and value==0
	then
		if get_language() == 0
		then
			set_text(24,21,"�������һ֡")
		elseif get_language() == 1
		then
			set_text(24,21,"Save last frame")
		end
		return 1

	 --��ַ�߿�·��� 24 25 28
	elseif control==25 and value==1
	then
		if get_language() == 0
		then
			set_text(24,28,"����")
		elseif get_language() == 1
		then
			set_text(24,28,"Open")
		end
		return 1
	elseif control==25 and value==0
	then
		if get_language() == 0
		then
			set_text(24,28,"����")
		elseif get_language() == 1
		then
			set_text(24,28,"Close")
		end
		return 1

	--Gramma 24 16 23
	elseif control==16 and value==1
	then
		set_text(24,23,"2.0")
		return 1
	elseif control==16 and value==0
	then
		set_text(24,23,"2.2")
		return 1
	end
end

function screen_25()
	screen = screen_t
	control = control_t
	value = value_t
	if control==13 and value==1
	then
		set_text(25,7,"Setting")

		tmp_dat[8] = get_value(25,9)-1--R����
		tmp_dat[9] = get_value(25,10)-1--G
		tmp_dat[10] = get_value(25,11)-1--B
		tmp_dat[11] = get_value(25,12)-1--W
				
		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		send_cmd_xb[6] = 0x34--ָʾSM1852X д��������
		send_cmd_xb[7] = tmp_dat[8]
		send_cmd_xb[8] = tmp_dat[9]
		send_cmd_xb[9] = tmp_dat[10]
		send_cmd_xb[10] =tmp_dat[11]

		if get_text(25,6) == "SM18522PH"--SM18522PH
		then
			send_cmd_xb[11] = 0xf3
		elseif get_text(25,6) == "SM18522P"--SM18522P
		then
			send_cmd_xb[11] = 0xf5
		elseif get_text(25,6) == "SM18512P"--SM18512P
		then
			send_cmd_xb[11] = 0xfa
		else
			send_cmd_xb[11] =0xf3	
		end
	
		send_cmd_xb[12] =0
		send_cmd_xb[13] =0
		send_cmd_xb[14] =0
		send_cmd_xb[15] =0
		send_cmd_xb[16] =0
		send_cmd_xb[17] =0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	
			
		uart_send_data(send_cmd_xb) --��������	
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ���Ƶ�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother yellow")
		end
		change_screen(40)
		----
		return 1	
	elseif control==13 and value==0
	then
		return 1			

	--�Զ����� 25 15 16
	elseif control==15 and value==1
	then
		set_text(25,16,"Setting")

		ss = get_text(25,8)--�Զ�����
		if ss == "�Զ���ַ"
		then
			tmp_dat[8] = 0x0f
		elseif ss == "AUTO write add"
		then
			tmp_dat[8] = 0x0f
		elseif ss == "�Զ�Ѱַ"
		then
			tmp_dat[8] = 0xf0
		elseif ss == "AUTO search add"
		then
			tmp_dat[8] = 0xf0
		elseif ss == "����Ӧ"
		then
			tmp_dat[8] = 0xa5
		elseif ss == "Self adaption"
		then
			tmp_dat[8] = 0xa5
		elseif ss == "����"
		then		
			tmp_dat[8] = 0x00
		elseif ss == "Close"
		then		
			tmp_dat[8] = 0x00
		else
			tmp_dat[8] = 0x00
		end
		
		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		send_cmd_xb[6] = 0x35--ָʾSM1852X д�Զ�����
		send_cmd_xb[7] = tmp_dat[8]
		send_cmd_xb[8] = 0
		send_cmd_xb[9] = 0
		send_cmd_xb[10] =0
		send_cmd_xb[11] = 0
	
		send_cmd_xb[12] =0
		send_cmd_xb[13] =0
		send_cmd_xb[14] =0
		send_cmd_xb[15] =0
		send_cmd_xb[16] =0
		send_cmd_xb[17] =0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	
			
		uart_send_data(send_cmd_xb) --��������	
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ���ϵ�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother violet")
		end
		change_screen(40)
		----
		return 1	
	elseif control==15 and value==0
	then
		return 1			

	--SM1852X д���� ����
	
	--оƬѡ�� 25 2 6
	elseif control==2 and value==1
	then
		if get_text(25,6) == "SM18522PH"
		then
			set_text(25,6,"SM18522P")
			
			set_value(25,9,16)
			set_value(25,10,16)
			set_value(25,11,16)
			set_value(25,12,16)	
		elseif get_text(25,6) == "SM18522P"
		then
			set_text(25,6,"SM18512P")
			
			set_value(25,9,32)
			set_value(25,10,32)
			set_value(25,11,32)
			set_value(25,12,32)	
		elseif get_text(25,6) == "SM18512P"
		then
			set_text(25,6,"SM18522PH")
			
			set_value(25,9,32)
			set_value(25,10,32)
			set_value(25,11,32)
			set_value(25,12,32)	
		end
		return 1
	elseif control==2 and value==0
	then
		return 1	

	--�Զ����� 25 14 8
	elseif control==14 and value==1
	then
		S5C3 = get_text(25,8)--��ȡ��ǰֵ
		
		if get_language() == 0--����
		then
			if S5C3 == "�Զ���ַ"
			then
				set_text(25,8,"�Զ�Ѱַ")--���ÿؼ���ֵ	
			elseif S5C3 == "�Զ�Ѱַ"
			then
				set_text(25,8,"����Ӧ")--���ÿؼ���ֵ
			elseif S5C3 == "����Ӧ"
			then
				set_text(25,8,"����")--���ÿؼ���ֵ
			elseif S5C3 == "����"
			then
				set_text(25,8,"�Զ���ַ")--���ÿؼ���ֵ
			end
		elseif get_language() == 1--Ӣ��
		then
			if S5C3 == "AUTO write add"
			then
				set_text(25,8,"AUTO search add")--���ÿؼ���ֵ	
			elseif S5C3 == "AUTO search add"
			then
				set_text(25,8,"Self adaption")--���ÿؼ���ֵ
			elseif S5C3 == "Self adaption"
			then
				set_text(25,8,"Close")--���ÿؼ���ֵ
			elseif S5C3 == "Close"
			then
				set_text(25,8,"AUTO write add")--���ÿؼ���ֵ
			end
		end

		return 1
	elseif control==14 and value==0
	then
		return 1		

	--���õ������Ĳ���
	elseif control==9
	then
		local curr
		curr = get_value(25,2)
		if curr ==0--SM1852XPH
		then
			if get_value(25,9) >32
			then
				set_value(25,9,32)
			end
		else
			if get_value(25,9) >16
			then
				set_value(25,9,16)
			end
		end
	elseif control==10
	then
		local curr
		curr = get_value(25,2)
		if curr ==0--SM1852XPH
		then
			if get_value(25,10) >32
			then
				set_value(25,10,32)
			end
		else
			if get_value(25,10) >16
			then
				set_value(25,10,16)
			end
		end
	elseif control==11
	then
		local curr
		curr = get_value(25,2)
		if curr ==0--SM1852XPH
		then
			if get_value(25,11) >32
			then
				set_value(25,11,32)
			end
		else
			if get_value(25,11) >16
			then
				set_value(25,11,16)
			end
		end
	elseif control==12
	then
		local curr
		curr = get_value(25,2)
		if curr ==0--SM1852XPH
		then
			if get_value(25,12) >32
			then
				set_value(25,12,32)
			end
		else
			if get_value(25,12) >16
			then
				set_value(25,12,16)
			end
		end
	end
end

function screen_26()
	screen = screen_t
	control = control_t
	value = value_t
	if control==5 and value==1
	then
		set_text(26,16,"Setting")

		--------
		tmp_dat[8] = 0x80
		local dd
		dd = get_value(26,4)--�ϵ�����״̬
		if dd == 0
		then
			tmp_dat[8]  = Or(tmp_dat[8],0x08)
		else
			tmp_dat[8]  = tmp_dat[8]
		end

		dd = get_value(26,25)--���ź�״̬
		if dd == 0
		then
			tmp_dat[8]  = tmp_dat[8]
		else
			tmp_dat[8]  = Or(tmp_dat[8],0x04)
		end

		-------------��������
		dd = get_value(26,9)
		if dd>=1 and dd<=8
		then
			tmp_dat[9] = 0x40 + dd-1
		else
			tmp_dat[9] = 0x40
		end
		
		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		send_cmd_xb[6] = 0x36--ָʾQED512Pд��������
		send_cmd_xb[7] = tmp_dat[8]
		send_cmd_xb[8] = tmp_dat[9]
		send_cmd_xb[9] = 0
		send_cmd_xb[10] =0
		send_cmd_xb[11] = 0
	
		send_cmd_xb[12] =0
		send_cmd_xb[13] =0
		send_cmd_xb[14] =0
		send_cmd_xb[15] =0
		send_cmd_xb[16] =0
		send_cmd_xb[17] =0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	
			
		uart_send_data(send_cmd_xb) --��������	
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nall white")
		end
		change_screen(40)
		----
		return 1	
	elseif control==5 and value==0
	then
		return 1			

	--����д�����
	elseif control==17 and value==1
	then
		set_text(3,8,get_text(26,6))		
		change_screen(3)
		
		DMX_add_param = 0x33	
		return 1
	elseif control==17 and value==0
	then
		return 1
	
	--QED512P д���� ����

	--�ϵ�����״̬ 26 4 3
	elseif control==4 and value==1
	then
		if get_language() == 0
		then
			set_text(26,3,"�ϵ粻��")
		elseif get_language() == 1
		then
			set_text(26,3,"Trun off")
		end
		return 1
	elseif control==4 and value==0
	then
		if get_language() == 0
		then
			set_text(26,3,"�ϵ���")
		elseif get_language() == 1
		then
			set_text(26,3,"Trun on")
		end
		return 1

	--���ź�״̬ 26 25 24
	elseif control==25 and value==1
	then
		if get_language() == 0
		then
			set_text(26,7,"Ϩ��")
		elseif get_language() == 1
		then
			set_text(26,7,"Turn off")
		end
		return 1
	elseif control==25 and value==0
	then
		if get_language() == 0
		then
			set_text(26,7,"�������һ֡")
		elseif get_language() == 1
		then
			set_text(26,7,"Save last frame")
		end
		return 1
	end
end

function screen_28()
	screen = screen_t
	control = control_t
	value = value_t
	if control==2 and value==1 --��ַ����
	then
		set_text(28,10,"Setting")		

		Send_cmd(0xb5,0,0,0,0,0,0,0,0)	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")
		end	
		change_screen(40)
		----
		return 1	
	elseif control==2 and value==0
	then
		return 1			
	elseif control==1 and value==1 --GS851X дͳһ��ַ
	then
		set_text(28,7,"Setting")

		start_ch = get_value(28,11)--��ʼͨ��
		tmp_dat[7] = math.modf(start_ch/256)
		tmp_dat[8] = math.modf(start_ch%256)	
		
		tmp_dat[9] = get_value(28,12)--���ͨ��

		Send_cmd(0xb4,tmp_dat[7],tmp_dat[8],tmp_dat[9],0,0,0,0,0)	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")
		end	
		change_screen(40)
		----

		return 1	
	elseif control==1 and value==0
	then
		return 1			
	elseif control==31 and value==1 --�л���д�����
	then
		if get_value(0,12) == 0--����Ч��
		then
			Send_cmd(0xc1,0x55,0,0,0,0,0,0,0)	
		else
			Send_cmd(0xa1,0x55,0,0,0,0,0,0,0)	
		end
		
		set_text(3,8,get_text(28,27))		
		change_screen(3)
		
		DMX_add_param = 0x33
		return 1
	elseif control==31 and value==0
	then
		return 1
	elseif control==21 and value==1 --�л�����һ������
	then
		
		if get_value(0,12) == 0--����Ч��
		then
			Send_cmd(0xc1,0x55,0,0,0,0,0,0,0)	
		else
			Send_cmd(0xa1,0x55,0,0,0,0,0,0,0)	
		end
		
		if last_sreen == 49 --�л���49
		then
			change_screen(49)
		else 
			change_screen(34)
		end
		return 1
	elseif control==21 and value==0
	then
		return 1
	elseif control==20 and value==1 --�л�����һ������
	then
		if get_value(0,12) == 0--����Ч��
		then
			Send_cmd(0xc1,0x55,0,0,0,0,0,0,0)	
		else
			Send_cmd(0xa1,0x55,0,0,0,0,0,0,0)	
		end
		
		change_screen(2)
		return 1
	elseif control==20 and value==0
	then
		return 1

	--��������֡ 28 9 23
	elseif control==9 and value==1 or control==25
	then
		set_text(28,23,"Setting")
	
		tmp_dat[7] = get_value(28,19)--Gramma

		tmp_dat[8] = get_value(28,8)--R
		tmp_dat[9] = get_value(28,13)--G	
		tmp_dat[10] = get_value(28,14)--B
		tmp_dat[11] = get_value(28,15)--W

		tmp_dat[12] = get_value(28,25)--��������	

		Send_cmd(0xb6,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],0,0)		
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nall white")
		end	
		change_screen(40)
		return 1
	elseif control==9 and value==0 or control~=25
	then
		return 1
	elseif control==20 and value==1
	then
		if get_text(28,27) == "GS8516"
		then
			change_screen(49)
		end
		return 1
	elseif control==20 and value==0
	then
		return 1
	
	--GS8512 д���� ����
	--Gramma���� 28 19 29	
	elseif control==19 and value==1
	then
		if get_text(28,27) == "GS8516"
		then
			set_value(28,19,0)
		else
			set_text(28,29,"2.5")--���ÿؼ���ֵ	
		end 
		return 1
	elseif control==19 and value==0
	then
		set_text(28,29,"2.2")--���ÿؼ���ֵ
		return 1
	end
end

function screen_29()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==1 and value==1
	then
		if DMX_add_param == 0x55
		then
			set_visiable(30,16,1)
			set_visiable(30,18,1)
		else
			set_visiable(30,16,0)
			set_visiable(30,18,0)
		end
		change_screen(30)
	elseif control==1 and value==0
	then
		return 
	elseif control==8 and value==1
	then
		if DMX_add_param == 0x33 and qh_chip == 0x33--д��ַ
		then	
			qh_chip = 0
			change_screen(3)
		elseif DMX_add_param == 0x55 or qh_chip ~= 0x33--д����
		then	
			change_screen(2)
		end
		return 1
	elseif control==8 and value==0
	then
		return 1
	end
end

function screen_30()
	screen = screen_t
	control = control_t
	value = value_t
	if control==1 and value==1 --UCS512-A
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"UCS512-A")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������
		end
		return 1
	elseif control==1 and value==0
	then
		return 1
	elseif control==2 and value==1 --UCS512-B
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"UCS512-B")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������
		end
		return 1
	elseif control==2 and value==0
	then
		return 1
	elseif control==3 and value==1 --UCS512-C4
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"UCS512-C4")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(5,5,"UCS512-C4")
			change_screen(5)
			UCS512_param = 0x31	
		end
		return 1
	elseif control==3 and value==0
	then
		return 1
	elseif control==9 and value==1 --UCS512-CN
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"UCS512-CN")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(5,5,"UCS512-CN")
			change_screen(5)
			UCS512_param = 0x31	
		end
		return 1
	elseif control==9 and value==0
	then
		return 1
	elseif control==4 and value==1 --UCS512-D
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"UCS512-D")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(5,5,"UCS512-D")
			change_screen(5)
			UCS512_param = 0x32	
		end
		return 1
	elseif control==4 and value==0
	then
		return 1
	elseif control==5 and value==1 --UCS512-E
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"UCS512-E")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(10,17,"UCS512-E")
			change_screen(10)
		end
		return 1
	elseif control==5 and value==0
	then
		return 1
	elseif control==6 and value==1 --UCS512-F
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"UCS512-F")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(5,5,"UCS512-F")
			change_screen(5)
			UCS512_param = 0x33	
		end
		return 1
	elseif control==6 and value==0
	then
		return 1
	elseif control==7 and value==1 --UCS512-G
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"UCS512-G")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then
			set_text(45,5,"UCS512-G")
			change_screen(45)
			return 1
		end
		return 1
	elseif control==7 and value==0
	then
		return 1
	elseif control==10 and value==1 --UCS512-G-S
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"UCS512-G-S")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then
			set_text(45,5,"UCS512-G-S")
			change_screen(45)
			return 1
		end
		return 1
	elseif control==10 and value==0
	then
		return 1
	elseif control==11 and value==1 --UCS512-H
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"UCS512-H")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then
			set_text(47,5,"UCS512-H")
			change_screen(47)
			return 1
		end
		return 1
	elseif control==11 and value==0
	then
		return 1
	elseif control==12 and value==1 --UCS512-H-S
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"UCS512-H-S")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then
			set_text(47,5,"UCS512-H-S")
			change_screen(47)
			return 1
		end
		return 1
	elseif control==12 and value==0
	then
		return 1
	elseif control==13 and value==1 --UCS512-KH
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(69,8,"UCS512-KH")		
			change_screen(69)
		elseif DMX_add_param == 0x55--д����
		then
			set_text(53,5,"UCS512-KH")
			change_screen(53)
			return 1
		end
		return 1
	elseif control==13 and value==0
	then
		return 1
	elseif control==15 and value==1 --UCS512-KL
	then
		set_visiable(55,26,0)
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(69,8,"UCS512-KL")		
			change_screen(69)
		elseif DMX_add_param == 0x55--д����
		then
			set_text(55,5,"UCS512-KL")
			
			if 		get_text(55,47) == "UCS2903/4/12"		then 	xh=0
			elseif  get_text(55,47) == "UCS7604"			then 	xh=1
			elseif  get_text(55,47) == "UCS7804" 			then	xh=1	end
			
			if get_value(55,26) == 0 and xh ~=0
			then
				set_visiable(55,26,1)
			end
			
			change_screen(55)
			return 1
		end
		return 1
	elseif control==15 and value==0
	then
		return 1
	elseif control==16 and value==1 --UCS7804
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(58,5,"UCS7804")
			change_screen(58)
		elseif DMX_add_param == 0x55--д����
		then
			set_text(58,5,"UCS7804")
			change_screen(58)
			return 1
		end
		return 1
	elseif control==16 and value==0
	then
		return 1
	elseif control==17 and value==1 --UCS512-KH
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"UCS512-C1")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then
			set_text(59,27,"UCS512-C1")
			change_screen(59)
			return 1
		end
		return 1
	elseif control==17 and value==0
	then
		return 1
	elseif control==18 and value==1 --UCS7804
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(66,5,"UCS7604")
			change_screen(66)
		elseif DMX_add_param == 0x55--д����
		then
			set_text(66,5,"UCS7604")
			change_screen(66)
			return 1
		end
		return 1
	elseif control==18 and value==0
	then
		return 1
	elseif control==19 and value==1 --UCS7804
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"UCS512-K-Self")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then
			set_text(3,8,"UCS512-K-Self")		
			change_screen(3)
			return 1
		end
		return 1
	elseif control==19 and value==0
	then
		return 1
	end
end

function screen_31()
	screen = screen_t
	control = control_t
	value = value_t
	if control==1 and value==1 --SM1651X-3CH
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"SM1651X-3CH")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������
		end
		return 1
	elseif control==1 and value==0
	then
		return 1
	elseif control==2 and value==1 --SM1651X-4CH
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"SM1651X-4CH")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������
		end
		return 1
	elseif control==2 and value==0
	then
		return 1
	elseif control==3 and value==1 --SM17512
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"SM17512")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(11,20,"SM17512")
			change_screen(11)
		end
		return 1
	elseif control==3 and value==0
	then
		return 1
	elseif control==4 and value==1 --SM1752X
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"SM1752X")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(15,20,"SM1752X")
			change_screen(15)
		end
		return 1
	elseif control==4 and value==0
	then
		return 1
	elseif control==5 and value==1 --SM17500
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"SM17500")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(12,20,"SM17500")
			change_screen(12)
		end
		return 1
	elseif control==5 and value==0
	then
		return 1
	elseif control==6 and value==1 --SM17500-S
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"SM17500-S")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(12,20,"SM17500-S")
			change_screen(12)
		end
		return 1
	elseif control==6 and value==0
	then
		return 1
	elseif control==7 and value==1 --SM1852x
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"SM1852X")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(24,20,"SM1852X")
			change_screen(24)
		end
		return 1
	elseif control==7 and value==0
	then
		return 1
	elseif control==9 and value==1 --SM1952x
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"SM1952X")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(50,43,"SM1952X")
			change_screen(50)
		end
		return 1
	elseif control==9 and value==0
	then
		return 1
	elseif control==10 and value==1 or  control==13 and value==1--SM522
	then
		if DMX_add_param == 0x33--д��ַ
		then
			if control == 10
			then
				set_text(3,8,"SM522")
			else
				set_text(3,8,"SM522-S")
			end		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			if control == 10
			then
				set_text(72,31,"SM522")
			else
				set_text(72,31,"SM522-S")
			end	
			change_screen(72)
		end
		return 1
	elseif control==10 and value==0 or  control==13 and value==0
	then
		return 1
	elseif control==11 and value==1 or  control==14 and value==1--SM18500P
	then
		if DMX_add_param == 0x33--д��ַ
		then
			if control == 11
			then
				set_text(3,8,"SM18500P")
			else
				set_text(3,8,"SM18500P-S")
			end
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then
			if control == 11
			then
				set_text(73,5,"SM18500P")
				set_text(74,5,"SM18500P")
				set_text(75,5,"SM18500P")
				set_text(77,5,"SM18500P")
			else
				set_text(73,5,"SM18500P-S")
				set_text(74,5,"SM18500P-S")
				set_text(75,5,"SM18500P-S")
				set_text(77,5,"SM18500P-S")
			end
			
			change_screen(73)
		end
		return 1
	elseif control==11 and value==0 or  control==14 and value==0
	then
		return 1
	elseif control==12 and value==1 or  control==15 and value==1--SM522
	then
		if DMX_add_param == 0x33--д��ַ
		then
			if control == 12
			then
				set_text(3,8,"SM18500PS")
			else
				set_text(3,8,"SM18500PS-S")
			end	
					
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then
			if control == 12
			then
				set_text(76,5,"SM18500PS")
				set_text(74,5,"SM18500PS")
				set_text(75,5,"SM18500PS")
				set_text(77,5,"SM18500PS")
				
			else
				set_text(76,5,"SM18500PS-S")
				set_text(74,5,"SM18500PS-S")
				set_text(75,5,"SM18500PS-S")
				set_text(77,5,"SM18500PS-S")
			end			
			
			change_screen(76)
		end
		return 1
	elseif control==12 and value==0 or  control==15 and value==0
	then
		return 1
	end
end

function screen_32()
	screen = screen_t
	control = control_t
	value = value_t
	if control==1 and value==1 --TM512AB
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"TM512AB")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������
		end
		return 1
	elseif control==1 and value==0
	then
		return 1
	elseif control==2 and value==1 --TM512AL
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"TM512AL")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			if get_language() ==0
			then
				set_text(40,2,"��оƬû�д˹��ܣ�")	
			elseif get_language() == 1
			then
				set_text(40,2,"No this function��")	
			end	
			change_screen(40)--��ʾ��оƬû��д��������
		end
		return 1
	elseif control==2 and value==0
	then
		return 1
	elseif control==3 and value==1 --TM512AC
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"TM512AC")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(5,5,"TM512AC")
			change_screen(5)
			UCS512_param = 0x31	
		end
		return 1
	elseif control==3 and value==0
	then
		return 1
	elseif control==4 and value==1 --TM512AD
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"TM512AD")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(5,5,"TM512AD")
			change_screen(5)
			UCS512_param = 0x34	
		end
		return 1
	elseif control==4 and value==0
	then
		return 1
	elseif control==5 and value==1 --TM512AE
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"TM512AE")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(10,17,"TM512AE")
			change_screen(10)
		end
		return 1
	elseif control==5 and value==0
	then
		return 1
	end
end

function screen_33()
	screen = screen_t
	control = control_t
	value = value_t
	if control==1 and value==1 --Hi512A0
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"Hi512A0")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(21,2,"Hi512A0")
			change_screen(21)
		end
		return 1
	elseif control==1 and value==0
	then
		return 1
	elseif control==2 and value==1 --Hi512A4
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"Hi512A4")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(22,6,"Hi512A4")
			change_screen(22)
		end
		return 1
	elseif control==2 and value==0
	then
		return 1
	elseif control==3 and value==1 --Hi512A6
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"Hi512A6")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(23,27,"Hi512A6")
			change_screen(23)
		end
		return 1
	elseif control==3 and value==0
	then
		return 1
	elseif control==4 and value==1 --Hi512D
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"Hi512D")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(16,27,"Hi512D")
			change_screen(16)
		end
		return 1
	elseif control==4 and value==0
	then
		return 1
	elseif control==5 and value==1 --Hi512A0_Self
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"Hi512A0_Self")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(21,2,"Hi512A0_Self")
			change_screen(21)
		end
		return 1
	elseif control==5 and value==0
	then
		return 1
	end
end

function screen_34()
	screen = screen_t
	control = control_t
	value = value_t
	if control==1 and value==1 --GS8511
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"GS8511")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(28,27,"GS8511")
			change_screen(28)
		end
		return 1
	elseif control==1 and value==0
	then
		return 1
	elseif control==2 and value==1 --GS8512
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"GS8512")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(28,27,"GS8512")
			change_screen(28)
		end
		return 1
	elseif control==2 and value==0
	then
		return 1
	elseif control==3 and value==1 --GS8513
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"GS8513")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(28,27,"GS8513")
			change_screen(28)
		end
		return 1
	elseif control==3 and value==0
	then
		return 1
	elseif control==4 and value==1 --GS8515
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"GS8515")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(28,27,"GS8515")
			change_screen(28)
		end
		return 1
	elseif control==4 and value==0
	then
		return 1	
	elseif control==5 and value==1 --GS8516
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"GS8516")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(49,30,"GS8516")
			change_screen(49)
		end
		return 1
	elseif control==5 and value==0
	then
		return 1
	elseif control==6 and value==1 --GS8516
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"GS8516B")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(60,30,"GS8516B")
			change_screen(60)
		end
		return 1
	elseif control==6 and value==0
	then
	elseif control==7 and value==1 --GS8525
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"GS8525")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(62,30,"GS8525")
			change_screen(62)
		end
		return 1
	elseif control==7 and value==0
	then
		return 1
	elseif control==9 and value==1 --GS8523
	then
		if get_value(70,6) > 3 then set_value(70,6,3) end
	
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"GS8523")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(70,30,"GS8523")
			change_screen(70)
		end
		
		Send_cmd(0xd4,0xAA,0,0,0,0,0,0,0)
		
		return 1
	elseif control==9 and value==0
	then
		return 1
	elseif control==10 and value==1 --GS8524
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"GS8524")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(70,30,"GS8524")
			change_screen(70)
		end
		
		Send_cmd(0xd4,0xAA,0,0,0,0,0,0,0)
		
		return 1
	elseif control==10 and value==0
	then
		return 1
	elseif control==11 and value==1 --GS8526
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"GS8526")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(70,30,"GS8526")
			change_screen(70)
		end
		
		Send_cmd(0xd4,0xAA,0,0,0,0,0,0,0)
		
		return 1
	elseif control==11 and value==0
	then
		return 1
	end
end

function screen_35()
	screen = screen_t
	control = control_t
	value = value_t
	if control==1 and value==1 --QED512P
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"QED512P")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(26,6,"QED512P")
			change_screen(26)
		end
		return 1
	elseif control==1 and value==0
	then
		return 1
	elseif control==2 and value==1 --QED512P
	then
		if DMX_add_param == 0x33--д��ַ
		then
			set_text(3,8,"KW512A")		
			change_screen(3)
		elseif DMX_add_param == 0x55--д����
		then	
			set_text(68,5,"KW512A")
			change_screen(68)
		end
		return 1
	elseif control==2 and value==0
	then
		return 1
	end
end

function screen_36()
	screen = screen_t
	control = control_t
	value = value_t
	if control==3 and value==1 --ȷ����ť
	then
		if ztd_flag == 0x33--UCS512-Eд��ͨ����
		then
			set_text(13,8,"Setting")	

			tmp_dat[6] = 0x2a
			tmp_dat[7] = 0x4c
			
			local ztd = get_value(13,3) - 1
			tmp_dat[8] = Or(ztd,0x80)--��ͨ����

			tmp_dat[9] = 0
			tmp_dat[10] = 0
			tmp_dat[11] = 0
			tmp_dat[12] = 0
			tmp_dat[13] = 0	

			Send_param_cmd(0x06,tmp_dat[6],tmp_dat[7],tmp_dat[8],0,0,0,0,0,0,0,0)
			
			set_text(36,7,"")
			
			change_screen(13)
		elseif ztd_flag == 0x55--SM17500д��ͨ����
		then
			set_text(14,16,"Setting")

			tmp_dat[6] = math.modf(4095%256)
			tmp_dat[7] = math.modf(4095/256)
			
			tmp_dat[17] = 0x22
			tmp_dat[18] = get_value(14,3)--��ͨ����	

			Send_param_cmd(0x12,tmp_dat[17],tmp_dat[18],0,0,0,0,0,0,0,0,0)
			set_text(36,7,"")
			
			change_screen(14)
		elseif ztd_flag == 0xaa--Hi512A0д��ͨ����
		then
			set_text(21,16,"Setting")		

			tmp_dat[6] = 0x2a
			tmp_dat[7] = 0x4c
			
			local ztd = get_value(21,3) - 1
			tmp_dat[8] = ztd--��ͨ����

			tmp_dat[9] = 0
			tmp_dat[10] = 0
			tmp_dat[11] = 0
			tmp_dat[12] = 0
			tmp_dat[13] = 0	

			Send_param_cmd(0x30,tmp_dat[6],tmp_dat[7],tmp_dat[8],tmp_dat[13],0,0,0,0,0,0,0)

			set_text(36,7,"")

			change_screen(21)
		elseif ztd_flag == 0xbb--UCS512K
		then
			set_text(53,20,"Setting")
		
			local dd = 24
			dd = get_value(53,37)

			if dd < 1 or dd > 128
			then
				dd=24
				set_text(53,37,24)
			end
			
			local ee = 0x33
			ss = get_text(53,5)
			if ss == "UCS512-KH"
			then
				ee = 0x33
			elseif ss == "UCS512-KH-S"
			then
				ee = 0x55
			end
			
			Send_cmd(0xc7,0x3d,0x02,ee,dd-1,0,0,0,0)

			set_text(36,7,"")

			change_screen(53)
		elseif ztd_flag == 0xcc--UCS512K
		then
			set_text(55,20,"Setting")
		
			local dd = 24
			dd = get_value(55,37)

			if dd < 1 or dd > 128
			then
				dd=24
				set_text(55,37,24)
			end
			
			local ee = 0x33
			ss = get_text(55,5)
			if ss == "UCS512-KL"
			then
				ee = 0x33
			elseif ss == "UCS512-KL-S"
			then
				ee = 0x55
			end
			
			Send_cmd(0xc7,0x3d,0x12,ee,dd-1,0,0,0,0)

			set_text(36,7,"")

			change_screen(55)
		elseif ztd_flag == 0x44--SM18500P
		then
			set_text(77,16,"Setting")		

			tmp_dat[6] = 0x2a
			tmp_dat[7] = 0x4c
			
			local ztd = get_value(77,3)
			tmp_dat[8] = ztd--��ͨ����

			tmp_dat[9] = 0
			tmp_dat[10] = 0
			tmp_dat[11] = 0
			tmp_dat[12] = 0
			tmp_dat[13] = 0	

			Send_param_cmd(0x42,tmp_dat[6],tmp_dat[7],tmp_dat[8],tmp_dat[13],0,0,0,0,0,0,0)

			set_text(36,7,"")

			change_screen(77)
		else
			change_screen(last_sreen)
		end
	
		ztd_flag = 0x00--����ò���
		return 1
	elseif control==3 and value==0 --ȷ����ť
	then
		return 1
	
	--ȡ�� ��ť
	elseif control==4 and value==1 --ȡ����ť
	then
		if ztd_flag == 0x33--UCS512-Eд��ͨ����
		then
			set_value(13,4,0)
			change_screen(13)
		elseif ztd_flag == 0x55--SM17500д��ͨ����
		then
			set_value(14,4,0)
			change_screen(14)
		elseif ztd_flag == 0xaa--Hi512A0д��ͨ����
		then
			set_value(21,4,0)
			change_screen(21)
		elseif ztd_flag == 0xbb--UCS512KH
		then
			set_value(53,38,0)
			change_screen(53)
		elseif ztd_flag == 0xcc--UCS512KL
		then
			set_value(55,38,0)
			change_screen(55)
		elseif ztd_flag == 0x44--SM18500P
		then
			set_value(77,4,0)
			change_screen(77)
		else
			change_screen(last_sreen)	
		end
	
		ztd_flag = 0x00--����ò���
		return 1
	elseif control==4 and value==0 --ȡ����ť
	then
		return 1
	end
end

function screen_37()
	screen = screen_t
	control = control_t
	value = value_t
	if control==18 and value==1
	then
		language_sel(1)	
		return 1
	elseif control==18 and value==0
	then
		language_sel(0)	
		return 1

	------------��ʼ���� ���뵽������1 �������Ͳ�������
	elseif control==4 and value==1
	then
		
		if get_value(0,12) == 0--����Ч��
		then
			Send_cmd(0xc1,0,0,0,0,0,0,0,0)	
		else
			Send_cmd(0xa1,0,0,0,0,0,0,0,0)	
		end
		
		change_screen(0)
		return 1
	elseif control==4 and value==0
	then
		return 1

	------------��ʼ���� �л������Խ��� ���� ������ͣ״̬
	elseif control==5 and value==1
	then
		if get_value(0,12) == 0--����Ч��
		then
			Send_cmd(0xc1,0x55,0,0,0,0,0,0,0)	
		else
			Send_cmd(0xa1,0x55,0,0,0,0,0,0,0)	
		end
		
		change_screen(2)
		return 1
	elseif control==5 and value==0
	then
		return 1
	end
end

function screen_38()
	screen = screen_t
	control = control_t
	value = value_t
	if control==3 and value==1 --ȷ����ť
	then
		--����ȶ����룬�����ȷ�����л�����Ӧ�Ľ���
		if get_text(38,2) == "xb88"
		then
			if DMX_add_param == 0x33--�л���д�����
			then
				--change_screen(3)
				change_screen(29)
			elseif DMX_add_param == 0x55 --�л���д��������
			then
				change_screen(29)
			end
			
			secret_1 = 0x55
		else
			set_text(38,8,"�������!")
		end
		return 1
	elseif control==3 and value==0 --ȷ����ť
	then
		return 1
	
	--ȡ�� ��ť
	elseif control==4 and value==1 --ȡ����ť
	then
		change_screen(last_sreen)
		return 1
	elseif control==4 and value==0 --ȡ����ť
	then
		return 1
	end
end

function screen_39()
	screen = screen_t
	control = control_t
	value = value_t

	if control==3 and value==1 --ȷ����ť
	then
		--����ȶ����룬�����ȷ�����л�����Ӧ�Ľ���
		if get_text(39,2) == "8866"
		then		
			if ztd_flag == 0x33--UCS512-Eд��ͨ����
			then
				if get_language() == 0--����
				then
					set_text(36,7,"д�ɹ����׵����Ƶƣ��������̵�")
				elseif get_language() == 1--Ӣ��
				then	
					set_text(36,7,"Write ok,first yellow,other green")
				end
			elseif ztd_flag == 0x55--SM17500д��ͨ����
			then
				if get_language() == 0--����
				then
					set_text(36,7,"д�ɹ����׵�����ƣ��������ϵ�")
				elseif get_language() == 1--Ӣ��
				then	
					set_text(36,7,"Write ok,first red,other violet")
				end
			elseif ztd_flag == 0xaa--Hi512A0д��ͨ����
			then
				if get_language() == 0--����
				then
					set_text(36,7,"д�ɹ������е����׹�")
				elseif get_language() == 1--Ӣ��
				then	
					set_text(36,7,"Write ok,all white")
				end
			end		
		
			if get_language() == 0--����
			then
				set_text(36,2,"��ȷ��Ҫ���øò�����")	
			elseif get_language() == 1--Ӣ��
			then	
				set_text(36,2,"Are you sure set param?")	
			end
			
			change_screen(36)
			
			secret_2 = 0x55
		else
			set_text(39,8,"�������!")
		end
		return 1
	elseif control==3 and value==0 --ȷ����ť
	then
		return 1
	
	--ȡ�� ��ť
	elseif control==4 and value==1 --ȡ����ť
	then
		if ztd_flag == 0x33--UCS512-Eд��ͨ����
		then
			set_value(13,4,0)
		elseif ztd_flag == 0x55--SM17500д��ͨ����
		then
			set_value(14,4,0)
		elseif ztd_flag == 0xaa--Hi512A0д��ͨ����
		then
			set_value(21,4,0)
		elseif ztd_flag == 0xbb--Hi512A0д��ͨ����
		then
			set_value(53,38,0)
		elseif ztd_flag == 0xcc--Hi512A0д��ͨ����
		then
		set_value(55,38,0)
		end
		
		change_screen(last_sreen)
		return 1
	elseif control==4 and value==0 --ȡ����ť
	then
		return 1
	end
end

function screen_40()
	screen = screen_t
	control = control_t
	value = value_t
	if control==3 and value==1 --ȷ����ť
	then
		DMX_Status_page = 0
		change_screen(last_sreen)
		return 1
	elseif control==3 and value==0 --ȷ����ť
	then
		return 1
	end
end

function screen_41()
	screen = screen_t
	control = control_t
	value = value_t
	if control==7 and value==1 
	then
		rr = get_value(41,8)
		gg = get_value(41,9)
		bb = get_value(41,10)
		ww = get_value(41,11)
		nw = get_value(41,12)
		aw = get_value(41,13)
		
		if last_sreen == 5
		then
			set_value(5,9,rr)
			set_value(5,10,gg)
			set_value(5,11,bb)
			set_value(5,12,ww)	
		elseif last_sreen == 10
		then
			set_value(10,9,rr)
			set_value(10,10,gg)
			set_value(10,11,bb)
			set_value(10,12,ww)	
		elseif last_sreen == 11
		then
			set_value(11,9,rr)
			set_value(11,10,gg)
			set_value(11,11,bb)
			set_value(11,12,ww)	
		elseif last_sreen == 12
		then
			set_value(12,9,rr)
			set_value(12,10,gg)
			set_value(12,11,bb)
			set_value(12,12,ww)	
		elseif last_sreen == 15
		then
			set_value(15,9,rr)
			set_value(15,10,gg)
			set_value(15,11,bb)
			set_value(15,12,ww)	
		elseif last_sreen == 16
		then
			set_value(16,9,rr)
			set_value(16,10,gg)
			set_value(16,11,bb)
			set_value(16,12,ww)	
			set_value(16,26,nw)	
		elseif last_sreen == 22
		then
			set_value(22,9,rr)
			set_value(22,10,gg)
			set_value(22,11,bb)
			set_value(22,12,ww)	
		elseif last_sreen == 23
		then
			set_value(23,9,rr)
			set_value(23,10,gg)
			set_value(23,11,bb)
			set_value(23,12,ww)	
			set_value(23,26,nw)
			set_value(23,14,aw)
		elseif last_sreen == 24
		then
			set_value(24,9,rr)
			set_value(24,10,gg)
			set_value(24,11,bb)
			set_value(24,12,ww)	
		end
		
		change_screen(last_sreen)
		
		if last_sreen == 5 or last_sreen == 10 or last_sreen == 11 or last_sreen == 12 or last_sreen == 15 or last_sreen == 16 or last_sreen == 22 or last_sreen == 23 or last_sreen == 24
		then
			rr = ((rr>>3)<<11)&0xf800
			gg = ((gg>>2)<<5)&0x07e0
			bb = (bb>>3)&0x001f
		
			draw_pen_color = Or(rr,gg)
			draw_pen_color = Or(draw_pen_color,bb) 
			redraw() 
		end
		return 1
	elseif control==7 and value==0
	then
		return 1
	
	elseif control==8
	then
		set_value(41,1,get_value(41,8))
		
		rr = get_value(41,8)
		gg = get_value(41,9)
		bb = get_value(41,10)
		
		rr = ((rr>>3)<<11)&0xf800
		gg = ((gg>>2)<<5)&0x07e0
		bb = (bb>>3)&0x001f
		
		draw_pen_color = Or(rr,gg)
		draw_pen_color = Or(draw_pen_color,bb) 
		redraw()
		
		return 1
	elseif control==9
	then
		set_value(41,2,get_value(41,9))
		
		rr = get_value(41,8)
		gg = get_value(41,9)
		bb = get_value(41,10)
		
		rr = ((rr>>3)<<11)&0xf800
		gg = ((gg>>2)<<5)&0x07e0
		bb = (bb>>3)&0x001f
		
		draw_pen_color = Or(rr,gg)
		draw_pen_color = Or(draw_pen_color,bb) 
		redraw()
		
		return 1
	elseif control==10
	then
		set_value(41,3,get_value(41,10))
		
		rr = get_value(41,8)
		gg = get_value(41,9)
		bb = get_value(41,10)
		
		rr = ((rr>>3)<<11)&0xf800
		gg = ((gg>>2)<<5)&0x07e0
		bb = (bb>>3)&0x001f
		
		draw_pen_color = Or(rr,gg)
		draw_pen_color = Or(draw_pen_color,bb) 
		redraw()	
		
		return 1
	elseif control==11
	then
		set_value(41,4,get_value(41,11))
		return 1
	elseif control==12
	then
		set_value(41,5,get_value(41,12))
		return 1
	elseif control==13
	then
		set_value(41,6,get_value(41,13))
		return 1
	elseif control==1
	then
		set_value(41,8,get_value(41,1))
		return 1	
	elseif control==2
	then
		set_value(41,9,get_value(41,2))
		return 1	
	elseif control==3
	then
		set_value(41,10,get_value(41,3))
		return 1	
	elseif control==4
	then
		set_value(41,11,get_value(41,4))
		return 1	
	elseif control==5
	then
		set_value(41,12,get_value(41,5))
		return 1	
	elseif control==6
	then
		set_value(41,13,get_value(41,6))
		return 1	
	end
end

function screen_43()
	screen = screen_t
	control = control_t
	value = value_t
	
	ch = get_value(19,4)--ͨ����
	brightness = get_value(19,8)--��������	
	Test_chip_sel()
	ss = get_text(19,5)--ģʽѡ��
	
	if get_language() == 0
	then
		if ss == "ͨ��һ"
		then
			mode = 0
		elseif ss == "ͨ����"
		then
			mode = 1
		elseif ss == "ͨ����"
		then
			mode = 2
		elseif ss == "ͨ����"
		then
			mode = 3
		elseif ss == "ͨ����"
		then
			mode = 4
		elseif ss == "ͨ����"
		then
			mode = 5
		elseif ss == "ȫ��"
		then
			mode = 6
		elseif ss == "ȫ��"
		then
			mode = 7
		elseif ss == "ȫ��ȫ��������"
		then
			mode = 8
		elseif ss == "ȫͨ����������"
		then
			mode = 9
		elseif ss == "ȫͨ�����潥��"
		then
			mode = 13
		elseif ss == "ȫͨ�����彥��"
		then
			mode = 14
		elseif ss == "����ɨ��"
		then
			mode = 10
		elseif ss == "����"
		then
			mode = 12
		end
	elseif get_language() == 1
	then
		if ss == "CH1"
		then
			mode = 0
		elseif ss == "CH2"
		then
			mode = 1
		elseif ss == "CH3"
		then
			mode = 2
		elseif ss == "CH4"
		then
			mode = 3
		elseif ss == "CH5"
		then
			mode = 4
		elseif ss == "CH6"
		then
			mode = 5
		elseif ss == "All bright"
		then
			mode = 6
		elseif ss == "All black"
		then
			mode = 7
		elseif ss == "Bright black change"
		then
			mode = 8
		elseif ss == "All ch change"
		then
			mode = 9
		elseif ss == "All ch gradient"
		then
			mode = 13
		elseif ss == "All gradient"
		then
			mode = 14
		elseif ss == "Single light run"
		then
			mode = 10
		elseif ss == "Count"
		then
			mode = 12
		end
	end


	if control==1 and value==1
	then
		set_text(19,13,"UCS1903")
		Test_chip_sel()
		
		if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
		then
			run_num_tt=get_value(19,19)	
			Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
		else
			Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
		end
		
		change_screen(last_sreen)
		return 1
	elseif control==1 and value==0
	then
		return 1
	elseif control==2 and value==1
	then
		set_text(19,13,"DMX 250K")	
		Test_chip_sel()
		
		if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
		then
			run_num_tt=get_value(19,19)	
			Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
		else
			Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
		end
		
		change_screen(last_sreen)
		return 1
	elseif control==2 and value==0
	then
		return 1
	
	elseif control==3 and value==1
	then
		set_text(19,13,"DMX 500K")	
		Test_chip_sel()
		
		if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
		then
			run_num_tt=get_value(19,19)	
			Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
		else
			Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
		end
		
		change_screen(last_sreen)
		return 1
	elseif control==3 and value==0
	then
		return 1
	elseif control==4 and value==1
	then
		set_text(19,13,"GS851X")	
		Test_chip_sel()
		
		if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
		then
			run_num_tt=get_value(19,19)	
			Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
		else
			Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
		end
		
		change_screen(last_sreen)
		return 1
	elseif control==4 and value==0
	then
		return 1
	else
		if get_text(43,13) == "UCS2603"
		then
		    set_text(43,13,"")
			set_text(19,13,"UCS2603")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "UCS5/8603"
		then
		    set_text(43,13,"")
			set_text(19,13,"UCS5/8603")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "UCS8904"
		then
		    set_text(43,13,"")
			set_text(19,13,"UCS8904")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "UCS9812"
		then
		    set_text(43,13,"")
			set_text(19,13,"UCS9812")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "UCS7604"
		then
		    set_text(43,13,"")
			set_text(19,13,"UCS7604")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "UCS7804"
		then
		    set_text(43,13,"")
			set_text(19,13,"UCS7804")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "SM16212"
		then
		    set_text(43,13,"")
			set_text(19,13,"SM16212")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "SM16703"
		then
		    set_text(43,13,"")
			set_text(19,13,"SM16703")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "SM16713_A"
		then
		    set_text(43,13,"")
			set_text(19,13,"SM16713_A")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "SM16713_B"
		then
		    set_text(43,13,"")
			set_text(19,13,"SM16713_B")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "SM16713_C"
		then
		    set_text(43,13,"")
			set_text(19,13,"SM16713_C")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "SM16714"
		then
		    set_text(43,13,"")
			set_text(19,13,"SM16714")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "SM16716"
		then
		    set_text(43,13,"")
			set_text(19,13,"SM16716")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "SM16803"
		then
		    set_text(43,13,"")
			set_text(19,13,"SM16803")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "SM16804"
		then
		    set_text(43,13,"")
			set_text(19,13,"SM16804")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "SM16813"
		then
		    set_text(43,13,"")
			set_text(19,13,"SM16813")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "TM1804"
		then
		    set_text(43,13,"")
			set_text(19,13,"TM1804")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "TM1814"
		then
		    set_text(43,13,"")
			set_text(19,13,"TM1814")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "TM1914"
		then
		    set_text(43,13,"")
			set_text(19,13,"TM1914")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "WS2816"
		then
		    set_text(43,13,"")
			set_text(19,13,"WS2816")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "LPD6803"
		then
		    set_text(43,13,"")
			set_text(19,13,"LPD6803")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "KW5603A"
		then
		    set_text(43,13,"")
			set_text(19,13,"KW5603A")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "KW5604"
		then
		    set_text(43,13,"")
			set_text(19,13,"KW5604")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "QS2633"
		then
		    set_text(43,13,"")
			set_text(19,13,"QS2633")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "QS2639"
		then
		    set_text(43,13,"")
			set_text(19,13,"QS2639")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		elseif get_text(43,13) == "WS2814"
		then
		    set_text(43,13,"")
			set_text(19,13,"WS2814")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
				elseif get_text(43,13) == "MT1885"
		then
		    set_text(43,13,"")
			set_text(19,13,"MT1885")
			Test_chip_sel()
			
			if mode == 12--����ʱ��Ҫȡ��ǰ�ĵ���
			then
				run_num_tt=get_value(19,19)	
				Send_cmd(0xe2,ic_sel_test,ch,12,brightness,math.modf(run_num_tt/256),math.modf(run_num_tt%256),0,0)	
			else
				Send_cmd(0xe2,ic_sel_test,ch,mode,brightness,0,0,0,0)	
			end		

	        change_screen(last_sreen)
			return 1
		end
		return 1
	end
end

function screen_44()
	screen = screen_t
	control = control_t
	value = value_t
	if control==3 and value==1
	then
		S5C2 = get_value(44,2)
		S5C2 = S5C2 + 1	
		if S5C2>6
		then
			S5C2 = 1
		end
		set_value(44,2,S5C2)
		
		if get_value(44,25) == 0 --��̬����ʱ���ı�ͨ�����������������һ������
		then
			TiaoGuang_new()
		end
		return 1
	elseif control==3 and value==0
	then
		return 1

	--����ʱ���Ƿ� �����������
	elseif control==4
	then
		if get_value(44,25) == 0 --��̬����
		then
			Save_screen = 0x33
	
			S5C2 = get_value(44,2)--ͨ����
		
			rr = get_value(44,16)
			gg = get_value(44,17)
			bb = get_value(44,19)
			ww = get_value(44,5)
			nw = get_value(44,7)
			aw = get_value(44,9)

			Send_cmd(0xee,0x66,S5C2,rr,gg,bb,ww,nw,aw)--����Ҫ���� �ϵ� ��ʾ��ɫ������	

			data[0] = 0xaa--���λ
			data[1] = 0xcc
			
			data[2] = 44--ҳ��ID

			data[3] = S5C2--ͨ����
			data[4] = 0--IC�ͺ�

			data[5] = rr--ͨ������ֵ
			data[6] = gg
			data[7] = bb
			data[8] = ww
			data[9] = nw
			data[10] = aw
		
			Save_show = 0x00
		
			data[11] = 0 
			data[12] = 0
			data[13] = 0
			data[14] = 0
			data[15] = 0
			data[16] = 0

			data[17] = Save_show--ģ�����⻹�Ǿ�׼����
			data[18] = Save_screen--��̬����ı��
			data[19] = 0
			
			write_flash(0x00,data)
		else --��̬����
			Save_screen = 0x55
	
			S5C2 = get_value(44,2)--ͨ����
		
			if Save_show == 0x00--��׼����
			then
				rr = get_value(44,16)
				gg = get_value(44,17)
				bb = get_value(44,19)
			elseif Save_show == 0x55--ģ������
			then
				bb = ((select_rgb >>  0) & 0x1F) << 3
				gg = ((select_rgb >>  5) & 0x3F) << 2
				rr = ((select_rgb >> 11) & 0x1F) << 3
			end
			
			ww = get_value(44,5)
			nw = get_value(44,7)
			aw = get_value(44,9)

			Send_cmd(0xee,0x55,S5C2,rr,gg,bb,ww,nw,aw)--����Ҫ���� �ϵ� ��ʾ��ɫ������	

			data[0] = 0x33--���λ
			data[1] = 0x55
			
			data[2] = 44--ҳ��ID

			data[3] = S5C2--ͨ����
			data[4] = 0--IC�ͺ�

			data[5] = rr--ͨ������ֵ
			data[6] = gg
			data[7] = bb
			data[8] = ww
			data[9] = nw
			data[10] = aw
		
			if Save_show == 0x00--��׼����
			then
				data[11] = 0 --X����
				data[12] = 0
				data[13] = 0--Y����
				data[14] = 0
				data[15] = 0--ѡ�е���ɫֵ
				data[16] = 0
			elseif Save_show == 0x55--ģ������
			then
				data[11] = math.modf(draw_select_x/256) --X����
				data[12] = math.modf(draw_select_x%256)
				data[13] = math.modf(draw_select_y/256)--Y����
				data[14] = math.modf(draw_select_y%256)
				data[15] = math.modf(select_rgb/256)--ѡ�е���ɫֵ
				data[16] = math.modf(select_rgb%256)
			end

			data[17] = Save_show--ģ�����⻹�Ǿ�׼����
			data[18] = Save_screen--��̬����ı��
			data[19] = 0
			
			write_flash(0x00,data)
		end
		return 1
	
	elseif control==25 and value==1
	then
		Save_screen = 0x55--��̬����
		return 1
	elseif control==25 and value==0
	then	
		set_value(44,22,0)--��22�����ť����
	
		Save_screen = 0x33--��̬����
		Save_show = 0x00--��׼����
	
		set_visiable(44,15,0)--����
		set_value(44,21,0)--����

		set_visiable(44,16,1)--��ʾ
		set_visiable(44,17,1)--��ʾ
		set_visiable(44,19,1)--��ʾ
		
		set_visiable(44,31,1)--��ʾ
		set_visiable(44,32,1)--��ʾ
		set_visiable(44,33,1)--��ʾ
		set_visiable(44,34,1)--��ʾ
		set_visiable(44,35,1)--��ʾ
		set_visiable(44,36,1)--��ʾ
		return 1
	
	--��������
	elseif control==5
	then
		TiaoGuang_new()
		return 1
	elseif control==7
	then
		TiaoGuang_new()
		return 1
	elseif control==9
	then
		TiaoGuang_new()
		return 1
	elseif control==16
	then
		TiaoGuang_new()
		return 1
	elseif control==17
	then
		TiaoGuang_new()
		return 1
	elseif control==19
	then
		TiaoGuang_new()
		return 1
	elseif (control==20 or control==26) and (value==1 or value==2)
	then
		brightness = get_value(44,5)
		if control==20 
		then
			if brightness < 255
			then
				brightness = brightness + 1
			end
		elseif control==26 
		then
			if brightness > 0
			then
				brightness = brightness - 1
			end
		end
		
		set_value(44,5,brightness)
		TiaoGuang_new()
		return 1
	elseif (control==20 or control==26) and value==0
	then
		return 1
	elseif (control==27 or control==29) and (value==1 or value==2)
	then
		brightness = get_value(44,7)
		if control==27 
		then
			if brightness < 255
			then
				brightness = brightness + 1
			end
		elseif control==29 
		then
			if brightness > 0
			then
				brightness = brightness - 1
			end
		end
		
		set_value(44,7,brightness)
		TiaoGuang_new()
		return 1
	elseif (control==27 or control==29) and value==0
	then
		return 1
	elseif (control==28 or control==30) and (value==1 or value==2)
	then
		brightness = get_value(44,9)
		if control==28
		then
			if brightness < 255
			then
				brightness = brightness + 1
			end
		elseif control==30 
		then
			if brightness > 0
			then
				brightness = brightness - 1
			end
		end
		
		set_value(44,9,brightness)
		TiaoGuang_new()
		return 1
	elseif (control==28 or control==30) and value==0
	then
		return 1
	elseif (control==31 or control==34) and (value==1 or value==2)
	then
		brightness = get_value(44,16)
		if control==31
		then
			if brightness < 255
			then
				brightness = brightness + 1
			end
		elseif control==34 
		then
			if brightness > 0
			then
				brightness = brightness - 1
			end
		end
		
		set_value(44,16,brightness)
		TiaoGuang_new()
		return 1
	elseif (control==31 or control==34) and value==0
	then
		return 1
	elseif (control==32 or control==35) and (value==1 or value==2)
	then
		brightness = get_value(44,17)
		if control==32
		then
			if brightness < 255
			then
				brightness = brightness + 1
			end
		elseif control==35 
		then
			if brightness > 0
			then
				brightness = brightness - 1
			end
		end
		
		set_value(44,17,brightness)
		TiaoGuang_new()
		return 1
	elseif (control==32 or control==35) and value==0
	then
		return 1
	elseif (control==33 or control==36) and (value==1 or value==2)
	then
		brightness = get_value(44,19)
		if control==33
		then
			if brightness < 255
			then
				brightness = brightness + 1
			end
		elseif control==36 
		then
			if brightness > 0
			then
				brightness = brightness - 1
			end
		end
		
		set_value(44,19,brightness)
		TiaoGuang_new()
		return 1
	elseif (control==33 or control==36) and value==0
	then
		return 1
	
	--���� ��ť
	elseif control==18 and value==1
	then
		if get_value(0,12) == 0--����Ч��
		then
			Send_cmd(0xee,0xc1,0,0,0,0,0,0,0)
		else
			Send_cmd(0xee,0xa1,0,0,0,0,0,0,0)	
		end
	
		--��ȡFlash
		data = read_flash(0x00,20)
		if data[0] == 0x33 and data[1] == 0x55 --�����������  ��̬
		then
			data[0] = 0--���λ
			data[1] = 0
			
			write_flash(0x00,data)
		end
		return 1
	elseif control==18 and value==0
	then
		return 1
	
	elseif control==22 and value==1
	then
		if get_value(44,25) == 1--���ھ�̬����ʱ������������ģ������
		then
			Save_show = 0x55--ģ������ı��
		
			set_visiable(44,15,1)--��ʾ
			set_value(44,21,1)--��ʾ
			
			set_visiable(44,16,0)--����
			set_visiable(44,17,0)--����
			set_visiable(44,19,0)--����
			
			set_visiable(44,31,0)--����
			set_visiable(44,32,0)--����
			set_visiable(44,33,0)--����
			set_visiable(44,34,0)--����
			set_visiable(44,35,0)--����
			set_visiable(44,36,0)--����
		else --��̬����ʱ
			set_value(44,22,0)
		
			Save_show = 0x00--��׼����ı��
		
			set_visiable(44,15,0)--����
			set_value(44,21,0)--����
			
			set_visiable(44,16,1)--��ʾ
			set_visiable(44,17,1)--��ʾ
			set_visiable(44,19,1)--��ʾ
			
			set_visiable(44,31,1)--��ʾ
			set_visiable(44,32,1)--��ʾ
			set_visiable(44,33,1)--��ʾ
			set_visiable(44,34,1)--��ʾ
			set_visiable(44,35,1)--��ʾ
			set_visiable(44,36,1)--��ʾ
		end

		return 1
	elseif control==22 and value==0
	then
		Save_show = 0x00--��׼����ı��
	
		set_visiable(44,15,0)--����
		set_value(44,21,0)--����
		
		set_visiable(44,16,1)--��ʾ
		set_visiable(44,17,1)--��ʾ
		set_visiable(44,19,1)--��ʾ
		
		set_visiable(44,31,1)--��ʾ
		set_visiable(44,32,1)--��ʾ
		set_visiable(44,33,1)--��ʾ
		set_visiable(44,34,1)--��ʾ
		set_visiable(44,35,1)--��ʾ
		set_visiable(44,36,1)--��ʾ

		return 1

	--�������ؼ��������ᷢ�����ݳ�ȥ
	elseif control==23
	then
		return 1
	end
end

function screen_45()
	screen = screen_t
	control = control_t
	value = value_t
	if control==41 and value==1
	then
		set_text(3,8,get_text(45,5))		
		change_screen(3)
		
		DMX_add_param = 0x33	
		return 1
	elseif control==41 and value==0
	then
		return 1
	
	--�ֶ�����
	elseif control==2 and value==1
	then
		if get_value(45,6) == 1
		then
			set_value(45,6,2)--���ÿؼ���ֵ	
		elseif get_value(45,6) == 2
		then
			set_value(45,6,3)--���ÿؼ���ֵ
		elseif get_value(45,6) == 3
		then
			set_value(45,6,4)--���ÿؼ���ֵ
		elseif get_value(45,6) == 4
		then
			set_value(45,6,5)--���ÿؼ���ֵ	
		elseif get_value(45,6) == 5
		then
			set_value(45,6,6)--���ÿؼ���ֵ	
		elseif get_value(45,6) == 6
		then
			set_value(45,6,1)--���ÿؼ���ֵ	
		end
		return 1
	elseif control==2 and value==0
	then
		return 1	
	
	--�����ֶ�
	elseif control==13 and value==1
	then
		set_text(45,22,"Setting")
		
		local dd =0	
		dd = get_value(45,6)--�ֶ�ѡ��
		if (dd <1) or (dd >6)
		then
			dd = 6
		end

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3a--ָʾUCS512-G��д����
		
		ss = get_text(45,5)
		if ss == "UCS512-G"
		then
			send_cmd_xb[7] = 0x33
		elseif ss == "UCS512-G-S"
		then
			send_cmd_xb[7] = 0x55
		end
		
		send_cmd_xb[8] = 0x01--д�ֶ����ı��
		
		send_cmd_xb[9] = dd--�ֶ�ѡ��
		send_cmd_xb[10] = 0
		send_cmd_xb[11] = 0 
		send_cmd_xb[12] = 0
		send_cmd_xb[13] = 0
		send_cmd_xb[14] = 0
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nall white")
		end
		change_screen(40)
		----
		return 1
	elseif control==13 and value==0
	then
		return 1
	
	--�Զ�д������
	elseif control==7 and value==1
	then
		if get_language() == 0
		then
			set_text(45,8,"����")
		elseif get_language() == 1
		then
			set_text(45,8,"Open")
		end
		return 1
	elseif control==7 and value==0
	then
		if get_language() == 0
		then
			set_text(45,8,"�ر�")
		elseif get_language() == 1
		then
			set_text(45,8,"Close")
		end
		return 1	
	
	--���� �Զ�д��
	elseif control==9 and value==1
	then
		set_text(45,10,"Setting")
		
		local dd =0	
		dd = get_value(45,7)--���� �Զ�д��				

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3a--ָʾUCS512-G��д����
		
		ss = get_text(45,5)
		if ss == "UCS512-G"
		then
			send_cmd_xb[7] = 0x33
		elseif ss == "UCS512-G-S"
		then
			send_cmd_xb[7] = 0x55
		end
		
		send_cmd_xb[8] = 0x02--д �Զ�д�� �ı��
		
		send_cmd_xb[9] = dd--�Զ�д�� �� ����/�ر�
		send_cmd_xb[10] = 0
		send_cmd_xb[11] = 0 
		send_cmd_xb[12] = 0
		send_cmd_xb[13] = 0
		send_cmd_xb[14] = 0
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			if dd == 0
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
			elseif dd == 1
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ�����")
			end
		elseif get_language() == 1--Ӣ��
		then	
			if dd == 0
			then
				set_text(40,2,"Write ok,\r\nall white")
			elseif dd == 1
			then
				set_text(40,2,"Write ok,\r\nall red")
			end		
		end

		change_screen(40)
		----
		return 1
	elseif control==9 and value==0
	then
		return 1
	
	--�Ҷ�ƽ�� ����
	elseif control==12 and value==1
	then
		if get_language() == 0
		then
			set_text(45,14,"����")
		elseif get_language() == 1
		then
			set_text(45,14,"Open")
		end
		return 1
	elseif control==12 and value==0
	then
		if get_language() == 0
		then
			set_text(45,14,"�ر�")
		elseif get_language() == 1
		then
			set_text(45,14,"Close")
		end
		return 1
	
	--���� �Ҷ�ƽ��
	elseif control==15 and value==1
	then
		set_text(45,16,"Setting")
		
		local dd =0	
		dd = get_value(45,12)--���� �Ҷ�ƽ��			

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3a--ָʾUCS512-G��д����
		
		ss = get_text(45,5)
		if ss == "UCS512-G"
		then
			send_cmd_xb[7] = 0x33
		elseif ss == "UCS512-G-S"
		then
			send_cmd_xb[7] = 0x55
		end
		
		send_cmd_xb[8] = 0x03--д �Ҷ�ƽ�� �ı��
		
		send_cmd_xb[9] = dd--�Ҷ�ƽ�� �� ����/�ر�
		send_cmd_xb[10] = 0
		send_cmd_xb[11] = 0 
		send_cmd_xb[12] = 0
		send_cmd_xb[13] = 0
		send_cmd_xb[14] = 0
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nall white")
		end
		change_screen(40)
		----
		return 1
	elseif control==15 and value==0
	then
		return 1
	
	--A�ڿ����� ����
	elseif control==18 and value==1
	then
		if get_language() == 0
		then
			set_text(45,19,"�ر�")
		elseif get_language() == 1
		then
			set_text(45,19,"Close")
		end
		return 1
	elseif control==18 and value==0
	then
		if get_language() == 0
		then
			set_text(45,19,"����")
		elseif get_language() == 1
		then
			set_text(45,19,"Open")
		end
		return 1
	
	--����ʱ�� 
	elseif control==46 and value==1
	then
		buc_time_count_G = buc_time_count_G + 1
		if buc_time_count_G >=32
		then
			buc_time_count_G = 0
		end 
		
		buc_time_G = buc_time_count_G*60
		set_value(45,47,buc_time_G)
	
		return 1
	elseif control==46 and value==0
	then
		return 1	
	
	--���ò���ʱ��
	elseif control==48 and value==1
	then
		set_text(45,49,"Setting")
	
		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3a--ָʾUCS512-G��д����
		
		ss = get_text(45,5)
		if ss == "UCS512-G"
		then
			send_cmd_xb[7] = 0x33
		elseif ss == "UCS512-G-S"
		then
			send_cmd_xb[7] = 0x55
		end
		
		send_cmd_xb[8] = 0x0b--д�ֶ����ı��
		
		send_cmd_xb[9] = buc_time_count_G--��ʱ�ȼ�
		send_cmd_xb[10] = 0
		send_cmd_xb[11] = 0 
		send_cmd_xb[12] = 0
		send_cmd_xb[13] = 0
		send_cmd_xb[14] = 0
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nall white")
		end
			
		change_screen(40)
		----
		return 1
	elseif control==48 and value==0
	then
		return 1
	
	--���� �Ҷ�ƽ��
	elseif control==20 and value==1
	then
		set_text(45,21,"Setting")
		
		local dd =0	
		dd = get_value(45,18)--����  �Ҷ�ƽ��				

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3a--ָʾUCS512-G��д����
		
		ss = get_text(45,5)
		if ss == "UCS512-G"
		then
			send_cmd_xb[7] = 0x33
		elseif ss == "UCS512-G-S"
		then
			send_cmd_xb[7] = 0x55
		end
		
		send_cmd_xb[8] = 0x04--д A�ڿ����� �ı��
		
		send_cmd_xb[9] = dd--�Ҷ�ƽ�� �� ����/�ر�
		send_cmd_xb[10] = 0
		send_cmd_xb[11] = 0 
		send_cmd_xb[12] = 0
		send_cmd_xb[13] = 0
		send_cmd_xb[14] = 0
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nall white")
		end
		change_screen(40)
		----
		return 1
	elseif control==20 and value==0
	then
		return 1
	
	--���� �����ȼ�
	elseif control==26 and value==1
	then
		set_text(45,27,"Setting")
	
		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3a--ָʾUCS512-G��д����
		
		ss = get_text(45,5)
		if ss == "UCS512-G"
		then
			send_cmd_xb[7] = 0x33
		elseif ss == "UCS512-G-S"
		then
			send_cmd_xb[7] = 0x55
		end
		
		send_cmd_xb[8] = 0x05--д �����ȼ� �ı��
		
		send_cmd_xb[9]  = get_value(45,24)--RR
		send_cmd_xb[10] = get_value(45,25)--GG
		send_cmd_xb[11] = get_value(45,29)--BB
		send_cmd_xb[12] = get_value(45,30)--W1
		send_cmd_xb[13] = get_value(45,33)--W2
		send_cmd_xb[14] = get_value(45,34)--W3
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nall white")
		end
		change_screen(40)
		----
		return 1
	elseif control==26 and value==0
	then
		return 1
	
	--���� PWM�ȼ�
	elseif control==31 and value==1
	then
		set_text(45,32,"Setting")
	
		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3a--ָʾUCS512-G��д����
		
		ss = get_text(45,5)
		if ss == "UCS512-G"
		then
			send_cmd_xb[7] = 0x33
		elseif ss == "UCS512-G-S"
		then
			send_cmd_xb[7] = 0x55
		end
		
		send_cmd_xb[8] = 0x06--д PWM�ȼ� �ı��
		
		send_cmd_xb[9]  = get_value(45,35)--RR
		send_cmd_xb[10] = get_value(45,36)--GG
		send_cmd_xb[11] = get_value(45,37)--BB
		send_cmd_xb[12] = get_value(45,38)--W1
		send_cmd_xb[13] = get_value(45,39)--W2
		send_cmd_xb[14] = get_value(45,40)--W3
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nall white")
		end
		change_screen(40)
		----
		return 1
	elseif control==31 and value==0
	then
		return 1
	
	--������һҳ��label
	elseif control==43 and value==1
	then
		set_text(46,5,get_text(45,5))
		return 1
	elseif control==43 and value==0
	then
		return 1
	end
end

function screen_46()
	screen = screen_t
	control = control_t
	value = value_t
	if control==8 and value==1
	then
		if get_language() == 0
		then
			set_text(46,28,"�ر�")
		elseif get_language() == 1
		then
			set_text(46,28,"Close")
		end
		return 1
	elseif control==8 and value==0
	then
		if get_language() == 0
		then
			set_text(46,28,"����")
		elseif get_language() == 1
		then
			set_text(46,28,"Open")
		end
		return 1
	
	--���ź�״̬ ����
	elseif control==7 and value==1
	then
		if get_language() == 0
		then
			set_text(46,21,"�������һ֡")
		elseif get_language() == 1
		then
			set_text(46,21,"Save last frame")
		end
		return 1
	elseif control==7 and value==0
	then
		if get_language() == 0
		then
			set_text(46,21,"�ָ��ϵ�״̬")
		elseif get_language() == 1
		then
			set_text(46,21,"Restore light status")
		end
		return 1
	
	--�˿�ˢ��������
	elseif control==18 and value==1
	then
		S5C3 = get_text(46,19)--��ȡ��ǰֵ

		if S5C3 == "250Hz"
		then
			set_text(46,19,"4KHz")--���ÿؼ���ֵ	
		elseif S5C3 == "4KHz"
		then
			set_text(46,19,"8KHz")--���ÿؼ���ֵ
		elseif S5C3 == "8KHz"
		then
			set_text(46,19,"16KHz")--���ÿؼ���ֵ
		elseif S5C3 == "16KHz"
		then
			set_text(46,19,"250Hz")--���ÿؼ���ֵ	
		end

		return 1
	elseif control==18 and value==0
	then
		return 1	
	
	--�������� ����
	elseif control==12 and value==1
	then
		S5C3 = get_text(46,14)--��ȡ��ǰֵ

		if S5C3 == "1S/��"
		then
			set_text(46,14,"4S/��")--���ÿؼ���ֵ	
		elseif S5C3 == "4S/��"
		then
			set_text(46,14,"1S/��")--���ÿؼ���ֵ
		end
		return 1
	elseif control==12 and value==0
	then
		return 1
	
	--RGBȫ�ʽ��� ����
	elseif control==2 and value==1
	then
		S5C3 = get_text(46,9)--��ȡ��ǰֵ

		if S5C3 == "25ms/��"
		then
			set_text(46,9,"200ms/��")--���ÿؼ���ֵ	
		elseif S5C3 == "200ms/��"
		then
			set_text(46,9,"25ms/��")--���ÿؼ���ֵ
		end
		return 1
	elseif control==2 and value==0
	then
		return 1	
	
	--���彥�� ����
	elseif control==10 and value==1
	then
		S5C3 = get_text(46,15)--��ȡ��ǰֵ

		if S5C3 == "20ms/��"
		then
			set_text(46,15,"200ms/��")--���ÿؼ���ֵ	
		elseif S5C3 == "200ms/��"
		then
			set_text(46,15,"20ms/��")--���ÿؼ���ֵ
		end
		return 1
	elseif control==10 and value==0
	then
		return 1
	
	--UCS512-G2д���� 46 31 32
	elseif control==31 and value==1
	then
		set_text(46,32,"Setting")
		
		tmp_dat[6] = 0x00--оƬ��Ŀ Ĭ��512
		tmp_dat[7] = 0x02	

		---------
		tmp_dat[8] = 0x02
		
		local dd =0	
		dd = get_value(46,8)--��ַ�߼��ģʽ
		if dd ==1--������ �ر� ��ַ�߼��ģʽ
		then
			tmp_dat[8]  = Or(tmp_dat[8],0x40)	
		end
		
		dd = get_value(46,7)--���ź�״̬
		if dd ==0--������ �ָ��ϵ�����
		then
			tmp_dat[8]  = Or(tmp_dat[8],0x20)	
		end

		ss = get_text(46,19)--�˿�ˢ����
		if ss == "250Hz"
		then
			tmp_dat[8] = tmp_dat[8]
		elseif ss == "4KHz"
		then
			tmp_dat[8] = Or(tmp_dat[8],0x08)
		elseif ss == "8KHz"
		then
			tmp_dat[8] = Or(tmp_dat[8],0x10)
		elseif  ss == "16KHz"
		then
			tmp_dat[8] = Or(tmp_dat[8],0x18)
		end	
		------------------
		
		------------------
		tmp_dat[9] = 0x00
		
		dd = get_value(46,16)--KM2
		if dd == 1
		then
			tmp_dat[9] = Or(tmp_dat[9],0x80)
		end	

		dd = get_value(46,17)--KM1
		if dd == 1
		then
			tmp_dat[9] = Or(tmp_dat[9],0x40)
		end

		dd = get_value(46,20)--KM0
		if dd == 1
		then
			tmp_dat[9] = Or(tmp_dat[9],0x20)
		end
		
		ss = get_text(46,14)--�������� ST2
		if ss == "4S/��"
		then
			tmp_dat[9] = Or(tmp_dat[9],0x10)
		end
		
		ss = get_text(46,9)--RGBȫ������ ST1
		if ss == "200ms/��"
		then
			tmp_dat[9] = Or(tmp_dat[9],0x08)
		end
		
		ss = get_text(46,15)--RGBȫ������ ST0
		if ss == "200ms/��"
		then
			tmp_dat[9] = Or(tmp_dat[9],0x04)
		end
		-------------------

		--�ϵ�����״̬
		tmp_dat[10] = get_value(46,24)--R
		tmp_dat[11] = get_value(46,25)--G
		tmp_dat[12] = get_value(46,29)--B
		tmp_dat[13] = get_value(46,30)--W1
		tmp_dat[14] = get_value(46,33)--W2
		tmp_dat[15] = get_value(46,34)--W3

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		send_cmd_xb[6] = 0x3a--ָʾUCS512-G��д����
		
		ss = get_text(46,5)
		if ss == "UCS512-G"
		then
			send_cmd_xb[7] = 0x33
		elseif ss == "UCS512-G-S"
		then
			send_cmd_xb[7] = 0x55
		end
		
		send_cmd_xb[8] = 0x07--д �������� �ı��	
		
		send_cmd_xb[9] = tmp_dat[8]--��ַ�߼��ģʽ ���ź�״̬ �˿�ˢ����
		send_cmd_xb[10] = tmp_dat[9]--KM2-0  ST2-0
		send_cmd_xb[11] = tmp_dat[10]--R
		send_cmd_xb[12] =tmp_dat[11]--G
		send_cmd_xb[13] =tmp_dat[12]--B
		send_cmd_xb[14] =tmp_dat[13]--W1
		send_cmd_xb[15] =tmp_dat[14]--W2
		send_cmd_xb[16] =tmp_dat[15]--W3
		send_cmd_xb[17] =0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			if get_value(46,8) == 0--Ĭ�� ���� ��ַ�߼��ģʽ
			then
				if get_value(45,7) == 0--Ĭ��  �ر� �Զ�дַģʽ
				then	
					set_text(40,2,"д�����ɹ���,\r\n����оƬ���Ƶ�")
				else --�� �Զ�дַģʽ
					set_text(40,2,"д�ɹ���,�׵ƻ�,��ƺ�\r\n�����лƵ�,���ַ���쳣\r\n�������˸,��д�����쳣")
				end
			else --�ر� ��ַ�߼��ģʽ
				if (get_value(46,16)==1) or (get_value(46,17)==1) or (get_value(46,20)==1)
				then
					set_text(40,2,"д�����ɹ���,\r\n����оƬ�ܶ��Ա�Ч��")
				else
					set_text(40,2,"д�����ɹ���,\r\n����оƬ���ϵ�������ɫ")
				end
			end
		elseif get_language() == 1--Ӣ��
		then	
			if get_value(46,8) == 0--Ĭ�� ���� ��ַ�߼��ģʽ
			then
				if get_value(45,7) == 0--Ĭ��  �ر� �Զ�дַģʽ
				then	
					set_text(40,2,"Write ok,\r\nall yellow")
				else --�� �Զ�дַģʽ
					set_text(40,2,"Write ok,\r\nfirst yellow,other red\r\nother yellow,pi bad\r\nyellow red run,AB bad")
				end
			else --�ر� ��ַ�߼��ģʽ
				if (get_value(46,16)==1) or (get_value(46,17)==1) or (get_value(46,20)==1)
				then
					set_text(40,2,"Write ok,\r\nall run change flash")
				else
					set_text(40,2,"Write ok,\r\nall run light status")
				end
			end
		end
		change_screen(40)
		----
		return 1
	elseif control==31 and value==0
	then
		return 1
	end
end

function screen_47()
	screen = screen_t
	control = control_t
	value = value_t
	if control==41 and value==1
	then
		set_text(3,8,get_text(47,5))		
		change_screen(3)
		
		DMX_add_param = 0x33	
		return 1
	elseif control==41 and value==0
	then
		return 1
	
	--�ֶ�����
	elseif control==2 and value==1
	then
		if get_value(47,6) == 1
		then
			set_value(47,6,2)--���ÿؼ���ֵ	
		elseif get_value(47,6) == 2
		then
			set_value(47,6,3)--���ÿؼ���ֵ
		elseif get_value(47,6) == 3
		then
			set_value(47,6,4)--���ÿؼ���ֵ
		elseif get_value(47,6) == 4
		then
			set_value(47,6,1)--���ÿؼ���ֵ	
		end
		return 1
	elseif control==2 and value==0
	then
		return 1
	
	--�����ֶ�
	elseif control==13 and value==1
	then
		set_text(47,22,"Setting")
		
		local dd =0	
		dd = get_value(47,6)--�ֶ�ѡ��
		if (dd <1) or (dd >4)
		then
			dd = 4
		end

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3a--ָʾUCS512-G��д����
		
		ss = get_text(47,5)
		if ss == "UCS512-H"
		then
			send_cmd_xb[7] = 0x33
		elseif ss == "UCS512-H-S"
		then
			send_cmd_xb[7] = 0x55
		end
		
		send_cmd_xb[8] = 0x01--д�ֶ����ı��
		
		send_cmd_xb[9] = dd--�ֶ�ѡ��
		send_cmd_xb[10] = 0
		send_cmd_xb[11] = 0 
		send_cmd_xb[12] = 0
		send_cmd_xb[13] = 0
		send_cmd_xb[14] = 0
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		ss = get_text(47,5)
		if ss == "UCS512-H"--����
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n��оƬ�Ƶ�,\r\n����оƬ���׵�")
			elseif get_language() == 1--Ӣ��
			then
				set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
			end	
		elseif ss == "UCS512-H-S"--����
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(40,2,"Write ok,\r\nall white")
			end
		end
			
		change_screen(40)
		----
		return 1
	elseif control==13 and value==0
	then
		return 1
	
	--�Զ�д������
	elseif control==7 and value==1
	then
		if get_language() == 0
		then
			set_text(47,8,"����")
		elseif get_language() == 1
		then
			set_text(47,8,"Open")
		end
		return 1
	elseif control==7 and value==0
	then
		if get_language() == 0
		then
			set_text(47,8,"�ر�")
		elseif get_language() == 1
		then
			set_text(47,8,"Close")
		end
		return 1
	
	--���� �Զ�д��
	elseif control==9 and value==1
	then
		set_text(47,10,"Setting")
		
		local dd =0	
		dd = get_value(47,7)--���� �Զ�д��				

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3a--ָʾUCS512-G��д����
		
		ss = get_text(47,5)
		if ss == "UCS512-H"
		then
			send_cmd_xb[7] = 0x33
		elseif ss == "UCS512-H-S"
		then
			send_cmd_xb[7] = 0x55
		end
		
		send_cmd_xb[8] = 0x02--д �Զ�д�� �ı��
		
		send_cmd_xb[9] = dd--�Զ�д�� �� ����/�ر�
		send_cmd_xb[10] = 0
		send_cmd_xb[11] = 0 
		send_cmd_xb[12] = 0
		send_cmd_xb[13] = 0
		send_cmd_xb[14] = 0
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		ss = get_text(47,5)
		if ss == "UCS512-H"--����д
		then
			if get_language() == 0--����
			then
				if dd == 0 --�ر�
				then
					set_text(40,2,"д�����ɹ���,\r\n��оƬ�Ƶ�,\r\n����оƬ���׵�")
				elseif dd == 1 --����
				then
					set_text(40,2,"д�����ɹ���,\r\n��оƬ�Ƶ�,\r\n����оƬ���ϵ�")
				end
			elseif get_language() == 1--Ӣ��
			then	
				if dd == 0
				then
					set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
				elseif dd == 1
				then
					set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother violet")
				end		
			end
		elseif ss == "UCS512-H-S" --����д
		then
			if get_language() == 0--����
			then
				if dd == 0 --�ر�
				then
					set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
				elseif dd == 1 --����
				then
					set_text(40,2,"д�����ɹ���,\r\n�������ϵ�")
				end
			elseif get_language() == 1--Ӣ��
			then	
				if dd == 0
				then
					set_text(40,2,"Write ok,\r\nall white")	
				elseif dd == 1
				then
					set_text(40,2,"Write ok,\r\nall violet")
				end		
			end
		end

		change_screen(40)
		----
		return 1
	elseif control==9 and value==0
	then
		return 1
	
	--�Ҷ�ƽ�� ����
	elseif control==12 and value==1
	then
		if get_language() == 0
		then
			set_text(47,14,"����")
		elseif get_language() == 1
		then
			set_text(47,14,"Open")
		end
		return 1
	elseif control==12 and value==0
	then
		if get_language() == 0
		then
			set_text(47,14,"�ر�")
		elseif get_language() == 1
		then
			set_text(47,14,"Close")
		end
		return 1
	end	
	
	--���� �Ҷ�ƽ��
	if control==15 and value==1
	then
		set_text(47,16,"Setting")
		
		local dd =0	
		dd = get_value(47,12)--���� �Ҷ�ƽ��			

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3a--ָʾUCS512-G��д����
		
		ss = get_text(47,5)
		if ss == "UCS512-H"
		then
			send_cmd_xb[7] = 0x33
		elseif ss == "UCS512-H-S"
		then
			send_cmd_xb[7] = 0x55
		end
		
		send_cmd_xb[8] = 0x03--д �Ҷ�ƽ�� �ı��
		
		send_cmd_xb[9] = dd--�Ҷ�ƽ�� �� ����/�ر�
		send_cmd_xb[10] = 0
		send_cmd_xb[11] = 0 
		send_cmd_xb[12] = 0
		send_cmd_xb[13] = 0
		send_cmd_xb[14] = 0
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		ss = get_text(47,5)
		if ss == "UCS512-H"
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n��оƬ�Ƶ�,\r\n����оƬ���׵�")
			elseif get_language() == 1--Ӣ��
			then
				set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
			end	
		elseif ss == "UCS512-H-S"
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(40,2,"Write ok,\r\nall white")
			end
		end	
		change_screen(40)
		----
		return 1
	elseif control==15 and value==0
	then
		return 1
	
	--A�ڿ����� ����
	elseif control==18 and value==1
	then
		if get_language() == 0
		then
			set_text(47,19,"�ر�")
		elseif get_language() == 1
		then
			set_text(47,19,"Close")
		end
		return 1
	elseif control==18 and value==0
	then
		if get_language() == 0
		then
			set_text(47,19,"����")
		elseif get_language() == 1
		then
			set_text(47,19,"Open")
		end
		return 1
	
	--���� ������
	elseif control==20 and value==1
	then
		set_text(47,21,"Setting")
		
		local dd =0	
		dd = get_value(47,18)--����  �Ҷ�ƽ��				

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3a--ָʾUCS512-G��д����
		
		ss = get_text(47,5)
		if ss == "UCS512-H"
		then
			send_cmd_xb[7] = 0x33
		elseif ss == "UCS512-H-S"
		then
			send_cmd_xb[7] = 0x55
		end
		
		send_cmd_xb[8] = 0x04--д A�ڿ����� �ı��
		
		send_cmd_xb[9] = dd--�Ҷ�ƽ�� �� ����/�ر�
		send_cmd_xb[10] = 0
		send_cmd_xb[11] = 0 
		send_cmd_xb[12] = 0
		send_cmd_xb[13] = 0
		send_cmd_xb[14] = 0
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		ss = get_text(47,5)
		if ss == "UCS512-H"
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n��оƬ�Ƶ�,\r\n����оƬ���׵�")
			elseif get_language() == 1--Ӣ��
			then
				set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
			end	
		elseif ss == "UCS512-H-S"
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(40,2,"Write ok,\r\nall white")
			end
		end	
		change_screen(40)	
		----
		return 1
	elseif control==20 and value==0
	then
		return 1
	
	--0�ֶ�ģʽ ����
	elseif control==35 and value==1
	then
		if get_language() == 0
		then
			set_text(47,36,"����")
		elseif get_language() == 1
		then
			set_text(47,36,"Open")
		end
		return 1
	elseif control==35 and value==0
	then
		if get_language() == 0
		then
			set_text(47,36,"�ر�")
		elseif get_language() == 1
		then
			set_text(47,36,"Close")
		end
		return 1
	
	--���� 0 �ֶ�ģʽ
	elseif control==31 and value==1
	then
		set_text(47,32,"Setting")
		
		local dd =0	
		dd = get_value(47,35)--����  0�ֶ�ģʽ			

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3a--ָʾUCS512-G��д����
		
		ss = get_text(47,5)
		if ss == "UCS512-H"
		then
			send_cmd_xb[7] = 0x33
		elseif ss == "UCS512-H-S"
		then
			send_cmd_xb[7] = 0x55
		end
		
		send_cmd_xb[8] = 0x08--д 0�ֶ�ģʽ
		
		send_cmd_xb[9] = dd--0�ֶ�ģʽ �� ����/�ر�
		
		start_ch = get_value(47,45)--��ʼ��ַ
		send_cmd_xb[10] = math.modf(start_ch/256)	
		send_cmd_xb[11] = math.modf(start_ch%256)
		
		send_cmd_xb[12] = 0
		send_cmd_xb[13] = 0
		send_cmd_xb[14] = 0
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		ss = get_text(47,5)
		if ss == "UCS512-H"
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n��оƬ�Ƶ�,\r\n����оƬ���׵�")
			elseif get_language() == 1--Ӣ��
			then
				set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
			end	
		elseif ss == "UCS512-H-S"
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(40,2,"Write ok,\r\nall white")
			end
		end	
		change_screen(40)	
		----
		return 1
	elseif control==31 and value==0
	then
		return 1
	
	--����ʱ�� 
	elseif control==34 and value==1
	then
		buc_time_count_H = buc_time_count_H + 1
		if buc_time_count_H >=32
		then
			buc_time_count_H = 0
		end 
		
		buc_time_H = buc_time_count_H*60
		set_value(47,37,buc_time_H)
	
		return 1
	elseif control==34 and value==0
	then
		return 1
	
	--���ò���ʱ��
	elseif control==38 and value==1
	then
		set_text(47,39,"Setting")
	
		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3a--ָʾUCS512-G��д����
		
		ss = get_text(47,5)
		if ss == "UCS512-H"
		then
			send_cmd_xb[7] = 0x33
		elseif ss == "UCS512-H-S"
		then
			send_cmd_xb[7] = 0x55
		end
		
		send_cmd_xb[8] = 0x0b--д�ֶ����ı��
		
		send_cmd_xb[9] = buc_time_count_H--��ʱ�ȼ�
		send_cmd_xb[10] = 0
		send_cmd_xb[11] = 0 
		send_cmd_xb[12] = 0
		send_cmd_xb[13] = 0
		send_cmd_xb[14] = 0
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		ss = get_text(47,5)
		if ss == "UCS512-H"--����
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n��оƬ�Ƶ�,\r\n����оƬ���׵�")
			elseif get_language() == 1--Ӣ��
			then
				set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
			end	
		elseif ss == "UCS512-H-S"--����
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(40,2,"Write ok,\r\nall white")
			end
		end
			
		change_screen(40)
		----
		return 1
	elseif control==38 and value==0
	then
		return 1
	
	--���� �����ȼ�
	elseif control==26 and value==1
	then
		set_text(47,27,"Setting")
	
		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3a--ָʾUCS512-G��д����
		
		ss = get_text(47,5)
		if ss == "UCS512-H"
		then
			send_cmd_xb[7] = 0x33
		elseif ss == "UCS512-H-S"
		then
			send_cmd_xb[7] = 0x55
		end
		
		send_cmd_xb[8] = 0x0a--д �����ȼ� �ı��
		
		send_cmd_xb[9]  = get_value(47,24)--RR
		send_cmd_xb[10] = get_value(47,25)--GG
		send_cmd_xb[11] = get_value(47,29)--BB
		send_cmd_xb[12] = get_value(47,30)--W
		send_cmd_xb[13] = 0
		send_cmd_xb[14] = 0
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		ss = get_text(47,5)
		if ss == "UCS512-H"
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n��оƬ�Ƶ�,\r\n����оƬ���׵�")
			elseif get_language() == 1--Ӣ��
			then
				set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
			end	
		elseif ss == "UCS512-H-S"
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(40,2,"Write ok,\r\nall white")
			end
		end	
		change_screen(40)	
		----
		return 1
	elseif control==26 and value==0
	then
		return 1
	
	--������һҳ��label
	elseif control==43 and value==1
	then
		set_text(48,5,get_text(47,5))
		return 1
	elseif control==43 and value==0
	then
		return 1
	end
end

function screen_48()
	screen = screen_t
	control = control_t
	value = value_t
	if control==8 and value==1
	then
		if get_language() == 0
		then
			set_text(48,28,"�ر�")
		elseif get_language() == 1
		then
			set_text(48,28,"Close")
		end
		return 1
	elseif control==8 and value==0
	then
		if get_language() == 0
		then
			set_text(48,28,"����")
		elseif get_language() == 1
		then
			set_text(48,28,"Open")
		end
		return 1	
	
	--���ź�״̬ ����
	elseif control==7 and value==1
	then
		if get_language() == 0
		then
			set_text(48,21,"�������һ֡")
		elseif get_language() == 1
		then
			set_text(48,21,"Save last frame")
		end
		return 1
	elseif control==7 and value==0
	then
		if get_language() == 0
		then
			set_text(48,21,"�ָ��ϵ�״̬")
		elseif get_language() == 1
		then
			set_text(48,21,"Restore light status")
		end
		return 1
	
	--�˿�ˢ��������
	elseif control==18 and value==1
	then
		S5C3 = get_text(48,19)--��ȡ��ǰֵ

		if S5C3 == "250Hz"
		then
			set_text(48,19,"4KHz")--���ÿؼ���ֵ	
		elseif S5C3 == "4KHz"
		then
			set_text(48,19,"8KHz")--���ÿؼ���ֵ
		elseif S5C3 == "8KHz"
		then
			set_text(48,19,"32KHz")--���ÿؼ���ֵ
		elseif S5C3 == "32KHz"
		then
			set_text(48,19,"250Hz")--���ÿؼ���ֵ	
		end

		return 1
	elseif control==18 and value==0
	then
		return 1
	
	--UCS512-H2д���� 46 31 32
	elseif control==31 and value==1
	then
		set_text(48,32,"Setting")
		
		tmp_dat[6] = 0x00--оƬ��Ŀ Ĭ��512
		tmp_dat[7] = 0x02	

		---------
		tmp_dat[8] = 0x02
		
		local dd =0	
		dd = get_value(48,8)--��ַ�߼��ģʽ
		if dd ==1--������ �ر� ��ַ�߼��ģʽ
		then
			tmp_dat[8]  = Or(tmp_dat[8],0x40)	
		end
		
		dd = get_value(48,7)--���ź�״̬
		if dd ==0--������ �ָ��ϵ�����
		then
			tmp_dat[8]  = Or(tmp_dat[8],0x20)	
		end

		ss = get_text(48,19)--�˿�ˢ����
		if ss == "250Hz"
		then
			tmp_dat[8] = tmp_dat[8]
		elseif ss == "4KHz"
		then
			tmp_dat[8] = Or(tmp_dat[8],0x08)
		elseif ss == "8KHz"
		then
			tmp_dat[8] = Or(tmp_dat[8],0x10)
		elseif  ss == "32KHz"
		then
			tmp_dat[8] = Or(tmp_dat[8],0x18)
		end	
		------------------
		
		------------------
		tmp_dat[9] = 0x00

		--�ϵ�����״̬
		tmp_dat[10] = get_value(48,24)--R
		tmp_dat[11] = get_value(48,25)--G
		tmp_dat[12] = get_value(48,29)--B
		tmp_dat[13] = get_value(48,30)--W

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		send_cmd_xb[6] = 0x3a--ָʾUCS512-G��д����
		
		ss = get_text(48,5)
		if ss == "UCS512-H"
		then
			send_cmd_xb[7] = 0x33
		elseif ss == "UCS512-H-S"
		then
			send_cmd_xb[7] = 0x55
		end
		
		send_cmd_xb[8] = 0x09--д �������� �ı��	
		
		send_cmd_xb[9] = tmp_dat[8]--��ַ�߼��ģʽ ���ź�״̬ �˿�ˢ����
		send_cmd_xb[10] = tmp_dat[10]--R
		send_cmd_xb[11] = tmp_dat[11]--G
		send_cmd_xb[12] =tmp_dat[12]--B
		send_cmd_xb[13] =tmp_dat[13]--W
		send_cmd_xb[14] =0
		send_cmd_xb[15] =0
		send_cmd_xb[16] =0
		send_cmd_xb[17] =0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			if get_value(48,8) == 0--Ĭ�� ���� ��ַ�߼��ģʽ
			then
				if get_value(47,7) == 0--Ĭ��  �ر� �Զ�дַģʽ
				then	
					set_text(40,2,"д�����ɹ���,\r\n����оƬ���Ƶ�")
				else --�� �Զ�дַģʽ
					set_text(40,2,"д�ɹ���,�׵ƻ�,��ƺ�")
				end
			else --�ر� ��ַ�߼��ģʽ
				set_text(40,2,"д�����ɹ���,\r\n����оƬ���ϵ�������ɫ")
			end
		elseif get_language() == 1--Ӣ��
		then	
			if get_value(48,8) == 0--Ĭ�� ���� ��ַ�߼��ģʽ
			then
				if get_value(47,7) == 0--Ĭ��  �ر� �Զ�дַģʽ
				then	
					set_text(40,2,"Write ok,\r\nall yellow")
				else --�� �Զ�дַģʽ
					set_text(40,2,"Write ok,\r\nfirst yellow,other red")
				end
			else --�ر� ��ַ�߼��ģʽ
				set_text(40,2,"Write ok,\r\nall run light status")
			end
		end
		change_screen(40)
		----
		return 1
	elseif control==31 and value==0
	then
		return 1
	end
end

function screen_49()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==2 and value==1
	then
		if get_value(49,6) == 1
		then
			set_value(49,6,2)--���ÿؼ���ֵ	
		elseif get_value(49,6) == 2
		then
			set_value(49,6,3)--���ÿؼ���ֵ
		elseif get_value(49,6) == 3
		then
			set_value(49,6,4)--���ÿؼ���ֵ
		elseif get_value(49,6) == 4
		then
			set_value(49,6,1)--���ÿؼ���ֵ	
		end
		return 1
	elseif control==2 and value==0
	then
		return 1	
	--�����Զ�д���ͨ����
	elseif control==5 and value==1
	then
		if get_value(49,14) == 1
		then
			set_value(49,14,2)--���ÿؼ���ֵ	
		elseif get_value(49,14) == 2
		then
			set_value(49,14,3)--���ÿؼ���ֵ
		elseif get_value(49,14) == 3
		then
			set_value(49,14,4)--���ÿؼ���ֵ
		elseif get_value(49,14) == 4
		then
			set_value(49,14,1)--���ÿؼ���ֵ	
		end
		return 1
	elseif control==5 and value==0
	then
		return 1
	
	elseif control==7 and value==1
	then	
		if get_language() == 0
		then
			set_text(49,16,"�ָ��ϵ�״̬")
		elseif get_language() == 1
		then
			set_text(49,16,"Restore light status")
		end
		return 1
	elseif control==7 and value==0
	then	
		if get_language() == 0
		then
			set_text(49,16,"�������һ֡")
		elseif get_language() == 1
		then
			set_text(49,16,"Save last frame")
		end
		return 1	
	
	--�����ֶ���
	elseif control==28 and value==1
	then
		set_text(49,29,"Setting")
		
		---ͨ����
		local ch_num = get_value(49,6)
		if ch_num==1 
		then
			tmp_dat[7] = 0x00
		elseif ch_num==2
		then
			tmp_dat[7] = 0x01
		elseif ch_num==3 
		then
			tmp_dat[7] = 0x02
		elseif ch_num==4 
		then
			tmp_dat[7] = 0x03
		else
			tmp_dat[7] = 0x03
		end	


		Send_cmd(0xb9,tmp_dat[7],0,0,0,0,0,0,0)		
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")
		end
		
		change_screen(40)

		return 1	
	elseif control==28 and value==0
	then
		return 1		
	
	--���ò���
	elseif control==13 and value==1
	then
		set_text(49,15,"Setting")
		
		tmp_dat[8] = 0;
		
		--���ź�״̬ �Լ� �ϵ�����״̬ ����
		if get_value(49,7) ==0 --�������һ֡
		then
			tmp_dat[8] = 0x08
		elseif get_value(49,7) ==1 --�ָ��ϵ�����״̬
		then
			if get_value(49,9) ==1
			then
				tmp_dat[8] = Or(tmp_dat[8],0x10)--R
			end
			
			if get_value(49,10) ==1
			then
				tmp_dat[8] = Or(tmp_dat[8],0x20)--G
			end
			
			if get_value(49,11) ==1
			then
				tmp_dat[8] = Or(tmp_dat[8],0x40)--B
			end
			
			if get_value(49,12) ==1
			then
				tmp_dat[8] = Or(tmp_dat[8],0x80)--W
			end
		else
			tmp_dat[8] = 0x08
		end

		Send_cmd(0xb7,0,tmp_dat[8],0,0,0,0,0,0)		
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ���ϵ�������ɫ")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nall run light status")
		end
		
		change_screen(40)

		return 1	
	elseif control==13 and value==0
	then
		return 1		
	
	--�Զ�д�� ���� / �ر�
	elseif control==18 and value==1
	then
		set_text(49,20,"Setting")
	
		--��ʼ��ַ
		 start_ch = get_value(49,19)
		 tmp_dat[7] = math.modf(start_ch/256)	
		 tmp_dat[8] = math.modf(start_ch%256)
	
		---�����ַ
		tmp_dat[9] = get_value(49,14)

		--���� / �ر� �Զ�д�빦��
		if get_value(49,17) ==0 -- �Զ�д��
		then
			tmp_dat[10] = 0x55;
		else
			tmp_dat[10] = 0xaa;
		end 

		Send_cmd(0xb8,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],0,0,0,0)		
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		if tmp_dat[10] == 0x55 --����
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ�����")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(40,2,"Write ok,\r\nAll red")
			end
		elseif tmp_dat[10] == 0xaa --�ر�
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")
			end
		end

		change_screen(40)

		return 1	
	elseif control==18 and value==0
	then
		return 1		
	
	--�л���д�������� 2
	elseif control==25 and value==1
	then
		set_text(28,27,"GS8516")		
		change_screen(28)
		return 1
	elseif control==25 and value==0
	then
		return 1
	--�л���д�����
	elseif control==41 and value==1
	then
		set_text(3,8,"GS8516")			
		change_screen(3)
		
		DMX_add_param = 0x33
		return 1
	elseif control==41 and value==0
	then
		return 1
	end
end

function screen_50()
	screen = screen_t
	control = control_t
	value = value_t
	if control==7 and value==1
	then
		if get_text(50,8) == "1.0"
		then
			set_text(50,8,"2.0")
		elseif get_text(50,8) == "2.0"
		then
			set_text(50,8,"2.2")
		elseif get_text(50,8) == "2.2"
		then
			set_text(50,8,"2.5")
		elseif get_text(50,8) == "2.5"
		then
			set_text(50,8,"1.0")	
		end
		return 1
	elseif control==7 and value==0
	then
		return 1
	elseif control==9 and value==1
	then
		if get_text(50,10) == "0ns"
		then
			set_text(50,10,"220ns")
		elseif get_text(50,10) == "220ns"
		then
			set_text(50,10,"440ns")
		elseif get_text(50,10) == "440ns"
		then
			set_text(50,10,"660ns")
		elseif get_text(50,10) == "660ns"
		then
			set_text(50,10,"880ns")	
		elseif get_text(50,10) == "880ns"
		then
			set_text(50,10,"1100ns")
		elseif get_text(50,10) == "1100ns"
		then
			set_text(50,10,"1320ns")
		elseif get_text(50,10) == "1320ns"
		then
			set_text(50,10,"1540ns")
		elseif get_text(50,10) == "1540ns"
		then
			set_text(50,10,"0ns")
		end
		return 1
	elseif control==9 and value==0
	then
		return 1
	elseif control==21 and value==1
	then
		if get_text(50,5) == "250Hz"
		then
			set_text(50,5,"4KHz")
		elseif get_text(50,5) == "4KHz"
		then
			set_text(50,5,"32KHz")
		elseif get_text(50,5) == "32KHz"
		then
			set_text(50,5,"64KHz")
		elseif get_text(50,5) == "64KHz"
		then
			set_text(50,5,"250Hz")	
		end
		return 1
	elseif control==21 and value==0
	then
		return 1
	elseif control==18 and value==1
	then
		set_text(3,8,get_text(50,43))		
		change_screen(3)
		
		DMX_add_param = 0x33	
		return 1
	elseif control==18 and value==0
	then
		return 1
	
	elseif control==41 and value==1 --��������
	then
		set_text(50,42,"Setting")
	
		tmp_dat[7] = get_value(50,6)--�Զ���ַ���� 0-255
		
		local tmp
		tmp_dat[8] = 0 --Gamma �ͻԲ���  ͨ����
		if get_text(50,8) == "1.0"
		then
			tmp = 0
		elseif get_text(50,8) == "2.0"
		then
			tmp = 1		
		elseif get_text(50,8) == "2.2"
		then
			tmp = 2
		elseif get_text(50,8) == "2.5"
		then
			tmp = 3
		end
		tmp_dat[8] = Or(tmp_dat[8],tmp)		
		
		----------------------
		if get_text(50,10) == "0ns"
		then
			tmp = 0
		elseif get_text(50,10) == "220ns"
		then
			tmp = 1
		elseif get_text(50,10) == "440ns"
		then
			tmp = 2
		elseif get_text(50,10) == "660ns"
		then
			tmp = 3
		elseif get_text(50,10) == "880ns"
		then
			tmp = 4
		elseif get_text(50,10) == "1100ns"
		then
			tmp = 5
		elseif get_text(50,10) == "1320ns"
		then
			tmp = 6
		elseif get_text(50,10) == "1540ns"
		then
			tmp = 7
		end	
		tmp_dat[8] = Or(tmp_dat[8],tmp<<2)
		
		--------------------------------
		tmp = get_value(50,13)-1
		tmp_dat[8] = Or(tmp_dat[8],tmp<<5)
		
		tmp_dat[9] = 0
		tmp = get_value(50,14) --OUT����ź�
		tmp_dat[9] = Or(tmp_dat[9],tmp)
		
		tmp = get_value(50,16) --WYZ3������
		tmp_dat[9] = Or(tmp_dat[9],tmp<<1)
		
		tmp = get_value(50,19) --��ַ�߿�·���
		tmp_dat[9] = Or(tmp_dat[9],tmp<<2)

		-----------------------------------------
		if get_text(50,5) == "250Hz"
		then
			tmp = 0
		elseif get_text(50,5) == "4KHz"
		then
			tmp = 1		
		elseif get_text(50,5) == "16KHz"
		then
			tmp = 2
		elseif get_text(50,5) == "32KHz"
		then
			tmp = 3
		end
		tmp_dat[9] = Or(tmp_dat[9],tmp<<5)	
		
		if get_value(50,24) == 1
		then
			tmp_dat[9] = Or(tmp_dat[9],0x80)
		end
			
		Send_cmd(0xc7,0x3b,0x01,tmp_dat[7],tmp_dat[8],tmp_dat[9],0,0,0)
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ������")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother blue")
		end
		
		change_screen(40)
		
		
		
		return 1
	elseif control==41 and value==0
	then
		return 1
	elseif control==27 and value==1 --��������
	then
		set_text(50,29,"Setting")
		
		tmp_dat[7] = get_value(50,30)-1 --R
		tmp_dat[8] = get_value(50,31)-1 --G
		tmp_dat[9] = get_value(50,32)-1 --B
		tmp_dat[10] = get_value(50,33)-1 --W
		tmp_dat[11] = get_value(50,34)-1 --Y
		tmp_dat[12] = get_value(50,35)-1 --Z
		
		Send_cmd(0xc7,0x3b,0x03,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12])
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ���Ƶ�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother yellow")
		end
		
		change_screen(40)
		
		
		return 1
	elseif control==27 and value==0
	then
		return 1
	elseif control==37 and value==1 --PWM
	then
		set_text(50,38,"Setting")
		
		tmp_dat[7] = 0
		tmp_dat[7] = Or(tmp_dat[7],get_value(50,40))
		
		if get_value(50,39) == 1
		then
			tmp_dat[7] = Or(tmp_dat[7],0x80)
		end
		
		Send_cmd(0xc7,0x3b,0x05,tmp_dat[7],0,0,0,0,0)
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")
		end
		
		change_screen(40)
		
		
		return 1
	elseif control==37 and value==0
	then
		return 1
	end
end

function screen_51()
	screen = screen_t
	control = control_t
	value = value_t
	if control==12 and value==1
	then
		if get_text(51,14) == "8s"
		then
			set_text(51,14,"4s")
		elseif get_text(51,14) == "4s"
		then
			set_text(51,14,"2s")
		elseif get_text(51,14) == "2s"
		then
			set_text(51,14,"1s")
		elseif get_text(51,14) == "1s"
		then
			set_text(51,14,"8s")	
		end
		return 1
	elseif control==12 and value==0
	then
		return 1
	elseif control==2 and value==1
	then
		if get_text(51,9) == "51ms"
		then
			set_text(51,9,"39ms")
		elseif get_text(51,9) == "39ms"
		then
			set_text(51,9,"28ms")
		elseif get_text(51,9) == "28ms"
		then
			set_text(51,9,"16ms")
		elseif get_text(51,9) == "16ms"
		then
			set_text(51,9,"51ms")	
		end
		return 1
	elseif control==2 and value==0
	then
		return 1
	elseif control==10 and value==1
	then
		if get_text(51,15) == "51ms"
		then
			set_text(51,15,"39ms")
		elseif get_text(51,15) == "39ms"
		then
			set_text(51,15,"28ms")
		elseif get_text(51,15) == "28ms"
		then
			set_text(51,15,"16ms")
		elseif get_text(51,15) == "16ms"
		then
			set_text(51,15,"51ms")	
		end
		return 1
	elseif control==10 and value==0
	then
		return 1
	elseif control==1 and value==1
	then
		if get_text(51,5) == "1s"
		then
			set_text(51,5,"0.5s")
		elseif get_text(51,5) == "0.5s"
		then
			set_text(51,5,"0.25s")
		elseif get_text(51,5) == "0.25s"
		then
			set_text(51,5,"0.125s")
		elseif get_text(51,5) == "0.125s"
		then
			set_text(51,5,"1s")	
		end
		return 1
	elseif control==1 and value==0
	then
		return 1
	elseif control==28 and value==1
	then
		set_value(51,28,1)

		return 1
	elseif control==28 and value==0
	then
		return 1
	elseif control==6 and value==1
	then
		set_value(51,6,1)
		return 1
	elseif control==6 and value==0
	then
		return 1
	elseif control==16 and value==1
	then
		set_value(51,16,1)
		return 1
	elseif control==16 and value==0
	then
		return 1
	elseif control==17 and value==1
	then
		set_value(51,17,1)
		return 1
	elseif control==17 and value==0
	then
		return 1
	
	elseif control==27 and value==1 --��ʾ����
	then
		set_text(51,19,"Setting")
		local tmp

		tmp_dat[7] = 0 --�ϵ���ʾ״̬
		if get_value(51,18) == 0
		then
			tmp_dat[7] = Or(tmp_dat[7],0x03)
		else
			tmp_dat[7] = Or(tmp_dat[7],0x0c)
		end
		
		if get_value(51,7) == 0
		then
			tmp_dat[7] = Or(tmp_dat[7],0x30)
		else
			tmp_dat[7] = Or(tmp_dat[7],0xc0)
		end
		
		tmp_dat[8] = 0 --����Ч��ѡ��
		if get_value(51,28) == 1
		then
			tmp_dat[8] = Or(tmp_dat[8],0x01)
		end
		if get_value(51,6) == 1
		then
			tmp_dat[8] = Or(tmp_dat[8],0x02)
		end
		if get_value(51,16) == 1
		then
			tmp_dat[8] = Or(tmp_dat[8],0x04)
		end
		if get_value(51,17) == 1
		then
			tmp_dat[8] = Or(tmp_dat[8],0x08)
		end
		
		tmp_dat[9] = 0 --����ѡ��
		if get_text(51,14) == "8s" 
		then
			tmp = 0
		elseif get_text(51,14) == "4s"
		then
			tmp = 1
		elseif get_text(51,14) == "2s"
		then
			tmp = 2
		elseif get_text(51,14) == "1s"
		then
			tmp = 3
		end
		tmp_dat[9] = Or(tmp_dat[9],tmp) 
		
		if get_text(51,9) == "51ms" 
		then
			tmp = 0
		elseif get_text(51,9) == "39ms"
		then
			tmp = 1
		elseif get_text(51,9) == "28ms"
		then
			tmp = 2
		elseif get_text(51,9) == "16ms"
		then
			tmp = 3
		end
		tmp_dat[9] = Or(tmp_dat[9],tmp<<2) 
		
		if get_text(51,15) == "51ms" 
		then
			tmp = 0
		elseif get_text(51,15) == "39ms"
		then
			tmp = 1
		elseif get_text(51,15) == "28ms"
		then
			tmp = 2
		elseif get_text(51,15) == "16ms"
		then
			tmp = 3
		end
		tmp_dat[9] = Or(tmp_dat[9],tmp<<4) 
		
		if get_text(51,5) == "1s"
		then
			tmp = 0
		elseif get_text(51,5) == "0.5s"
		then
			tmp = 1
		elseif get_text(51,5) == "0.25s"
		then
			tmp = 2
		elseif get_text(51,5) == "0.125s"
		then
			tmp = 3
		
		else
			tmp = 5
		end
		tmp_dat[9] = Or(tmp_dat[9],tmp<<6) 
		
		tmp_dat[10] = get_value(51,24) --R
		tmp_dat[11] = get_value(51,25) --G
		tmp_dat[12] = get_value(51,29) --B
		tmp_dat[13] = get_value(51,30) --W
		tmp_dat[14] = get_value(51,33) --Y
		tmp_dat[15] = get_value(51,34) --Z
		
		----------------------
		--��������
		send_cmd_xb[0] = 0xc3

		send_cmd_xb[1] = 0xff --UID
		send_cmd_xb[2] = 0xff	
		send_cmd_xb[3] = 0xff	
		send_cmd_xb[4] = 0xff	
		
		send_cmd_xb[5] = 0xc7 --������
		
		send_cmd_xb[6] = 0x3b --����
		
		send_cmd_xb[7] = 0x02 --С���λ
		
		send_cmd_xb[8] = tmp_dat[7]
		send_cmd_xb[9] = tmp_dat[8]
		send_cmd_xb[10] = tmp_dat[9]
		send_cmd_xb[11] = tmp_dat[10]
		send_cmd_xb[12] = tmp_dat[11]
		send_cmd_xb[13] = tmp_dat[12]
		send_cmd_xb[14] = tmp_dat[13]
		send_cmd_xb[15] = tmp_dat[14]
		send_cmd_xb[16] = tmp_dat[15]
		send_cmd_xb[17] = 0
		
		check_sum = 0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end

		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ��ʾ�ϵ�������ɫ")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nall light power on light status")	
		end

		change_screen(40)
		
		
		return 1
	elseif control==27 and value==0
	then
		return 1
	end
end

function screen_52()
	screen = screen_t
	control = control_t
	value = value_t
	if control==2 and value==1
	then
		if get_text(52,6) == "�ر�"
		then
			set_text(52,6,"����Ӧ")
		elseif get_text(52,6) == "����Ӧ"
		then
			set_text(52,6,"�Զ�Ѱַ")
		elseif get_text(52,6) == "�Զ�Ѱַ"
		then
			set_text(52,6,"�׵�ַ�����Ա�ַ")
		elseif get_text(52,6) == "�׵�ַ�����Ա�ַ"
		then
			set_text(52,6,"�Զ���ַ")	
		elseif get_text(52,6) == "�Զ���ַ"
		then
			set_text(52,6,"�ر�")	
		end
		return 1
	elseif control==2 and value==0
	then
		return 1
	elseif control==7 and value==1
	then
		local zbz_cout
		
		if get_text(52,16) == "���޴�"
		then
			set_text(52,16,"1")
		elseif get_value(52,16) < 15
		then
			zbz_cout = get_value(52,16)
			zbz_cout = zbz_cout + 1
			set_value(52,16,zbz_cout)
		elseif get_value(52,16) == 15
		then
			set_text(52,16,"���޴�")
		end
		return 1
	elseif control==7 and value==0
	then
		return 1
	elseif control==1 and value==1
	then
		if get_text(52,5) == "�ر�"
		then
			set_text(52,5,"����1")
		elseif get_text(52,5) == "����1"
		then
			set_text(52,5,"����2")
		elseif get_text(52,5) == "����2"
		then
			set_text(52,5,"�ر�")	
		end
		return 1
	elseif control==1 and value==0
	then
		return 1
	
	elseif control==13 and value==1 --�Զ�д��
	then
		set_text(52,15,"Setting")
		
		if get_text(52,6) == "�ر�"
		then
			tmp_dat[7] = 0x00
		elseif get_text(52,6) == "����Ӧ"
		then
			tmp_dat[7] = 0xa5
		elseif get_text(52,6) == "�Զ�Ѱַ"
		then
			tmp_dat[7] = 0xf0
		elseif get_text(52,6) == "�׵�ַ�����Ա�ַ"
		then
			tmp_dat[7] = 0xc3
		elseif get_text(52,6) == "�Զ���ַ"
		then
			tmp_dat[7] = 0x0f
		end
		
		tmp_dat[8] = 0x00
		if get_text(52,16) =="���޴�"
		then
			tmp_dat[8] = Or(tmp_dat[8],0x20) 
		else
			tmp_dat[8] = Or(tmp_dat[8],get_value(52,16)) 
		end
		
		if get_text(52,5) == "�ر�"
		then
			tmp_dat[8] = tmp_dat[8]
		elseif get_text(52,5) == "����1"
		then
			tmp_dat[8] = Or(tmp_dat[8],0x80)
		elseif get_text(52,5) == "����2"
		then
			tmp_dat[8] = Or(tmp_dat[8],0xc0)
		end
		
		Send_cmd(0xc7,0x3b,0x04,tmp_dat[7],tmp_dat[8],0,0,0,0)
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ���ϵ�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother violet")
		end
		
		change_screen(40)
		
		return 1
	elseif control==13 and value==0
	then
		return 1
	end	
end

function screen_53()
	screen = screen_t
	control = control_t
	value = value_t
	
	if 		get_text(53,47) == "UCS9812"		then 	xh=0
	elseif  get_text(53,47) == "UCS8903/4" 		then	xh=1
	elseif  get_text(53,47) == "UCS2903/4/12"	then 	xh=2
	elseif  get_text(53,47) == "UCS7604"		then 	xh=3
	elseif  get_text(53,47) == "UCS7804" 		then	xh=3	end
	
	if control==41 and value==1
	then
		set_text(69,8,get_text(53,5))		
		change_screen(69)
		
		DMX_add_param = 0x33	
		return 1
	elseif control==41 and value==0
	then
		return 1

	elseif control==43 and value==1
	then
		set_text(54,5,get_text(53,5))
		
		change_screen(54)
		return 1
	elseif control==43 and value==0
	then
		return 1
	--ת���ͺ�����
	elseif control==48 and value==1
	then
		if get_text(53,47) == "UCS9812"
		then
			set_text(53,47,"UCS8903/4")--����оƬ�ͺ�
			xh=1
			if get_language() == 0--����
			then
				set_text(53,6,"������")--�ֶ�
				set_text(53,45,"������")--�˿�ˢ����
				set_text(53,16,"������")--�Ҷ�ƽ��
				set_text(53,19,"�����ȼ�  ������ :")
				
			elseif get_language() == 1--Ӣ��
			then	
				set_text(53,6,"  invalid")--�ֶ�
				set_text(53,45,"  invalid")--�˿�ˢ����
				set_text(53,16,"  invalid")--�Ҷ�ƽ��
				set_text(53,19,"Current rating   invalid :")
			end
			
			
			set_visiable(53,2,0)--�ֶΰ�ť
			set_visiable(53,40,0)
			set_visiable(53,12,0)
			set_visiable(53,26,0)--����
		
			set_text(53,52,"0")
			set_text(53,53,"0")
			set_text(53,54,"0")
			set_text(53,55,"0")
			set_text(53,56,"0")
			set_text(53,57,"0")
			set_text(53,58,"0")

		elseif get_text(53,47) == "UCS8903/4"
		then
			set_text(53,47,"UCS2903/4/12")--����оƬ�ͺ�
			xh=2
			if get_language() == 0--����
			then
				set_text(53,6,"������")--�ֶ�
				set_text(53,45,"������")--�˿�ˢ����
				set_text(53,16,"������")--�Ҷ�ƽ��
				set_text(53,19,"�����ȼ�  ������ :")
				
			elseif get_language() == 1--Ӣ��
			then	
				set_text(53,6,"  invalid")--�ֶ�
				set_text(53,45,"  invalid")--�˿�ˢ����
				set_text(53,16,"  invalid")--�Ҷ�ƽ��
				set_text(53,19,"Current rating   invalid :")
			end
			
			set_visiable(53,2,0)--�ֶΰ�ť
			set_visiable(53,40,0)--�˿�ˢ����
			set_visiable(53,12,0)--�Ҷ�ƽ��
			set_visiable(53,26,0)--����
	
			set_text(53,52,"0")
			set_text(53,53,"0")
			set_text(53,54,"0")
			set_text(53,55,"0")
			set_text(53,56,"0")
			set_text(53,57,"0")
			set_text(53,58,"0")
			
		elseif  get_text(53,47) == "UCS2903/4/12"
		then
			set_text(53,47,"UCS7604")--����оƬ�ͺ�
			xh=3
			if get_language() == 0--����
			then
				set_value(53,6,3)----�ֶοؼ���ֵ
				set_text(53,45,"������")--�˿�ˢ����
				set_text(53,16,"������")--�Ҷ�ƽ��
				set_text(53,19,"�����ȼ�  1~16 :")
				
			elseif get_language() == 1--Ӣ��
			then	
				set_value(53,6,3)----�ֶοؼ���ֵ
				set_text(53,45,"  invalid")--�˿�ˢ����
				set_text(53,16,"  invalid")--�Ҷ�ƽ��
				set_text(53,19,"Current rating   1~16 :")
			end
					
			set_visiable(53,2,1)--�ֶΰ�ť	
			set_visiable(53,40,0)--�˿�ˢ����			
			set_visiable(53,12,0)--�Ҷ�ƽ��			
			set_visiable(53,26,1)--����
			
			
			set_text(53,52,"16")
			set_text(53,53,"16")
			set_text(53,54,"16")
			set_text(53,55,"16")
			set_text(53,56,"16")
			set_text(53,57,"16")
			set_text(53,58,"16")
			
		elseif  get_text(53,47) == "UCS7604"
		then
			set_text(53,47,"UCS7804")--����оƬ�ͺ�
			xh=3
			if get_language() == 0--����
			then
				set_value(53,6,3)----�ֶοؼ���ֵ
				set_text(53,45,"16KHZ")--�˿�ˢ����
				set_text(53,16,"�ر�")
				set_text(53,19,"�����ȼ�  1~64 :")
				
			elseif get_language() == 1--Ӣ��
			then	
				set_value(53,6,3)----�ֶοؼ���ֵ
				set_text(53,45,"16KHZ")--�˿�ˢ����
				set_text(53,16,"Close")--�Ҷ�ƽ��
				set_text(53,19,"Current rating   1~64 :")
			end
			
			set_visiable(53,2,1)--�ֶΰ�ť	
			set_visiable(53,40,1)--�˿�ˢ����	
			set_visiable(53,12,1)--�Ҷ�ƽ��
			set_visiable(53,26,1)--����
			
			set_text(53,52,"64")
			set_text(53,53,"64")
			set_text(53,54,"64")
			set_text(53,55,"64")
			set_text(53,56,"64")
			set_text(53,57,"64")
			set_text(53,58,"64")
		
		elseif  get_text(53,47) == "UCS7804"
		then
			set_text(53,47,"UCS9812")--����оƬ�ͺ�
			xh=0
			if get_language() == 0--����
			then
				set_text(53,6,"������")--�ֶ�
				set_text(53,45,"������")--�˿�ˢ����
				set_text(53,16,"������")--�Ҷ�ƽ��
				set_text(53,19,"�����ȼ�  1~16 :")
				
			elseif get_language() == 1--Ӣ��
			then	
				set_text(53,6,"  invalid")--�ֶ�
				set_text(53,45,"  invalid")--�˿�ˢ����
				set_text(53,16,"  invalid")--�Ҷ�ƽ��
				set_text(53,19,"Current rating   1~16 :")
			end
			
			set_visiable(53,2,0)--�ֶΰ�ť
			set_visiable(53,40,0)--�˿�ˢ����
			set_visiable(53,12,0)--�Ҷ�ƽ��
			set_visiable(53,26,1)--����
			
			set_text(53,52,"16")
			set_text(53,53,"16")
			set_text(53,54,"16")
			set_text(53,55,"16")
			set_text(53,56,"16")
			set_text(53,57,"16")
			set_text(53,58,"16")
			
		end
		return 1
	elseif control==48 and value==0
	then
		return 1
		--�ֶ����� 
	elseif control==2 and value==1
	then
		if get_value(53,6) == 1
		then
			set_value(53,6,2)--���ÿؼ���ֵ	
		elseif get_value(53,6) == 2
		then
			set_value(53,6,3)--���ÿؼ���ֵ
		elseif get_value(53,6) == 3
		then
			set_value(53,6,4)--���ÿؼ���ֵ
		elseif get_value(53,6) == 4
		then
			set_value(53,6,1)--���ÿؼ���ֵ	
		end
		return 1
	elseif control==2 and value==0
	then
		return 1
	
	--�˿�ˢ��������	
	elseif control==40 and value==1
	then
		if get_text(53,45) == "16KHZ"
		then
			set_text(53,45,"250HZ")--���ÿؼ���ֵ	
		elseif get_text(53,45) == "250HZ"
		then
			set_text(53,45,"16KHZ")--���ÿؼ���ֵ
		end
		return 1
	elseif control==40 and value==0
	then
		return 1
		
	--�Ҷ�ƽ������
	elseif control==12 and value==1
	then
		if get_language() == 0--����
		then
			set_text(53,16,"�ر�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(53,16,"Close")
		end

		return 1
	elseif control==12 and value==0
	then
		if get_language() == 0--����
		then
			set_text(53,16,"����")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(53,16,"Open")
		end
		return 1	
	
	--����ת���ͺ� �ֶΡ��˿�ˢ�¡��Ҷ�ƽ��
	elseif control==13 and value==1
	then
		set_text(53,8,"Setting")

		local zd =0	
		zd = get_value(53,6)--�ֶ�ѡ��
		if (zd <1) or (zd >4)
		then
			zd = 3
		end

		local sx =0	
		if get_text(53,45) == "250HZ"
		then
			sx=1
		else
			sx=0
		end
		
		local hd =0	
		hd = get_value(53,12)--���� �Ҷ�ƽ��

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3d--ָʾUCS512-KHд����
		
		send_cmd_xb[7] = 0x01--дת��Э��ı��
		
		ss = get_text(53,5)
		if ss == "UCS512-KH"
		then
			send_cmd_xb[8] = 0x33
		elseif ss == "UCS512-KH-S"
		then
			send_cmd_xb[8] = 0x55
		end
		
		send_cmd_xb[9] = xh--ת���ͺ�
		send_cmd_xb[10] = zd-1--�ֶ�
		send_cmd_xb[11] = sx--ˢ���� 
		send_cmd_xb[12] = hd--�Ҷ�ƽ��
		send_cmd_xb[13] = 0
		send_cmd_xb[14] = 0
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	
		----
		DMX_Status_page = 0x55
			
		----
		return 1
	elseif control==13 and value==0
	then
		return 1
	
	--��ɫ����ѡ�� 
	elseif control==25 and value==1
	then
		local num = get_value(53,29)
		
		num = num + 1
		
		if num > 7
		then
			num = 1
		end
		
		set_value(53,29,num)--���ÿؼ���ֵ	
		set_value(54,19,num)--���ÿؼ���ֵ	
		
		set_text(54,10,"R")
		set_text(54,11,"G")
		set_text(54,12,"B")
		set_text(54,13,"W1")
		set_text(54,14,"W2")
		set_text(54,15,"W3")
		set_text(54,16,"W4")
		
		for i = 0,6 do
			set_value(54,i+72,i)
			if i < num
			then
				set_visiable(53,i+52,1)
				set_visiable(54,i+10,1)
				set_visiable(54,i+36,1)
				set_visiable(54,i+53,1)
				set_visiable(54,i+61,1)
			else
				set_visiable(53,i+52,0)
				set_visiable(54,i+10,0)
				set_visiable(54,i+36,0)
				set_visiable(54,i+53,0)
				set_visiable(54,i+61,0)
			end
		end
		
		return 1
	elseif control==25 and value==0
	then
		return 1
	
	--������ɫ���� 
	elseif control==18 and value==1
	then
		local ee = 0x33
		
		set_text(53,24,"Setting")
		ss = get_text(53,5)
		if ss == "UCS512-KH"
		then
			ee = 0x33
		elseif ss == "UCS512-KH-S"
		then
			ee = 0x55
		end
		
		local num = get_value(53,29)
		if num > 8 or num < 1
		then
			num = 3
		end
		
		Send_cmd(0xc7,0x3d,0x09,ee,num-1,0,0,0,0)
		
		DMX_Status_page = 0x55
		
		return 1
	elseif control==18 and value==0
	then
		return 1
	
	elseif control==38 and value==1
	then
		ztd_flag = 0xbb
		
		set_text(39,2,"")--��������
		set_text(39,8,"")

		if secret_2 == 0x00--��һ�ε��������ʱ
		then
			change_screen(39)
		else
			if get_language() == 0--����
			then
				set_text(36,2,"��ȷ��Ҫ���øò�����")	
			elseif get_language() == 1--Ӣ��
			then
				set_text(36,2,"Are you sure set param��")			
			end		
			
			change_screen(36)
		end
		return 1	
	elseif control==38 and value==0
	then
		return 1
	
	--�Զ�д������
	elseif control==7 and value==1
	then
		if get_language() == 0--����
		then
			set_text(53,28,"�ر�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(53,28," Close")
		end
		return 1
	elseif control==7 and value==0
	then
		if get_language() == 0--����
		then
			set_text(53,28,"����")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(53,28," Open")
		end
		return 1
	
	--�����Զ�д��
	elseif control==9 and value==1
	then
		set_text(53,21,"Setting")
		
		local dd =0	
		dd = get_value(53,7)--���� �Զ�д��				

		local ee = 0x33
		ss = get_text(53,5)
		if ss == "UCS512-KH"
		then
			ee = 0x33
		elseif ss == "UCS512-KH-S"
		then
			ee = 0x55
		end
		
		Send_cmd(0xc7,0x3d,0x03,ee,dd,0,0,0,0)	

		----
		DMX_Status_page = 0x55
		
		return 1
	elseif control==9 and value==0
	then
		return 1
	
	--���ö�ת������
	elseif control==31 and value==1
	then
		set_text(53,22,"Setting")
		
		local dd=3
		dd=get_value(53,36)
		
		if (dd > 32) or  (dd < 1)
		then
			dd = 3
		end
		
		local ee =0x33
		ss = get_text(53,5)
		if ss == "UCS512-KH"
		then
			ee = 0x33
		elseif ss == "UCS512-KH-S"
		then
			ee = 0x55
		end
		
		Send_cmd(0xc7,0x3d,0x04,ee,dd-1,0,0,0,0)
		
		DMX_Status_page = 0x55
		
		return 1
	elseif control==31 and value==0
	then
		return 1
	--���õ����ȼ�
	elseif control==26 and value==1
	then
		
		set_text(53,27,"Setting")
	
		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3d--ָʾUCS512-KHд����
		
		send_cmd_xb[7] = 0x07--д �����ȼ� �ı��
		
		ss = get_text(53,5)
		if ss == "UCS512-KH"
		then
			send_cmd_xb[8] = 0x33
		elseif ss == "UCS512-KH-S"
		then
			send_cmd_xb[8] = 0x55
		end
		
		send_cmd_xb[9]  = get_value(53,52) - 1 --R
		send_cmd_xb[10] = get_value(53,53) - 1 --G
		send_cmd_xb[11] = get_value(53,54) - 1 --B
		send_cmd_xb[12] = get_value(53,55) - 1 --W1
		send_cmd_xb[13] = get_value(53,56) - 1 --W2
		send_cmd_xb[14] = get_value(53,57) - 1 --W3
		send_cmd_xb[15] = get_value(53,58) - 1 --W4
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	
		----
		DMX_Status_page = 0x55
		return 1
	elseif control==26 and value==0
	then
		return 1
	end	
	--����ֵУ��
	for i=1,7 do
		if (xh==00 or xh==03) and get_value(53,51+i)>16 and get_text(53,47) ~= "UCS7804"
		then
			set_value(53,51+i,16)
		end
		if xh==01 or xh==02
		then
			set_value(53,51+i,0)
		end
	end
end

function screen_54()
	screen = screen_t
	control = control_t
	value = value_t
	if control==8 and value==1
	then
		if get_language() == 0--����
		then
			set_text(54,28,"�Զ���Ҷ�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(54,28,"Custom gray scale")
		end
		return 1
	elseif control==8 and value==0
	then
		if get_language() == 0--����
		then
			set_text(54,28,"��ַ�߼��ģʽ")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(54,28,"Address line detection")
		end
		return 1
	
	elseif control==7 and value==1
	then
		if get_language() == 0--����
		then
			set_text(54,21,"�ָ��ϵ�����״̬")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(54,21,"Restore light status")
		end
		return 1
	elseif control==7 and value==0
	then
		if get_language() == 0--����
		then
			set_text(54,21,"�������һ֡")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(54,21,"Save last frame")
		end
		return 1
	--��ɫ����ѡ�� 
	elseif control==18 and value==1
	then
		local num = get_value(54,19)
		
		num = num + 1
		
		if num > 7
		then
			num = 1
		end
		
		set_value(54,19,num)--���ÿؼ���ֵ	
		set_value(53,29,num)--���ÿؼ���ֵ	
		
		set_text(54,10,"R")
		set_text(54,11,"G")
		set_text(54,12,"B")
		set_text(54,13,"W1")
		set_text(54,14,"W2")
		set_text(54,15,"W3")
		set_text(54,16,"W4")
		
		for i = 0,6 do
			set_value(54,i+72,i)
			if i < num
			then
				set_visiable(53,i+52,1)
				set_visiable(54,i+10,1)
				set_visiable(54,i+36,1)
				set_visiable(54,i+53,1)
				set_visiable(54,i+61,1)
			else
				set_visiable(53,i+52,0)
				set_visiable(54,i+10,0)
				set_visiable(54,i+36,0)
				set_visiable(54,i+53,0)
				set_visiable(54,i+61,0)
			end
		end
		
		return 1
	elseif control==18 and value==0
	then
		return 1
	
	--������ɫ���� 
	elseif control==20 and value==1
	then
		local ee = 0x33
		
		set_text(54,6,"Setting")
		ss = get_text(54,5)
		if ss == "UCS512-KH"
		then
			ee = 0x33
		elseif ss == "UCS512-KH-S"
		then
			ee = 0x55
		end
		
		local num = get_value(54,19)
		if num > 8 or num < 1
		then
			num = 3
		end
	
		Send_cmd(0xc7,0x3d,0x09,ee,num-1,0,0,0,0)
		
		DMX_Status_page = 0x55
		
		return 1
	elseif control==20 and value==0
	then
		return 1
	
	--�����ϵ�����
	elseif control==31 and value==1
	then
		
		set_text(54,32,"Setting")
	
		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3d--ָʾUCS512-KHд����
		
		send_cmd_xb[7] = 0x05--д �ϵ�Ҷ� �ı��
		
		ss = get_text(53,5)
		if ss == "UCS512-KH"
		then
			send_cmd_xb[8] = 0x33
		elseif ss == "UCS512-KH-S"
		then
			send_cmd_xb[8] = 0x55
		end
		
		
		if get_value(54,8)==0	then send_cmd_xb[9]=0x00
		elseif  get_value(54,8)==1 then send_cmd_xb[9]=0x01	end
		
		if get_value(54,7)==0	then send_cmd_xb[10]=0x00
		elseif  get_value(54,7)==1 then send_cmd_xb[10]=0x01 end
		
		
		send_cmd_xb[11] = get_value(54,61)--R
		send_cmd_xb[12] = get_value(54,62)--G
		send_cmd_xb[13] = get_value(54,63)--B
		send_cmd_xb[14] = get_value(54,64)--W1
		send_cmd_xb[15] = get_value(54,65)--W2
		send_cmd_xb[16] = get_value(54,66)--W3
		send_cmd_xb[17] = get_value(54,67)--W4
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		----
		DMX_Status_page = 0x55
		return 1
	elseif control==31 and value==0
	then
		return 1
	
	--RGBWYA��ͨ��˳��
	elseif (control>=36 and control<=42) and value==1
	then
		
		local num = get_value(54,control + 36)
		
		num = num + 1
		
		if num > 6
		then
			num = 0
		end
		
		set_value(54,control + 36,num)
		
		if get_value(54,control + 36) == 0
		then
			set_text(54,control - 26,"R" )
		elseif get_value(54,control + 36) == 1
		then
			set_text(54,control - 26,"G" )
		elseif get_value(54,control + 36) == 2
		then
			set_text(54,control - 26,"B" )
		elseif get_value(54,control + 36) == 3
		then
			set_text(54,control - 26,"W1" )
		elseif get_value(54,control + 36) == 4
		then
			set_text(54,control - 26,"W2" )
		elseif get_value(54,control + 36) == 5
		then
			set_text(54,control - 26,"W3" )
		elseif get_value(54,control + 36) == 6
		then
			set_text(54,control - 26,"W4" )
		end
		
		return 1
	elseif (control>=36 and control<=42) and value==0
	then
		return 1
	
	--����ͨ��ת��˳��
	elseif control==2 and value==1
	then
		set_text(54,3,"Setting")
	
		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3d--ָʾUCS512-KHд����
		
		send_cmd_xb[7] = 0x06--д ͨ��ת��˳�� �ı��
		
		ss = get_text(54,5)
		if ss == "UCS512-KL"
		then
			send_cmd_xb[8] = 0x33
		elseif ss == "UCS512-KL-S"
		then
			send_cmd_xb[8] = 0x55
		end
		
		send_cmd_xb[9]  = get_value(54,72)--RR
		send_cmd_xb[10] = get_value(54,73)--GG
		send_cmd_xb[11] = get_value(54,74)--BB
		send_cmd_xb[12] = get_value(54,75)--WW
		send_cmd_xb[13] = get_value(54,76)--YY
		send_cmd_xb[14] = get_value(54,77)--AA
		send_cmd_xb[15] = get_value(54,78)--AA
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	
		
		DMX_Status_page = 0x55
		
		return 1
	elseif control==2 and value==0
	then
		return 1
	
	--����ͨ��ת������
	elseif control==34 and value==1
	then
		
		set_text(54,35,"Setting")
	
		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3d--ָʾUCS512-KHд����
		
		send_cmd_xb[7] = 0x08--д ͨ��ת������ �ı��
		
		ss = get_text(53,5)
		if ss == "UCS512-KL"
		then
			send_cmd_xb[8] = 0x33
		elseif ss == "UCS512-KL-S"
		then
			send_cmd_xb[8] = 0x55
		end
		
		send_cmd_xb[9]  = get_value(54,53)-1--R
		send_cmd_xb[10] = get_value(54,54)-1--G
		send_cmd_xb[11] = get_value(54,55)-1--B
		send_cmd_xb[12] = get_value(54,56)-1--W1
		send_cmd_xb[13] = get_value(54,57)-1--W2
		send_cmd_xb[14] = get_value(54,58)-1--W3
		send_cmd_xb[15] = get_value(54,59)-1--W4
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	
		
		DMX_Status_page = 0x55
		
		return 1
	elseif control==34 and value==0
	then
		return 1
	end	
end

function screen_55()
	screen = screen_t
	control = control_t
	value = value_t

	if 		get_text(55,47) == "UCS9812"		then 	xh=0
	elseif  get_text(55,47) == "UCS8903/4" 		then	xh=1
	elseif  get_text(55,47) == "UCS2903/4/12"	then 	xh=2
	elseif  get_text(55,47) == "UCS7604"		then 	xh=3
	elseif  get_text(55,47) == "UCS7804" 		then	xh=3	end
	
	if control==41 and value==1
	then
		set_text(69,8,get_text(55,5))		
		change_screen(69)
		
		DMX_add_param = 0x33	
		return 1
	elseif control==41 and value==0
	then
		return 1

	elseif control==43 and value==1
	then
		set_text(56,5,get_text(55,5))
		
		change_screen(56)
		return 1
	elseif control==43 and value==0
	then
		return 1
	
	--ת���ͺ�����
	elseif control==48 and value==1
	then
		if get_text(55,47) == "UCS9812"
		then
			set_text(55,47,"UCS8903/4")--����оƬ�ͺ�
			xh=1
			if get_language() == 0--����
			then
				set_text(55,6,"������")--�ֶ�
				set_text(55,45,"������")--�˿�ˢ����
				set_text(55,16,"������")--�Ҷ�ƽ��
				set_text(55,19,"�����ȼ�  ������ :")
				
			elseif get_language() == 1--Ӣ��
			then	
				set_text(55,6,"  invalid")--�ֶ�
				set_text(55,45,"  invalid")--�˿�ˢ����
				set_text(55,16,"  invalid")--�Ҷ�ƽ��
				set_text(55,19,"Current rating   invalid :")
			end
			
			
			set_visiable(55,2,0)--�ֶΰ�ť
			set_visiable(55,40,0)
			set_visiable(55,12,0)
			set_visiable(55,26,0)--����
		
			set_text(55,52,"0")
			set_text(55,53,"0")
			set_text(55,54,"0")
			set_text(55,55,"0")
			set_text(55,56,"0")
			set_text(55,57,"0")
			set_text(55,58,"0")

		elseif get_text(55,47) == "UCS8903/4"
		then
			set_text(55,47,"UCS2903/4/12")--����оƬ�ͺ�
			xh=2
			if get_language() == 0--����
			then
				set_text(55,6,"������")--�ֶ�
				set_text(55,45,"������")--�˿�ˢ����
				set_text(55,16,"������")--�Ҷ�ƽ��
				set_text(55,19,"�����ȼ�  ������ :")
				
			elseif get_language() == 1--Ӣ��
			then	
				set_text(55,6,"  invalid")--�ֶ�
				set_text(55,45,"  invalid")--�˿�ˢ����
				set_text(55,16,"  invalid")--�Ҷ�ƽ��
				set_text(55,19,"Current rating   invalid :")
			end
			
			set_visiable(55,2,0)--�ֶΰ�ť
			set_visiable(55,40,0)--�˿�ˢ����
			set_visiable(55,12,0)--�Ҷ�ƽ��
			set_visiable(55,26,0)--����
	
			set_text(55,52,"0")
			set_text(55,53,"0")
			set_text(55,54,"0")
			set_text(55,55,"0")
			set_text(55,56,"0")
			set_text(55,57,"0")
			set_text(55,58,"0")
			
		elseif  get_text(55,47) == "UCS2903/4/12"
		then
			set_text(55,47,"UCS7604")--����оƬ�ͺ�
			xh=3
			if get_language() == 0--����
			then
				set_value(55,6,3)----�ֶοؼ���ֵ
				set_text(55,45,"������")--�˿�ˢ����
				set_text(55,16,"������")--�Ҷ�ƽ��
				set_text(55,19,"�����ȼ�  1~16 :")
				
			elseif get_language() == 1--Ӣ��
			then	
				set_value(55,6,3)----�ֶοؼ���ֵ
				set_text(55,45,"  invalid")--�˿�ˢ����
				set_text(55,16,"  invalid")--�Ҷ�ƽ��
				set_text(55,19,"Current rating   1~16 :")
			end
					
			set_visiable(55,2,1)--�ֶΰ�ť	
			set_visiable(55,40,0)--�˿�ˢ����			
			set_visiable(55,12,0)--�Ҷ�ƽ��			
			set_visiable(55,26,1)--����
			
			
			set_text(55,52,"16")
			set_text(55,53,"16")
			set_text(55,54,"16")
			set_text(55,55,"16")
			set_text(55,56,"16")
			set_text(55,57,"16")
			set_text(55,58,"16")
			
		elseif  get_text(55,47) == "UCS7604"
		then
			set_text(55,47,"UCS7804")--����оƬ�ͺ�
			xh=3
			if get_language() == 0--����
			then
				set_value(55,6,3)----�ֶοؼ���ֵ
				set_text(55,45,"16KHZ")--�˿�ˢ����
				set_text(55,16,"�ر�")
				set_text(55,19,"�����ȼ�  1~64 :")
				
			elseif get_language() == 1--Ӣ��
			then	
				set_value(55,6,3)----�ֶοؼ���ֵ
				set_text(55,45,"16KHZ")--�˿�ˢ����
				set_text(55,16,"Close")--�Ҷ�ƽ��
				set_text(55,19,"Current rating   1~64 :")
			end
			
			set_visiable(55,2,1)--�ֶΰ�ť	
			set_visiable(55,40,1)--�˿�ˢ����	
			set_visiable(55,12,1)--�Ҷ�ƽ��
			set_visiable(55,26,1)--����
			
			set_text(55,52,"64")
			set_text(55,53,"64")
			set_text(55,54,"64")
			set_text(55,55,"64")
			set_text(55,56,"64")
			set_text(55,57,"64")
			set_text(55,58,"64")
		
		elseif  get_text(55,47) == "UCS7804"
		then
			set_text(55,47,"UCS9812")--����оƬ�ͺ�
			xh=0
			if get_language() == 0--����
			then
				set_text(55,6,"������")--�ֶ�
				set_text(55,45,"������")--�˿�ˢ����
				set_text(55,16,"������")--�Ҷ�ƽ��
				set_text(55,19,"�����ȼ�  1~16 :")
				
			elseif get_language() == 1--Ӣ��
			then	
				set_text(55,6,"  invalid")--�ֶ�
				set_text(55,45,"  invalid")--�˿�ˢ����
				set_text(55,16,"  invalid")--�Ҷ�ƽ��
				set_text(55,19,"Current rating   1~16 :")
			end
			
			set_visiable(55,2,0)--�ֶΰ�ť
			set_visiable(55,40,0)--�˿�ˢ����
			set_visiable(55,12,0)--�Ҷ�ƽ��
			set_visiable(55,26,1)--����
			
			set_text(55,52,"16")
			set_text(55,53,"16")
			set_text(55,54,"16")
			set_text(55,55,"16")
			set_text(55,56,"16")
			set_text(55,57,"16")
			set_text(55,58,"16")
			
		end
		return 1
	elseif control==48 and value==0
	then
		return 1
	--�ֶ����� 
	elseif control==2 and value==1
	then
		if get_value(55,6) == 1
		then
			set_value(55,6,2)--���ÿؼ���ֵ	
		elseif get_value(55,6) == 2
		then
			set_value(55,6,3)--���ÿؼ���ֵ
		elseif get_value(55,6) == 3
		then
			set_value(55,6,4)--���ÿؼ���ֵ
		elseif get_value(55,6) == 4
		then
			set_value(55,6,1)--���ÿؼ���ֵ	
		end
		return 1
	elseif control==2 and value==0
	then
		return 1
	
	--�˿�ˢ��������	
	elseif control==40 and value==1
	then
		if get_text(55,45) == "16KHZ"
		then
			set_text(55,45,"250HZ")--���ÿؼ���ֵ	
		elseif get_text(55,45) == "250HZ"
		then
			set_text(55,45,"16KHZ")--���ÿؼ���ֵ
		end
		return 1
	elseif control==40 and value==0
	then
		return 1	
		
	--�Ҷ�ƽ������
	elseif control==12 and value==1
	then
		if get_language() == 0--����
		then
			set_text(55,16,"�ر�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(55,16,"Close")
		end
		return 1
	elseif control==12 and value==0
	then
		if get_language() == 0--����
		then
			set_text(55,16,"����")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(55,16,"Open")
		end
		return 1
	
	--����ת���ͺ� �ֶΡ��˿�ˢ�¡��Ҷ�ƽ��
	elseif control==13 and value==1
	then
		set_text(55,8,"Setting")
		
		local zd =0	
		zd = get_value(55,6)--�ֶ�ѡ��
		if (zd <1) or (zd >4)
		then
			zd = 3
		end

		local sx =0	
		if get_text(55,45) == "250HZ"
		then
			sx=1
		else
			sx=0
		end
		
		local hd =0	
		hd = get_value(55,12)--���� �Ҷ�ƽ��

		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3d--ָʾUCS512-KHд����
		
		send_cmd_xb[7] = 0x11--дת��Э��ı��
		
		ss = get_text(55,5)
		if ss == "UCS512-KL"
		then
			send_cmd_xb[8] = 0x33
		elseif ss == "UCS512-KL-S"
		then
			send_cmd_xb[8] = 0x55
		end
		
		send_cmd_xb[9] = xh--ת���ͺ�
		send_cmd_xb[10] = zd-1--�ֶ�
		send_cmd_xb[11] = sx--ˢ���� 
		send_cmd_xb[12] = hd--�Ҷ�ƽ��
		send_cmd_xb[13] = 0
		send_cmd_xb[14] = 0
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		DMX_Status_page = 0x55
			
		----
		return 1
	elseif control==13 and value==0
	then
		return 1

	--��ɫ����ѡ�� 
	elseif control==25 and value==1
	then
		local num = get_value(55,29)
		
		num = num + 1
		
		if num > 7
		then
			num = 1
		end
		
		set_value(56,19,num)--���ÿؼ���ֵ	
		set_value(55,29,num)--���ÿؼ���ֵ	
		
		for i = 1,7 do
		
			if i <= num
			then
				set_visiable(55,51+i,1)
				set_visiable(56,60+i,1)
			else
				set_visiable(55,51+i,0)
				set_visiable(56,60+i,0)
			end
		end
		
		return 1
	elseif control==25 and value==0
	then
		return 1

	--������ɫ���� 
	elseif control==18 and value==1
	then
		local ee = 0x33
		
		set_text(55,24,"Setting")
		
		ss = get_text(55,5)
		if ss == "UCS512-KL"
		then
			ee = 0x33
		elseif ss == "UCS512-KL-S"
		then
			ee = 0x55
		end
		
		local num = get_value(55,29)
		if num > 8 or num < 1
		then
			num = 3
		end
	
		Send_cmd(0xc7,0x3d,0x19,ee,num-1,0,0,0,0)
		
		DMX_Status_page = 0x55
		
		return 1
	elseif control==18 and value==0
	then
		return 1
	
	--������ͨ����	
	elseif control==38 and value==1
	then
		ztd_flag = 0xcc
		
		set_text(39,2,"")--��������
		set_text(39,8,"")

		if secret_2 == 0x00--��һ�ε��������ʱ
		then
			change_screen(39)
		else
			if get_language() == 0--����
			then
				set_text(36,2,"��ȷ��Ҫ���øò�����")	
				set_text(36,7,"д�ɹ����׵����Ƶƣ��������̵�")
			elseif get_language() == 1--Ӣ��
			then
				set_text(36,2,"Are you sure set param��")			
				set_text(36,7,"Write ok,first yellow,other green")
			end		
			
			change_screen(36)
		end
		return 1	
	elseif control==38 and value==0
	then
		return 1
	
	--�Զ�д������
	elseif control==7 and value==1
	then
		if get_language() == 0--����
		then
			set_text(55,28,"�ر�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(55,28," Close")
		end
		return 1
	elseif control==7 and value==0
	then
		if get_language() == 0--����
		then
			set_text(55,28,"����")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(55,28," Open")
		end
		return 1
	
	--�����Զ�д��
	elseif control==9 and value==1
	then
		set_text(55,21,"Setting")
		
		local dd =0	
		dd = get_value(55,7)--���� �Զ�д��				

		local ee = 0x33
		ss = get_text(55,5)
		if ss == "UCS512-KL"
		then
			ee = 0x33
		elseif ss == "UCS512-KL-S"
		then
			ee = 0x55
		end
		
		Send_cmd(0xc7,0x3d,0x13,ee,dd,0,0,0,0)	

		----
		DMX_Status_page = 0x55
			
		return 1
	elseif control==9 and value==0
	then
		return 1	
	--���õ����ȼ�
	elseif control==26 and value==1
	then
		
		set_text(55,27,"Setting")
	
		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3d--ָʾUCS512-KHд����
		
		send_cmd_xb[7] = 0x17--д �����ȼ� �ı��
		
		ss = get_text(55,5)
		if ss == "UCS512-KL"
		then
			send_cmd_xb[8] = 0x33
		elseif ss == "UCS512-KL-S"
		then
			send_cmd_xb[8] = 0x55
		end
		
		send_cmd_xb[9]  = get_value(55,52) - 1 --R
		send_cmd_xb[10] = get_value(55,55) - 1 --G
		send_cmd_xb[11] = get_value(55,54) - 1 --B
		send_cmd_xb[12] = get_value(55,55) - 1 --W1
		send_cmd_xb[13] = get_value(55,56) - 1 --W2
		send_cmd_xb[14] = get_value(55,57) - 1 --W3
		send_cmd_xb[15] = get_value(55,58) - 1 --W4
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	
		----
		DMX_Status_page = 0x55
		return 1
	elseif control==26 and value==0
	then
		return 1
	end	
	
	--����ֵУ��
	for i=1,7 do
		if (xh==00 or xh==03) and get_value(55,51+i)>16 and get_text(55,47) ~= "UCS7804"
		then
			set_value(55,51+i,16)
		end
		if xh==01 or xh==02
		then
			set_value(55,51+i,0)
		end
	end
	
end

function screen_56()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==8 and value==1
	then
		if get_language() == 0--����
		then
			set_text(56,28,"�Զ���Ҷ�")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(56,28,"Custom gray scale")
		end
		return 1
	elseif control==8 and value==0
	then
		if get_language() == 0--����
		then
			set_text(56,28,"��ַ�߼��ģʽ")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(56,28,"Address line detection")
		end
		return 1
	
	elseif control==7 and value==1
	then
		if get_language() == 0--����
		then
			set_text(56,21,"�ָ��ϵ�����״̬")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(56,21,"Restore light status")
		end
		return 1
	elseif control==7 and value==0
	then
		if get_language() == 0--����
		then
			set_text(56,21,"�������һ֡")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(56,21,"Save last frame")
		end
		return 1
	--��ɫ����ѡ�� 
	elseif control==18 and value==1
	then
		local num = get_value(56,19)
		
		num = num + 1
		if num > 7
		then
			num = 1
		end
		
		set_value(56,19,num)--���ÿؼ���ֵ	
		set_value(55,29,num)--���ÿؼ���ֵ	
		
		for i = 1,7 do
		
			if i <= num
			then
				set_visiable(56,60+i,1)
				set_visiable(55,51+i,1)
			else
				set_visiable(56,60+i,0)
				set_visiable(55,51+i,0)
			end
		end
		
		return 1
	elseif control==18 and value==0
	then
		return 1
	
	--������ɫ���� 
	elseif control==20 and value==1
	then
		local ee = 0x33
		
		set_text(56,6,"Setting")
		
		ss = get_text(56,5)
		if ss == "UCS512-KL"
		then
			ee = 0x33
		elseif ss == "UCS512-KL-S"
		then
			ee = 0x55
		end
		
		local num = get_value(56,19)
		if num > 8 or num < 1
		then
			num = 3
		end
	
		Send_cmd(0xc7,0x3d,0x19,ee,num-1,0,0,0,0)
		
		DMX_Status_page = 0x55
		
		return 1
	elseif control==20 and value==0
	then
		return 1
	
	--�����ϵ�����
	elseif control==31 and value==1
	then
		
		set_text(56,32,"Setting")
	
		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3d--ָʾUCS512-KHд����
		
		send_cmd_xb[7] = 0x15--д �ϵ�Ҷ� �ı��
		
		ss = get_text(55,5)
		if ss == "UCS512-KL"
		then
			send_cmd_xb[8] = 0x33
		elseif ss == "UCS512-KL-S"
		then
			send_cmd_xb[8] = 0x55
		end
		
		
		if get_value(56,8)==0	   then send_cmd_xb[9]=0x00
		elseif  get_value(56,8)==1 then send_cmd_xb[9]=0x01	end
		
		if get_value(56,7)==0	   then send_cmd_xb[10]=0x00
		elseif  get_value(56,7)==1 then send_cmd_xb[10]=0x01 end
		
		
		send_cmd_xb[11] = get_value(56,61)--R
		send_cmd_xb[12] = get_value(56,62)--G
		send_cmd_xb[13] = get_value(56,63)--B
		send_cmd_xb[14] = get_value(56,64)--W1
		send_cmd_xb[15] = get_value(56,65)--W2
		send_cmd_xb[16] = get_value(56,66)--W3
		send_cmd_xb[17] = get_value(56,67)--W4
	
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		----
		DMX_Status_page = 0x55
		return 1
	elseif control==31 and value==0
	then
		return 1
	end	
end

function screen_57()
	screen = screen_t
	control = control_t
	value = value_t
	
	local effect = 0xC4
	
	if get_value(0,12) == 0--Ԥ��Ч��
	then
		effect = 0xC4		
	elseif get_value(0,12) == 1--SDЧ��
	then
		effect = 0xa3	
	end	
	
	if control==1 and value==1
	then
	    set_value(0,26,control - 1)
		set_text(0,4,"UCS1903")
			
		Send_cmd(effect,0,0,0,0,0,0,0,0)

		change_screen(0)
		return 1
	elseif control==1 and value==0
	then
		return 1
	elseif control==2  and value==1
	then
	    set_value(0,26,control - 1)
		set_text(0,4,"DMX 250K")

		Send_cmd(effect,10,0,0,0,0,0,0,0)

		change_screen(0)
		return 1
	elseif control==2 and value==0
	then
		return 1
	elseif control==3  and value==1
	then
	    set_value(0,26,control - 1)
		set_text(0,4,"DMX 500K")

		Send_cmd(effect,11,0,0,0,0,0,0,0)

		change_screen(0)
		return 1
	elseif control==3 and value==0
	then
		return 1
	elseif control==4  and value==1
	then
	    set_value(0,26,control - 1)
		set_text(0,4,"GS851X")

		Send_cmd(effect,23,0,0,0,0,0,0,0)

		change_screen(0)
		return 1
	elseif control==4 and value==0
	then
		return 1
	else --�����˵�
		if get_text(57,13) == "UCS2603"
		then
		    set_text(57,13,"")
			
		    set_value(0,26,7)
			set_text(0,4,"UCS2603")
			
			Send_cmd(effect,30,0,0,0,0,0,0,0)

	        change_screen(0)
			return 1
		elseif get_text(57,13) == "UCSX603_T"
		then
		    set_text(57,13,"")
			
		    set_value(0,26,6)
			set_text(0,4,"UCSX603_T")

			Send_cmd(effect,14,0,0,0,0,0,0,0)

		    change_screen(0)
			return 1
		elseif get_text(57,13) == "UCS5/8603"
		then
		    set_text(57,13,"")
			
			set_value(0,26,8)
			set_text(0,4,"UCS5/8603")

			Send_cmd(effect,15,0,0,0,0,0,0,0)

		    change_screen(0)
			return 1
		elseif get_text(57,13) == "UCS8904"
		then
		    set_text(57,13,"")
			
			set_value(0,26,9)
			set_text(0,4,"UCS8904")

			Send_cmd(effect,20,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "UCS9812"
		then
		    set_text(57,13,"")
			
			set_value(0,26,10)
			set_text(0,4,"UCS9812")

			Send_cmd(effect,26,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "UCS7604"
		then
		    set_text(57,13,"")
			
			set_value(0,26,11)
			set_text(0,4,"UCS7604")

			Send_cmd(effect,33,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "UCS7604"
		then
		    set_text(57,13,"")
			
			set_text(0,4,"UCSX603_T")
			set_value(0,26,7)

			Send_cmd(effect,14,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "UCS7804"
		then
		    set_text(57,13,"")
			
			set_value(0,26,12)
			set_text(0,4,"UCS7804")

			Send_cmd(effect,31,0,0,0,0,0,0,0)
            change_screen(0)			
			return 1
		elseif get_text(57,13) == "SM16212"
		then
		    set_text(57,13,"")
			
			set_value(0,26,13)
			set_text(0,4,"SM16212")

			Send_cmd(effect,40,0,0,0,0,0,0,0)
	
            change_screen(0)			
			return 1
		elseif get_text(57,13) == "SM16713_A"
		then
		    set_text(57,13,"")
			
			set_value(0,26,14)
			set_text(0,4,"SM16713_A")

			Send_cmd(effect,40,0,0,0,0,0,0,0)
	
            change_screen(0)			
			return 1
		elseif get_text(57,13) == "SM16713_B"
		then
		    set_text(57,13,"")
			
			set_value(0,26,15)
			set_text(0,4,"SM16713_B")

			Send_cmd(effect,41,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "SM16713_C"
		then
		    set_text(57,13,"")
			
			set_value(0,26,16)
			set_text(0,4,"SM16713_C")

			Send_cmd(effect,42,0,0,0,0,0,0,0)
	
            change_screen(0)			
			return 1
		elseif get_text(57,13) == "SM16714"
		then
		    set_text(57,13,"")
			
			set_value(0,26,17)
			set_text(0,4,"SM16714")

			Send_cmd(effect,21,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "SM16716"
		then
		    set_text(57,13,"")
			
			set_value(0,26,18)
			set_text(0,4,"SM16716")

			Send_cmd(effect,1,0,0,0,0,0,0,0)
	
            change_screen(0)			
			return 1
		elseif get_text(57,13) == "SM16803"
		then
		    set_text(57,13,"")
			
			set_value(0,26,19)
			set_text(0,4,"SM16803")

			Send_cmd(effect,27,0,0,0,0,0,0,0)

		    change_screen(0)
			return 1
		elseif get_text(57,13) == "SM16804"
		then
		    set_text(57,13,"")
			
			set_value(0,26,20)
			set_text(0,4,"SM16804")

			Send_cmd(effect,28,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "SM16813"
		then
		    set_text(57,13,"")
			
			set_value(0,26,21)
			set_text(0,4,"SM16813")

			Send_cmd(effect,22,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "TM1814"
		then
		    set_text(57,13,"")
			
			set_value(0,26,4)
			set_text(0,4,"TM1814")

			Send_cmd(effect,17,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "TM1914"
		then
		    set_text(57,13,"")
			
			set_value(0,26,5)
			set_text(0,4,"TM1914")

			Send_cmd(effect,8,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "WS2816"
		then
		    set_text(57,13,"")
			
			set_value(0,26,22)
			set_text(0,4,"WS2816")

			Send_cmd(effect,25,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "LPD6803"
		then
		    set_text(57,13,"")
			
			set_value(0,26,23)
			set_text(0,4,"LPD6803")
			
			Send_cmd(effect,3,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "HW1002"
		then
		    set_text(57,13,"")
			
			set_value(0,26,24)
			set_text(0,4,"HW1002")

			Send_cmd(effect,50,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "HW1603_1"
		then
		    set_text(57,13,"")
			
			set_value(0,26,25)
			set_text(0,4,"HW1603_1")

			Send_cmd(effect,51,0,0,0,0,0,0,0)
	
            change_screen(0)			
			return 1
		elseif get_text(57,13) == "HW1603_2"
		then
		    set_text(57,13,"")
			
			set_value(0,26,26)
			set_text(0,4,"HW1603_2")

			Send_cmd(effect,52,0,0,0,0,0,0,0)
	
            change_screen(0)			
			return 1
		elseif get_text(57,13) == "HW1603_3"
		then
		    set_text(57,13,"")
			
			set_value(0,26,27)
			set_text(0,4,"HW1603_3")

			Send_cmd(effect,53,0,0,0,0,0,0,0)
	
            change_screen(0)			
			return 1
		elseif get_text(57,13) == "KW5603A"
		then
		    set_text(57,13,"")
			
			set_value(0,26,28)
			set_text(0,4,"KW5603A")

			Send_cmd(effect,34,0,0,0,0,0,0,0)
	
            change_screen(0)			
			return 1
		elseif get_text(57,13) == "KW5604"
		then
		    set_text(57,13,"")
			
			set_value(0,26,29)
			set_text(0,4,"KW5604")

			Send_cmd(effect,35,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "KW5603_T"
		then
		    set_text(57,13,"")
			
			set_value(0,26,30)
			set_text(0,4,"KW5603_T")

			Send_cmd(effect,36,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "KW5604_T"
		then
		    set_text(57,13,"")
			
			set_value(0,26,31)
			set_text(0,4,"KW5604_T")

			Send_cmd(effect,37,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "QS2633"
		then
		    set_text(57,13,"")
			
			set_value(0,26,32)
			set_text(0,4,"QS2633")

			Send_cmd(effect,38,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "QS2639"
		then
		    set_text(57,13,"")
			
			set_value(0,26,33)
			set_text(0,4,"QS2639")

			Send_cmd(effect,39,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "WS2814"
		then
		    set_text(57,13,"")
			
			set_value(0,26,34)
			set_text(0,4,"WS2814")

			Send_cmd(effect,60,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		elseif get_text(57,13) == "MT1885"
		then
		    set_text(57,13,"")
			
			set_value(0,26,35)
			set_text(0,4,"MT1885")

			Send_cmd(effect,61,0,0,0,0,0,0,0)

            change_screen(0)			
			return 1
		end
		return 1
	end
end

function screen_58()

	screen = screen_t
	control = control_t
	value = value_t
	
	if control==8 and value==1
	then
		set_text(58,28,"16KHZ")
		return 1
	elseif control==8 and value==0
	then
		set_text(58,28,"250HZ")
		return 1	

	elseif control==7 and value==1
	then
		if get_language() == 0
		then
			set_text(58,21,"�ر�")
		elseif get_language() == 1
		then
			set_text(58,21,"Close")
		end
		return 1
	elseif control==7 and value==0
	then
		if get_language() == 0
		then
			set_text(58,21,"����")
			
		elseif get_language() == 1
		then
			set_text(58,21,"Open")
		end
		return 1
	
	--�˿�ˢ��������
	elseif control==18 and value==1
	then

		if get_text(58,19) == "3"
		then
			set_text(58,19,"4")--���ÿؼ���ֵ	
		elseif get_text(58,19) == "4"
		then
			set_text(58,19,"1")--���ÿؼ���ֵ
		elseif get_text(58,19) == "1"
		then
			set_text(58,19,"2")--���ÿؼ���ֵ
		elseif get_text(58,19) == "2"
		then
			set_text(58,19,"3")--���ÿؼ���ֵ	
		end

		return 1
	elseif control==18 and value==0
	then
		return 1
	
	--UCS7804д����
	elseif control==31 and value==1
	then
		set_text(58,32,"Setting")
	
		if get_value(58,8)==0	   then tmp_dat[8]=0x01
		elseif  get_value(58,8)==1 then tmp_dat[8]=0x00	end	--�˿�ˢ����
		
		if get_value(58,7)==0	   then tmp_dat[7]=0x00
		elseif  get_value(58,7)==1 then tmp_dat[7]=0x01 end --�Ҷ�ƽ��
		
		tmp_dat[9] = get_text(58,19)-1--�ֶ����� 0~3
		
		tmp_dat[10] = get_value(58,24)--R 1~64
		tmp_dat[11] = get_value(58,25)--G 1~64	
		tmp_dat[12] = get_value(58,29)--B 1~64
		tmp_dat[13] = get_value(58,30)--W 1~64	

		Send_cmd(0xbb,0,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],tmp_dat[13])		
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nall white")
		end	
		change_screen(40)
		return 1
	elseif control==31 and value==0
	then
		return 1
	end
end

function screen_59()

	screen = screen_t
	control = control_t
	value = value_t
	
	if control==1 and value==1
	then
		set_value(59,1,1)
		set_value(59,2,0)
		return 1
	elseif control==1 and value==0
	then
		set_value(59,1,1)
		set_value(59,2,0)
		return 1	
	elseif control==2 and value==1
	then
		set_value(59,1,0)
		set_value(59,2,1)
		return 1
	elseif control==2 and value==0
	then
		set_value(59,1,0)
		set_value(59,2,1)
		return 1
	elseif control==5 and value==1
	then
		set_value(59,5,1)
		set_value(59,6,0)
		set_value(59,7,0)
		set_value(59,8,0)
		return 1
	elseif control==5 and value==0
	then
		set_value(59,5,1)
		set_value(59,6,0)
		set_value(59,7,0)
		set_value(59,8,0)
		return 1
	elseif control==6 and value==1
	then
		set_value(59,5,0)
		set_value(59,6,1)
		set_value(59,7,0)
		set_value(59,8,0)
		return 1
	elseif control==6 and value==0
	then
		set_value(59,5,0)
		set_value(59,6,1)
		set_value(59,7,0)
		set_value(59,8,0)
		return 1
	elseif control==7 and value==1
	then
		set_value(59,5,0)
		set_value(59,6,0)
		set_value(59,7,1)
		set_value(59,8,0)
		return 1
	elseif control==7 and value==0
	then
		set_value(59,5,0)
		set_value(59,6,0)
		set_value(59,7,1)
		set_value(59,8,0)
		return 1
	elseif control==8 and value==1
	then
		set_value(59,5,0)
		set_value(59,6,0)
		set_value(59,7,0)
		set_value(59,8,1)
		return 1
	elseif control==8 and value==0
	then
		set_value(59,5,0)
		set_value(59,6,0)
		set_value(59,7,0)
		set_value(59,8,1)
		return 1
	elseif control==33 and value==1
	then
		set_value(59,33,1)
		set_value(59,35,0)
		return 1
	elseif control==33 and value==0
	then
		set_value(59,33,1)
		set_value(59,35,0)
		return 1
	elseif control==35 and value==1
	then
		set_value(59,33,0)
		set_value(59,35,1)
		return 1
	elseif control==35 and value==0
	then
		set_value(59,33,0)
		set_value(59,35,1)

		return 1
	elseif control==25 and value==1
	then
		set_text(59,26,"Setting")
	
		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3e--ָʾUCS512-c1д����
		
		send_cmd_xb[7] = 0x01--д�������
		send_cmd_xb[8]=0x33
		
		if get_value(59,33)==1	   then send_cmd_xb[8]=0x55
		elseif  get_value(59,35)==1 then send_cmd_xb[8]=0x33 end
		
		if get_value(59,1)==1	   then send_cmd_xb[9]=0x01
		elseif  get_value(59,2)==1 then send_cmd_xb[9]=0x00	end
		
		if get_value(59,5)==1	   then send_cmd_xb[10]=0x03
		elseif  get_value(59,6)==1 then send_cmd_xb[10]=0x02 
		elseif  get_value(59,7)==1 then send_cmd_xb[10]=0x01 
		elseif  get_value(59,8)==1 then send_cmd_xb[10]=0x00 end
		
		send_cmd_xb[11] = get_value(59,13)--R
		send_cmd_xb[12] = get_value(59,14)--G
		send_cmd_xb[13] = get_value(59,15)--B
		send_cmd_xb[14] = get_value(59,16)--W
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
		
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		DMX_Status_page = 0x55
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ��ʾ�ϵ�������ɫ")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nall light power on light status")	
		end
		change_screen(40)
		return 1
	elseif control==25 and value==0
	then
		return 1
	elseif control==28 and value==1
	then
		set_text(59,29,"Setting")
	
		send_cmd_xb[0] = 0xc3
		send_cmd_xb[1] = 0xff
		send_cmd_xb[2] = 0xff
		send_cmd_xb[3] = 0xff
		send_cmd_xb[4] = 0xff
		send_cmd_xb[5] = 0xc7
		
		send_cmd_xb[6] = 0x3e--ָʾUCS512-c1д����
		
		send_cmd_xb[7] = 0x02--д�������
		send_cmd_xb[8] = 0x33
		
		if get_value(59,33)==1	   then send_cmd_xb[8]=0x55
		elseif  get_value(59,35)==1 then send_cmd_xb[8]=0x33 end
		
		send_cmd_xb[9] = 0x00
		send_cmd_xb[10]= 0x00

		send_cmd_xb[11] = get_value(59,17)-1--R
		send_cmd_xb[12] = get_value(59,18)-1--G
		send_cmd_xb[13] = get_value(59,19)-1--B
		send_cmd_xb[14] = get_value(59,20)-1--W
		send_cmd_xb[15] = 0
		send_cmd_xb[16] = 0
		send_cmd_xb[17] = 0
		
		check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + send_cmd_xb[i]
		end
	
		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)

		send_cmd_xb[18]	= check_sum
		send_cmd_xb[19] = 0xca	

		uart_send_data(send_cmd_xb) --��������	

		stop_timer(4)
		start_timer(4,time5,1,1)

		DMX_Status_page = 0x55
		
		if get_language() == 0--����
		then
			if get_value(59,33)==1	   
			then 
				set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
			elseif  get_value(59,35)==1 
			then 
				set_text(40,2,"д�����ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ���׵�")
			end
				
			elseif get_language() == 1--Ӣ��
			then
				if get_value(59,33)==1	   
				then 
					set_text(40,2,"Write ok,\r\nall white")
				elseif  get_value(59,35)==1 
				then 
					set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
				end
					
			end	

		change_screen(40)
		return 1
	elseif control==28 and value==0
	then
		return 1
	elseif control==30 and value==1
	then
		set_text(3,8,"UCS512-C1")
		change_screen(3)
		return 1
	elseif control==30 and value==0
	then
		return 1
	end
end

function screen_60()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==2 and value==1
	then
		if get_value(60,6) == 1
		then
			set_value(60,6,2)--���ÿؼ���ֵ	
		elseif get_value(60,6) == 2
		then
			set_value(60,6,3)--���ÿؼ���ֵ
		elseif get_value(60,6) == 3
		then
			set_value(60,6,4)--���ÿؼ���ֵ
		elseif get_value(60,6) == 4
		then
			set_value(60,6,1)--���ÿؼ���ֵ	
		end
		return 1
	elseif control==2 and value==0
	then
		return 1	
	--�����Զ�д���ͨ����
	elseif control==7 and value==1
	then	
		if get_language() == 0
		then
			set_text(60,16,"�������һ֡")
		elseif get_language() == 1
		then
			set_text(60,16,"Save last frame")
		end
		return 1
	elseif control==7 and value==0
	then	
		if get_language() == 0
		then
			set_text(60,16,"�ָ��ϵ�״̬")
		elseif get_language() == 1
		then
			set_text(60,16,"Restore light status")
		end
		return 1	
	--�����ֶ���
	elseif control==28 and value==1
	then
		set_text(60,29,"Setting")
		
		---ͨ����
		local ch_num = get_value(60,6)
		if ch_num==1 
		then
			tmp_dat[7] = 0x00
		elseif ch_num==2
		then
			tmp_dat[7] = 0x01
		elseif ch_num==3 
		then
			tmp_dat[7] = 0x02
		elseif ch_num==4 
		then
			tmp_dat[7] = 0x03
		else
			tmp_dat[7] = 0x03
		end	

		Send_cmd(0xb9,tmp_dat[7],0,0,0,0,0,0,0)		
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")
		end
		
		change_screen(40)

		return 1	
	elseif control==28 and value==0
	then
		return 1		
	
	--���ò���
	elseif control==12 and value==1
	then
		set_text(60,36,"Setting")
		
		tmp_dat[8] = get_value(60,7)
		
		if 		get_value(60,31)==1	   	then 	tmp_dat[9]=0x01
		elseif  get_value(60,32)==1 	then 	tmp_dat[9]=0x00	
		else									tmp_dat[9]=0x01		end	--�ϵ�����
			
		tmp_dat[10] = get_value(60,11)--R
		tmp_dat[11] = get_value(60,10)--G	
		tmp_dat[12] = get_value(60,9)--B
		tmp_dat[13] = get_value(60,8)--W	
		
		tmp_dat[14] = get_value(60,38)--R

		Send_cmd(0xbc,0,tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],tmp_dat[13],tmp_dat[14])		
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ������")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nAll blue")
		end
		
		change_screen(40)

		return 1	
	elseif control==12 and value==0
	then
		return 1
	--�����
	elseif control==13 and value==1
	then
		set_text(60,45,"Setting")
		
		tmp_dat[8] = get_value(60,7)
		
		if 		get_value(60,31)==1	   	then 	tmp_dat[9]=0x01
		elseif  get_value(60,32)==1 	then 	tmp_dat[9]=0x00	
		else									tmp_dat[9]=0x01		end	--�ϵ�����
		
		tmp_dat[10] = get_value(60,38)--R

		Send_cmd(0xba,0,tmp_dat[8],0,tmp_dat[10],0,0,0,0)		
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ������")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nAll blue")
		end
		
		change_screen(40)

		return 1	
	elseif control==13 and value==0
	then
		return 1		
	
	--�л���д�������� 2
	elseif control==25 and value==1
	then
		set_text(61,27,"GS8516B")		
		change_screen(61)
		return 1
	elseif control==25 and value==0
	then
		return 1
	elseif control==31 and value==1
	then
		set_value(60,31,1)
		set_value(60,32,0)
		
		if get_language() == 0--����
		then
			set_text(60,19,"�ϵ����ȵȼ���")
		elseif get_language() == 1--Ӣ��
		then
			set_text(60,19,"light status��")
		end	
		return 1
	elseif control==31 and value==0
	then
		set_value(60,31,1)
		set_value(60,32,0)
		
		if get_language() == 0--����
		then
			set_text(60,19,"�ϵ����ȵȼ���")
		elseif get_language() == 1--Ӣ��
		then
			set_text(60,19,"light status��")
		end	
		return 1
	elseif control==32 and value==1
	then
		set_value(60,31,0)
		set_value(60,32,1)
		
		if get_language() == 0--����
		then
			set_text(60,19,"ͨ����ƽ��ȼ���")
		elseif get_language() == 1--Ӣ��
		then
			set_text(60,19,"Ch white balance��")
		end	
		return 1
	elseif control==32 and value==0
	then
		set_value(60,31,0)
		set_value(60,32,1)
		
		if get_language() == 0--����
		then
			set_text(60,19,"ͨ����ƽ��ȼ���")
		elseif get_language() == 1--Ӣ��
		then
			set_text(60,19,"Ch white balance��")
		end	
		return 1
	--�л���д�����
	elseif control==43 and value==1
	then
		set_text(3,8,"GS8516B")			
		change_screen(3)
		
		DMX_add_param = 0x33
		return 1
	elseif control==43 and value==0
	then
		return 1
	end
end

function screen_61()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==8 and value==1
	then
		if get_value(61,14) == 1
		then
			set_value(61,14,2)--���ÿؼ���ֵ	
		elseif get_value(61,14) == 2
		then
			set_value(61,14,3)--���ÿؼ���ֵ
		elseif get_value(61,14) == 3
		then
			set_value(61,14,4)--���ÿؼ���ֵ
		elseif get_value(61,14) == 4
		then
			set_value(61,14,1)--���ÿؼ���ֵ	
		end
		return 1
	elseif control==8 and value==0
	then
		return 1
	elseif control==18 and value==1
	then
		set_text(61,9,"Setting")
	
		--��ʼ��ַ
		 start_ch = get_value(61,19)
		 tmp_dat[7] = math.modf(start_ch/256)	
		 tmp_dat[8] = math.modf(start_ch%256)
	
		---�����ַ
		tmp_dat[9] = get_value(61,14)

		--���� / �ر� �Զ�д�빦��
		if get_value(61,17) ==0 -- �Զ�д��
		then
			tmp_dat[10] = 0x55;
		else
			tmp_dat[10] = 0xaa;
		end 

        if get_text(61,27) == "GS8525" 
	    then 
		    Send_cmd(0xb8,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],1,0,0,0)	
		else 
		   Send_cmd(0xb8,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],0,0,0,0)	
		end
				
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
		
		if tmp_dat[10] == 0x55 --����
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ�����")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(40,2,"Write ok,\r\nAll red")
			end
		elseif tmp_dat[10] == 0xaa --�ر�
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")
			end
		end

		change_screen(40)

		return 1	
	elseif control==18 and value==0
	then
		return 1
	elseif control==1 and value==1 --GS851X дͳһ��ַ
	then
		set_text(61,7,"Setting")

		start_ch = get_value(61,11)--��ʼͨ��
		tmp_dat[7] = math.modf(start_ch/256)
		tmp_dat[8] = math.modf(start_ch%256)	
		
		tmp_dat[9] = get_value(61,12)--���ͨ��

		Send_cmd(0xb4,tmp_dat[7],tmp_dat[8],tmp_dat[9],0,0,0,0,0)	

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")
		end	
		change_screen(40)
		----

		return 1	
	elseif control==1 and value==0
	then
		return 1
	elseif control==2 and value==1 --��ַ����
	then
		set_text(61,10,"Setting")		
 
        if get_text(61,27) == "GS8525" 
	    then 
		    Send_cmd(0xb5,1,0,0,0,0,0,0,0)	
		else 
		    Send_cmd(0xb5,0,0,0,0,0,0,0,0)	
		end

		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")
		end	
		change_screen(40)
		----
		return 1	
	elseif control==2 and value==0
	then
		return 1	
    elseif control==20 and value==1 --������һ��
	then
		if get_text(61,27) == "GS8525"
		then
			change_screen(67)
		elseif get_text(61,27) == "GS8516B"
		then
			change_screen(60)
		end	
		
		----
		return 1	
	elseif control==20 and value==0
	then
		return 1		
	end

end

function screen_62()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==2 and value==1	--�ֶ�����
	then
		if get_value(62,6) == 1
		then
			set_value(62,6,2)--���ÿؼ���ֵ	
		elseif get_value(62,6) == 2
		then
			set_value(62,6,3)--���ÿؼ���ֵ
		elseif get_value(62,6) == 3
		then
			set_value(62,6,4)--���ÿؼ���ֵ
		elseif get_value(62,6) == 4
		then
			set_value(62,6,1)--���ÿؼ���ֵ	
		end
		return 1
	elseif control==2 and value==0
	then
		return 1	
	--�����ֶ���
	elseif control==28 and value==1
	then
		set_text(62,29,"Setting")
		
		---ͨ����
		local ch_num = get_value(62,6)
		if ch_num==1 
		then
			tmp_dat[7] = 0x00
		elseif ch_num==2
		then
			tmp_dat[7] = 0x01
		elseif ch_num==3 
		then
			tmp_dat[7] = 0x02
		elseif ch_num==4 
		then
			tmp_dat[7] = 0x03
		else
			tmp_dat[7] = 0x03
		end	

		Send_cmd(0xb9,tmp_dat[7],0,0,0,0,0,0,0)		
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")
		end
		
		change_screen(40)

		return 1	
	elseif control==28 and value==0
	then
		return 1		
	elseif control==7 and value==1	--ADDI�麸�������
	then	
		if get_language() == 0
		then
			set_text(62,16,"��")
		elseif get_language() == 1
		then
			set_text(62,16,"Open")
		end
		
		return 1
	elseif control==7 and value==0
	then	
		if get_language() == 0
		then
			set_text(62,16,"�ر�")
		elseif get_language() == 1
		then
			set_text(62,16,"Close")
		end
		return 1
	elseif control==10 and value==1	--�Ҷ�ƽ���ȼ�����
	then
	    if get_value(62,39) == 0
		then
			set_value(62,39,1)--���ÿؼ���ֵ
            set_text(62,18,"L1")			
		elseif get_value(62,39) == 1
		then
			set_value(62,39,2)--���ÿؼ���ֵ	
			set_text(62,18,"L2")
		elseif get_value(62,39) == 2
		then
			set_value(62,39,3)--���ÿؼ���ֵ
			set_text(62,18,"L3")
		elseif get_value(62,39) == 3
		then
			set_value(62,39,4)--���ÿؼ���ֵ
			set_text(62,18,"L4")
		elseif get_value(62,39) == 4
		then
			set_value(62,39,5)--���ÿؼ���ֵ
			set_text(62,18,"L5")
        elseif get_value(62,39) == 5
		then
			set_value(62,39,6)--���ÿؼ���ֵ
			set_text(62,18,"L6")
        elseif get_value(62,39) == 6
		then
			set_value(62,39,7)--���ÿؼ���ֵ	
            set_text(62,18,"L7")		
        elseif get_value(62,39) == 7
		then
			set_value(62,39,0)--���ÿؼ���ֵ	
            set_text(62,18,"L0")						
		end
		return 1
	elseif control==10 and value==0
	then
		return 1
	elseif control==11 and value==1	--�Ҷ�ƽ���ȼ�����
	then
	    if get_value(62,40) == 0
		then
			set_value(62,40,1)--���ÿؼ���ֵ
            set_text(62,19,"T2")			
		elseif get_value(62,40) == 1
		then
			set_value(62,40,2)--���ÿؼ���ֵ	
			set_text(62,19,"T3")
		elseif get_value(62,40) == 2
		then
			set_value(62,40,3)--���ÿؼ���ֵ
			set_text(62,19,"T4")
		elseif get_value(62,40) == 3
		then
			set_value(62,40,0)--���ÿؼ���ֵ
			set_text(62,19,"T1")								
		end
		return 1
	elseif control==11 and value==0
	then
		return 1
	elseif control==12 and value==1	--�Ҷ�ƽ���ȼ�����
	then
	    if get_value(62,43) == 0
		then
			set_value(62,43,1)--���ÿؼ���ֵ
            set_text(62,20,"L1")			
		elseif get_value(62,43) == 1
		then
			set_value(62,43,2)--���ÿؼ���ֵ	
			set_text(62,20,"L2")
		elseif get_value(62,43) == 2
		then
			set_value(62,43,3)--���ÿؼ���ֵ
			set_text(62,20,"L3")
		elseif get_value(62,43) == 3
		then
			set_value(62,43,4)--���ÿؼ���ֵ
			set_text(62,20,"L4")
		elseif get_value(62,43) == 4
		then
			set_value(62,43,5)--���ÿؼ���ֵ
			set_text(62,20,"L5")
        elseif get_value(62,43) == 5
		then
			set_value(62,43,6)--���ÿؼ���ֵ
			set_text(62,20,"L6")
        elseif get_value(62,43) == 6
		then
			set_value(62,43,7)--���ÿؼ���ֵ	
            set_text(62,20,"L7")		
        elseif get_value(62,43) == 7
		then
			set_value(62,43,0)--���ÿؼ���ֵ	
            set_text(62,20,"L0")						
		end
		return 1
	elseif control==12 and value==0
	then
		return 1
	elseif control==14 and value==1	--�Ҷ�ƽ���ȼ�����
	then
	    if get_value(62,44) == 0
		then
			set_value(62,44,1)--���ÿؼ���ֵ
            set_text(62,21,"T2")			
		elseif get_value(62,44) == 1
		then
			set_value(62,44,2)--���ÿؼ���ֵ	
			set_text(62,21,"T3")
		elseif get_value(62,44) == 2
		then
			set_value(62,44,3)--���ÿؼ���ֵ
			set_text(62,21,"T4")
		elseif get_value(62,44) == 3
		then
			set_value(62,44,0)--���ÿؼ���ֵ
			set_text(62,21,"T1")								
		end
		return 1
	elseif control==14 and value==0
	then
		return 1
	elseif control==17 and value==1	--�Ҷ�ƽ���ȼ�����
	then
	    if get_value(62,45) == 0
		then
			set_value(62,45,1)--���ÿؼ���ֵ
            set_text(62,22,"C2")			
		elseif get_value(62,45) == 1
		then
			set_value(62,45,2)--���ÿؼ���ֵ	
			set_text(62,22,"C3")
		elseif get_value(62,45) == 2
		then
			set_value(62,45,3)--���ÿؼ���ֵ
			set_text(62,22,"C4")
		elseif get_value(62,45) == 3
		then
			set_value(62,45,0)--���ÿؼ���ֵ
			set_text(62,22,"C1")								
		end
		return 1
	elseif control==17 and value==0
	then
		return 1
		
	elseif control==13 and value==1	--����ADDI�麸���
	then
		set_text(62,15,"Setting")
		
		tmp_dat[8]=0x00
		
		if 	get_value(62,7)==1	 --ADDI�麸���  	
		then
			tmp_dat[8]=0xE0
		end	
		
		tmp_dat[9]=	get_value(62,39)
		tmp_dat[10]= get_value(62,40)
		tmp_dat[11]= get_value(62,43)
		tmp_dat[12]= get_value(62,44)
		tmp_dat[13]= get_value(62,45)
		
		Send_cmd(0xbd,0,tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],tmp_dat[13],0)		
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
		
		if 	get_value(62,7)==1	 --ADDI�麸���  	
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\nADDI �麸оƬ�����")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(40,2,"Write ok,\r\nWelding error detection\r\nred ")
			end
			
		else
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ��ɫ")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(40,2,"Write ok,\r\nAll Black ")
			end
		
		end	
			change_screen(40)
		return 1	
	elseif control==13 and value==0
	then
		return 1
	elseif control==24 and value==1	--�Ҷ�ƽ���ȼ�����
	then
	    GS_BPH = get_value(62,46)
		
		if GS_BPH < 15 then GS_BPH = GS_BPH + 1
		else              GS_BPH = 0         end
		
		set_value(62,46,GS_BPH)--���ÿؼ���ֵ
		
		if GS_BPH == 0 then set_text(62,26,"6.25%")
		elseif GS_BPH == 1 then set_text(62,26,"12.5%")
		elseif GS_BPH == 2 then set_text(62,26,"18.75%")
		elseif GS_BPH == 3 then set_text(62,26,"25%")
		elseif GS_BPH == 4 then set_text(62,26,"31.25%")
		elseif GS_BPH == 5 then set_text(62,26,"37.5%")
		elseif GS_BPH == 6 then set_text(62,26,"43.75%")
		elseif GS_BPH == 7 then set_text(62,26,"50%")
		elseif GS_BPH == 8 then set_text(62,26,"56.25%")
		elseif GS_BPH == 9 then set_text(62,26,"62.5%")
		elseif GS_BPH == 10 then set_text(62,26,"68.75%")
		elseif GS_BPH == 11 then set_text(62,26,"75%")
		elseif GS_BPH == 12 then set_text(62,26,"81.25%")
		elseif GS_BPH == 13 then set_text(62,26,"87.5%")
		elseif GS_BPH == 14 then set_text(62,26,"93.75%")
		elseif GS_BPH == 15 then set_text(62,26,"100%") end
		
		return 1
	elseif control==24 and value==0
	then
		return 1
    elseif control==31 and value==1	--�Ҷ�ƽ���ȼ�����
	then
	    GS_BPH = get_value(62,47)
		
		if GS_BPH < 15 then GS_BPH = GS_BPH + 1
		else              GS_BPH = 0         end
		
		set_value(62,47,GS_BPH)--���ÿؼ���ֵ
		
		if GS_BPH == 0 then set_text(62,32,"6.25%")
		elseif GS_BPH == 1 then set_text(62,32,"12.5%")
		elseif GS_BPH == 2 then set_text(62,32,"18.75%")
		elseif GS_BPH == 3 then set_text(62,32,"25%")
		elseif GS_BPH == 4 then set_text(62,32,"31.25%")
		elseif GS_BPH == 5 then set_text(62,32,"37.5%")
		elseif GS_BPH == 6 then set_text(62,32,"43.75%")
		elseif GS_BPH == 7 then set_text(62,32,"50%")
		elseif GS_BPH == 8 then set_text(62,32,"56.25%")
		elseif GS_BPH == 9 then set_text(62,32,"62.5%")
		elseif GS_BPH == 10 then set_text(62,32,"68.75%")
		elseif GS_BPH == 11 then set_text(62,32,"75%")
		elseif GS_BPH == 12 then set_text(62,32,"81.25%")
		elseif GS_BPH == 13 then set_text(62,32,"87.5%")
		elseif GS_BPH == 14 then set_text(62,32,"93.75%")
		elseif GS_BPH == 15 then set_text(62,32,"100%") end
		
		return 1
	elseif control==31 and value==0
	then
		return 1	
    elseif control==33 and value==1	--�Ҷ�ƽ���ȼ�����
	then
	    GS_BPH = get_value(62,48)
		
		if GS_BPH < 15 then GS_BPH = GS_BPH + 1
		else              GS_BPH = 0         end
		
		set_value(62,48,GS_BPH)--���ÿؼ���ֵ
		
		if GS_BPH == 0 then set_text(62,34,"6.25%")
		elseif GS_BPH == 1 then set_text(62,34,"12.5%")
		elseif GS_BPH == 2 then set_text(62,34,"18.75%")
		elseif GS_BPH == 3 then set_text(62,34,"25%")
		elseif GS_BPH == 4 then set_text(62,34,"31.25%")
		elseif GS_BPH == 5 then set_text(62,34,"37.5%")
		elseif GS_BPH == 6 then set_text(62,34,"43.75%")
		elseif GS_BPH == 7 then set_text(62,34,"50%")
		elseif GS_BPH == 8 then set_text(62,34,"56.25%")
		elseif GS_BPH == 9 then set_text(62,34,"62.5%")
		elseif GS_BPH == 10 then set_text(62,34,"68.75%")
		elseif GS_BPH == 11 then set_text(62,34,"75%")
		elseif GS_BPH == 12 then set_text(62,34,"81.25%")
		elseif GS_BPH == 13 then set_text(62,34,"87.5%")
		elseif GS_BPH == 14 then set_text(62,34,"93.75%")
		elseif GS_BPH == 15 then set_text(62,34,"100%") end
		
		return 1
	elseif control==33 and value==0
	then
		return 1	
    elseif control==35 and value==1	--�Ҷ�ƽ���ȼ�����
	then
	    GS_BPH = get_value(62,49)
		
		if GS_BPH < 15 then GS_BPH = GS_BPH + 1
		else                GS_BPH = 0         end
		
		set_value(62,49,GS_BPH)--���ÿؼ���ֵ
		
		if GS_BPH == 0 then set_text(62,36,"6.25%")
		elseif GS_BPH == 1 then set_text(62,36,"12.5%")
		elseif GS_BPH == 2 then set_text(62,36,"18.75%")
		elseif GS_BPH == 3 then set_text(62,36,"25%")
		elseif GS_BPH == 4 then set_text(62,36,"31.25%")
		elseif GS_BPH == 5 then set_text(62,36,"37.5%")
		elseif GS_BPH == 6 then set_text(62,36,"43.75%")
		elseif GS_BPH == 7 then set_text(62,36,"50%")
		elseif GS_BPH == 8 then set_text(62,36,"56.25%")
		elseif GS_BPH == 9 then set_text(62,36,"62.5%")
		elseif GS_BPH == 10 then set_text(62,36,"68.75%")
		elseif GS_BPH == 11 then set_text(62,36,"75%")
		elseif GS_BPH == 12 then set_text(62,36,"81.25%")
		elseif GS_BPH == 13 then set_text(62,36,"87.5%")
		elseif GS_BPH == 14 then set_text(62,36,"93.75%")
		elseif GS_BPH == 15 then set_text(62,36,"100%") end
		
		return 1
	elseif control==35 and value==0
	then
		return 1
	elseif control==37 and value==1		--����ͨ����ƽ��
	then
		set_text(62,38,"Setting")
		
		tmp_dat[8] = get_value(62,46)	
		tmp_dat[9] = get_value(62,47)
		tmp_dat[10] = get_value(62,48)
		tmp_dat[11] = get_value(62,49)

		Send_cmd(0xD1,0,tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],0,0,0)		
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ������")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nAll blue")
		end
		
		change_screen(40)

		return 1	
	elseif control==49 and value==0
	then
		return 1		
	elseif control==47 and value==1	--�Ҷ�ƽ���ȼ�����
	then
		if get_value(62,48) == 1
		then
			set_value(62,48,2)--���ÿؼ���ֵ	
		elseif get_value(62,48) == 2
		then
			set_value(62,48,3)--���ÿؼ���ֵ
		elseif get_value(62,48) == 3
		then
			set_value(62,48,4)--���ÿؼ���ֵ
		elseif get_value(62,48) == 4
		then
			set_value(62,48,1)--���ÿؼ���ֵ	
		end
		return 1
	elseif control==47 and value==0
	then
		return 1
	elseif control==49 and value==1		--���ûҶ�ƽ��
	then
		set_text(62,50,"Setting")
		
		tmp_dat[8] = get_value(62,48) - 1	

		Send_cmd(0xbe,0,tmp_dat[8],0,0,0,0,0,0)		
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ������")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nAll blue")
		end
		
		change_screen(40)

		return 1	
	elseif control==49 and value==0
	then
		return 1
	--�л���д�����
	elseif control==41 and value==1 --�л���д�����
	then
		if get_value(0,12) == 0--����Ч��
		then
			Send_cmd(0xc1,0x55,0,0,0,0,0,0,0)	
		else
			Send_cmd(0xa1,0x55,0,0,0,0,0,0,0)	
		end
		
		set_text(3,8,"GS8525")			
		change_screen(3)
		
		DMX_add_param = 0x33
		return 1
	elseif control==41 and value==0
	then
		return 1
	elseif control==1 and value==1 --�л�����һ������
	then
		if get_value(0,12) == 0--����Ч��
		then
			Send_cmd(0xc1,0x55,0,0,0,0,0,0,0)	
		else
			Send_cmd(0xa1,0x55,0,0,0,0,0,0,0)	
		end
		
		change_screen(2)

		return 1
	elseif control==1 and value==0
	then
		return 1
	elseif control==5 and value==1 --�л�����һ������
	then
		if get_value(0,12) == 0--����Ч��
		then
			Send_cmd(0xc1,0x55,0,0,0,0,0,0,0)	
		else
			Send_cmd(0xa1,0x55,0,0,0,0,0,0,0)	
		end
		change_screen(34)
		
		return 1
	elseif control==5 and value==0
	then
		return 1	
	elseif control==25 and value==1 --�л�����һ������
	then
		if get_value(0,12) == 0--����Ч��
		then
			Send_cmd(0xc1,0x55,0,0,0,0,0,0,0)	
		else
			Send_cmd(0xa1,0x55,0,0,0,0,0,0,0)	
		end
		
		set_text(63,31,"GS8525")		
		change_screen(63)
		
		return 1
	elseif control==25 and value==0
	then
		return 1	
	--��������֡
	elseif control==43 and value==1 or control==31
	then
		set_text(62,44,"Setting")
		
		tmp_dat[7] = get_value(62,40)--Gramma

		tmp_dat[8] = get_value(62,33)--R
		tmp_dat[9] = get_value(62,34)--G	
		tmp_dat[10] = get_value(62,35)--B
		tmp_dat[11] = get_value(62,36)--W

		tmp_dat[12] = get_value(62,31)--��������	

		Send_cmd(0xb6,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],0,0)		
		
		stop_timer(4)
		start_timer(4,time5,1,1)

		DMX_Status_page = 0x55
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nall white")
		end	
		change_screen(40)

		return 1	
	elseif control==43 and value==1 or control~=31
	then
		return 1
	end
end

function screen_63()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==1 and value==1	--�������ź�״̬
	then
		if get_value(63,14) == 0
		then
			set_value(63,14,1)--���ÿؼ���ֵ
			
		if get_language() == 0--����
		then
			set_text(63,7,"����Ч��")
		elseif get_language() == 1--Ӣ��
		then
			set_text(63,7,"Built in effects")
		end	
			
		elseif get_value(63,14) == 1
		then
			set_value(63,14,2)--���ÿؼ���ֵ
			
			if get_language() == 0--����
			then
				set_text(63,7,"���")
			elseif get_language() == 1--Ӣ��
			then
				set_text(63,7,"Lights out")
			end	
		elseif get_value(63,14) == 2
		then
			set_value(63,14,3)--���ÿؼ���ֵ
			
			if get_language() == 0--����
			then
				set_text(63,7,"�������һ֡")
			elseif get_language() == 1--Ӣ��
			then
				set_text(63,7,"Save last frame")
			end	
		elseif get_value(63,14) == 3
		then
			set_value(63,14,0)--���ÿؼ���ֵ	
			
			if get_language() == 0--����
			then
				set_text(63,7,"RGBW�ϵ�����")
			elseif get_language() == 1--Ӣ��
			then
				set_text(63,7,"Restore light status")
			end	
		end
		return 1
	elseif control==1 and value==0
	then
		return 1	
	--���û����仯�ٶ�
	elseif control==2 and value==1
	then
		if get_value(63,15) == 0
		then
			set_value(63,15,1)--���ÿؼ���ֵ
			
			if get_language() == 0--����
			then
				set_text(63,9,"10֡/��")
			elseif get_language() == 1--Ӣ��
			then
				set_text(63,9,"10Frames/sec")
			end	
			
		elseif get_value(63,15) == 1
		then
			set_value(63,15,2)--���ÿؼ���ֵ
			
			if get_language() == 0--����
			then
				set_text(63,9,"20֡/��")
			elseif get_language() == 1--Ӣ��
			then
				set_text(63,9,"20Frames/sec")
			end	

		elseif get_value(63,15) == 2
		then
			set_value(63,15,3)--���ÿؼ���ֵ
			
			if get_language() == 0--����
			then
				set_text(63,9,"40֡/��")
			elseif get_language() == 1--Ӣ��
			then
				set_text(63,9,"40Frames/sec")
			end	
		elseif get_value(63,15) == 3
		then
			set_value(63,15,0)--���ÿؼ���ֵ	
			
			if get_language() == 0--����
			then
				set_text(63,9,"5֡/��")
			elseif get_language() == 1--Ӣ��
			then
				set_text(63,9,"5Frames/sec")
			end	
		end
		return 1	
	elseif control==2 and value==0
	then
		return 1		
	--���û����仯����
	elseif control==5 and value==1
	then
		if get_value(63,26) == 0
		then
			set_value(63,26,1)--���ÿؼ���ֵ
			
			if get_language() == 0--����
			then
				set_text(63,10,"32��")
			elseif get_language() == 1--Ӣ��
			then
				set_text(63,10,"32points")
			end	
		elseif get_value(63,26) == 1
		then
			set_value(63,26,2)--���ÿؼ���ֵ
			
			if get_language() == 0--����
			then
				set_text(63,10,"64��")
			elseif get_language() == 1--Ӣ��
			then
				set_text(63,10,"64points")
			end	
		elseif get_value(63,26) == 2
		then
			set_value(63,26,3)--���ÿؼ���ֵ
			
			if get_language() == 0--����
			then
				set_text(63,10,"128��")
			elseif get_language() == 1--Ӣ��
			then
				set_text(63,10,"128points")
			end	
		elseif get_value(63,26) == 3
		then
			set_value(63,26,0)--���ÿؼ���ֵ	
			
			if get_language() == 0--����
			then
				set_text(63,10,"16��")
			elseif get_language() == 1--Ӣ��
			then
				set_text(63,10,"16points")
			end	
		end

		return 1	
	elseif control==5 and value==0
	then
		return 1
	elseif control==22 and value==1	--W ��������
	then
		if get_value(63,32) == 1
		then
			set_value(63,32,2)--���ÿؼ���ֵ	
		elseif get_value(63,32) == 2
		then
			set_value(63,32,3)--���ÿؼ���ֵ
		elseif get_value(63,32) == 3
		then
			set_value(63,32,1)--���ÿؼ���ֵ	
		end
		return 1
	elseif control==22 and value==0
	then
		return 1	
	elseif control==28 and value==1
	then
		set_value(63,28,1)--���ÿؼ���ֵ	
		return 1	
	elseif control==28 and value==0
	then
		set_value(63,28,0)--���ÿؼ���ֵ	
		return 1
	elseif control==6 and value==1
	then
		set_value(63,6,1)--���ÿؼ���ֵ	
		return 1	
	elseif control==6 and value==0
	then
		set_value(63,6,0)--���ÿؼ���ֵ	
		return 1
	elseif control==16 and value==1
	then
		set_value(63,16,1)--���ÿؼ���ֵ	
		return 1	
	elseif control==16 and value==0
	then
		set_value(63,16,0)--���ÿؼ���ֵ	
		return 1
	elseif control==17 and value==1
	then
		set_value(63,17,1)--���ÿؼ���ֵ	
		return 1	
	elseif control==17 and value==0
	then
		set_value(63,17,0)--���ÿؼ���ֵ	
		return 1
	elseif control==37 and value==1
	then
		if get_language() == 0--����
		then
			set_text(63,38,"���õ���")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(63,38,"External current")
		end
		return 1	
	elseif control==37 and value==0
	then
		if get_language() == 0--����
		then
			set_text(63,38,"���õ���")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(63,38,"Internal current")
		end
		return 1
	elseif control==27 and value==1	--���ź�״̬���ϵ�Ҷ�����
	then
		set_text(63,19,"Setting")
		
		tmp_dat[7] = get_value(63,37) * 0x80
		
		if get_value(63,32) == 3	
		then  
			tmp_dat[8]=get_value(63,32)*32 + get_value(63,14)*8
		else
			tmp_dat[8]=get_value(63,32)*32 + get_value(63,14)*8 - 32
		end
		
		tmp_dat[9] = 0
		
		if get_value(63,14) == 0x01
		then
			tmp_dat[9]=get_value(63,28)*128 + get_value(63,6)*64 + get_value(63,16)*32 + get_value(63,17)*16 + get_value(63,15)*4 + get_value(63,26)
		end
		
		tmp_dat[10]=get_value(63,24)
		tmp_dat[11]=get_value(63,25)
		tmp_dat[12]=get_value(63,29)
		tmp_dat[13]=get_value(63,30)	
			
		Send_cmd(0xbf,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],tmp_dat[13],0)	
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
		
		if get_value(63,14) == 0
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ��ʾ�ϵ�������ɫ")
			elseif get_language() == 1--Ӣ��
			then
				set_text(40,2,"Write ok,\r\nall light power on light status")	
			end
		elseif get_value(63,14) == 1
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ������Ч��")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(40,2,"Write ok,\r\nAll Play Built in effects")
			end
		
		elseif get_value(63,14) == 2
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ��ɫ")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(40,2,"Write ok,\r\nAll black")
			end
		
		elseif get_value(63,14) == 3
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ��ʾ�ϵ�������ɫ")
			elseif get_language() == 1--Ӣ��
			then
				set_text(40,2,"Write ok,\r\nall light power on light status")	
			end
		
		end

		change_screen(40)
		return 1	
	elseif control==27 and value==0
	then
		return 1
	elseif control==33 and value==1 --�л�����һ������
	then
		set_text(67,30,"GS8525")		
		change_screen(67)
		return 1
	elseif control==33 and value==0
	then
		return 1	
	end
end

function screen_64()
	screen = screen_t
	control = control_t
	value = value_t

	if control==5 and value==1
	then
		if get_value(64,14) == 1
		then
			set_value(64,14,2)--���ÿؼ���ֵ	
		elseif get_value(64,14) == 2
		then
			set_value(64,14,3)--���ÿؼ���ֵ
		elseif get_value(64,14) == 3
		then
			set_value(64,14,4)--���ÿؼ���ֵ
		elseif get_value(64,14) == 4
		then
			set_value(64,14,1)--���ÿؼ���ֵ	
		end
		return 1
	elseif control==5 and value==0
	then
		return 1
--�Զ�д�� ���� / �ر�
	elseif control==18 and value==1
	then
		set_text(64,20,"Setting")
	
		--��ʼ��ַ
		 start_ch = get_value(64,19)
		 tmp_dat[7] = math.modf(start_ch/256)	
		 tmp_dat[8] = math.modf(start_ch%256)
	
		---�����ַ
		tmp_dat[9] = get_value(64,14) +4

		--���� / �ر� �Զ�д�빦��
		if get_value(64,17) ==0 -- �Զ�д��
		then
			tmp_dat[10] = 0x55;
		else
			tmp_dat[10] = 0xaa;
		end 

		Send_cmd(0xb8,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],0,0,0,0)		
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
		
		if tmp_dat[10] == 0x55 --����
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ�����")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(40,2,"Write ok,\r\nAll red")
			end
		elseif tmp_dat[10] == 0xaa --�ر�
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")
			end
		end

		change_screen(40)

		return 1	
	elseif control==18 and value==0
	then
		return 1
	end
end

function screen_65()
	screen = screen_t
	control = control_t
	value = value_t

	if control==3 and value==1 --ȷ����ť
	then
		if Auto_write == 0x55
		then
			Auto_write = 0
			
			if get_language() == 0--����
			then
				set_text(3,2,"����дַ")
			elseif get_language() == 1--Ӣ��
			then
				set_text(3,2,"Writing")
			end
			
			--����дַ����
			local write_addr={}  
		
			write_addr[0] = 0xc3

			write_addr[1] = 0xff --UID
			write_addr[2] = 0xff	
			write_addr[3] = 0xff	
			write_addr[4] = 0xff	
			
			write_addr[5] = 0xc6 --������

			start_ch = get_value(3,9)
			jiange_ch = get_value(3,10)
			
			chongfu_ch = get_value(3,23)

			sel_chip = dmx_ic_Sel()

			if get_value(3,19) == 0 and get_value(3,20) == 1 --���յ���д
			then
				start_ch = (start_ch-1)*jiange_ch + 1;
				
				write_addr[6] = 0x00	
				write_addr[7] = math.modf(start_ch/256)	
				write_addr[8] = math.modf(start_ch%256)
			else --����ͨ��д
				
				write_addr[6] = 0x00	
				write_addr[7] = math.modf(start_ch/256)	
				write_addr[8] = math.modf(start_ch%256)
			end
			
			if get_text(3,8) == "GS8525"
			then
				jiange_ch = get_value(3,10) + 4  
			end

			--���ͨ��
			write_addr[9] = jiange_ch

			--оƬ�ͺ�
			write_addr[10] = sel_chip
			
			--�ظ�д��
			write_addr[11] = math.modf(chongfu_ch/256)	
			write_addr[12] = math.modf(chongfu_ch%256)	
			
			--ͳһ��ַ
			write_addr[13] = tongyi	

			
			--ָ���˿�
			write_addr[14]=0xff	

			for i=15,18 do
				write_addr[i] = 0x00
			end

			local check_sum=0	
			for i=1,17 do
				check_sum = check_sum  + write_addr[i]
			end

			check_sum = math.modf(check_sum%256)	
			check_sum = Xor(check_sum,0x39)
		
			write_addr[18] = check_sum
			write_addr[19] = 0xca	
		
			uart_send_data(write_addr) --��������
			
			change_screen(03)
			
			stop_timer(4)
			start_timer(4,time5,1,1)
			
			str = get_text(3,8)--�õ���ǰ��IC�ͺ�
			
			if str == "UCS512-KL" or str == "UCS512-KH"
			then
				DMX_Status_page = 0x55
				
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ���׵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
				end
				
				change_screen(40)
			elseif str == "UCS512-C4"
			then
			
			end
			
		
		else
			Auto_write = 0
			Send_cmd(0xc7,0x3d,0x13,0x33,0x01,0,0,0,0)	

			DMX_Status_page = 0x55

			if get_language() == 0--����
			then
				if get_text(3,8)== "UCS512-KL"		then	set_text(65,7,"UCS512-KL����д����") 
				elseif get_text(3,8)== "UCS512-KH" 	then	set_text(65,7,"UCS512-KH����д����") 			end
					
				set_text(65,2,"���ڹرո�оƬ���Զ�д�빦�ܣ�")	
			elseif get_language() == 1--Ӣ��
			then
				if get_text(3,8)== "UCS512-KL"		then	set_text(65,7,"UCS512-KL Parameter writing")	
				elseif get_text(3,8)== "UCS512-KH" 	then	set_text(65,7,"UCS512-KH Parameter writing")	 end
				
				set_text(65,2,"Shutting down automatic coding��")	
			end
			
		end

		return 1
	elseif control==3 and value==0 --ȷ����ť 
	then
		return 1
	
	--ȡ�� ��ť
	elseif control==4 and value==1 --ȡ����ť
	then
		Auto_write = 0
		if get_language() == 0--����
		then
			set_text(3,2,"����дַ")
		elseif get_language() == 1--Ӣ��
		then
			set_text(3,2,"Writing")
		end
		
		--����дַ����
		local write_addr={}  
	
		write_addr[0] = 0xc3

		write_addr[1] = 0xff --UID
		write_addr[2] = 0xff	
		write_addr[3] = 0xff	
		write_addr[4] = 0xff	
		
		write_addr[5] = 0xc6 --������

		start_ch = get_value(3,9)
		jiange_ch = get_value(3,10)
		
		chongfu_ch = get_value(3,23)

		sel_chip = dmx_ic_Sel()

		if get_value(3,19) == 0 and get_value(3,20) == 1 --���յ���д
		then
			start_ch = (start_ch-1)*jiange_ch + 1;
			
			write_addr[6] = 0x00	
			write_addr[7] = math.modf(start_ch/256)	
			write_addr[8] = math.modf(start_ch%256)
		else --����ͨ��д
			
			write_addr[6] = 0x00	
			write_addr[7] = math.modf(start_ch/256)	
			write_addr[8] = math.modf(start_ch%256)
		end
		
		if get_text(3,8) == "GS8525"
		then
			jiange_ch = get_value(3,10) + 4  
		end

		--���ͨ��
		write_addr[9] = jiange_ch

		--оƬ�ͺ�
		write_addr[10] = sel_chip
		
		--�ظ�д��
		write_addr[11] = math.modf(chongfu_ch/256)	
		write_addr[12] = math.modf(chongfu_ch%256)	
		
		--ͳһ��ַ
		write_addr[13] = tongyi	

		
		--ָ���˿�
		write_addr[14]=0xff	

		for i=15,18 do
			write_addr[i] = 0x00
		end

		local check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + write_addr[i]
		end

		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)
	
		write_addr[18] = check_sum
		write_addr[19] = 0xca	
	
		uart_send_data(write_addr) --��������
		
		change_screen(03)
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		str = get_text(3,8)--�õ���ǰ��IC�ͺ�
		
		if str == "UCS512-KL" or str == "UCS512-KH"
		then
			DMX_Status_page = 0x55
			
			if get_language() == 0--����
			then
				set_text(40,2,"дַ�ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ���׵�")	
			elseif get_language() == 1--Ӣ��
			then
				set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
			end
			
			change_screen(40)
			
		elseif str == "UCS512-KH"
		then
		
		elseif str == "UCS512-C4"
		then
		
		end
		return 1
	elseif control==4 and value==0 --ȡ����ť
	then
		return 1
	end
end

function screen_66()

	screen = screen_t
	control = control_t
	value = value_t
	
	if control==8 and value==1
	then
		if get_value(66,14) == 0
		then
			set_value(66,14,1)--���ÿؼ���ֵ
			
		if get_language() == 0--����
		then
			set_text(66,28,"12λ")
		elseif get_language() == 1--Ӣ��
		then
			set_text(66,28,"12 bit")
		end	
			
		elseif get_value(66,14) == 1
		then
			set_value(66,14,2)--���ÿؼ���ֵ
			
			if get_language() == 0--����
			then
				set_text(66,28,"14λ")
			elseif get_language() == 1--Ӣ��
			then
				set_text(66,28,"14 bit")
			end	
		elseif get_value(66,14) == 2
		then
			set_value(66,14,3)--���ÿؼ���ֵ
			
			if get_language() == 0--����
			then
				set_text(66,28,"16λ")
			elseif get_language() == 1--Ӣ��
			then
				set_text(66,28,"16 bit")
			end	
		elseif get_value(66,14) == 3
		then
			set_value(66,14,0)--���ÿؼ���ֵ	
			
			if get_language() == 0--����
			then
				set_text(66,28,"8λ")
			elseif get_language() == 1--Ӣ��
			then
				set_text(66,28,"8 bit")
			end	
		end
		return 1	
    elseif control==8 and value==0
	then
		return 1
	elseif control==7 and value==1
	then
		set_text(66,21,"1600K")
		return 1
	elseif control==7 and value==0
	then
		set_text(66,21,"800K")
		return 1
	
	--�˿�ˢ��������
	elseif control==18 and value==1
	then

		if get_text(66,19) == "3"
		then
			set_text(66,19,"4")--���ÿؼ���ֵ	
		elseif get_text(66,19) == "4"
		then
			set_text(66,19,"1")--���ÿؼ���ֵ
		elseif get_text(66,19) == "1"
		then
			set_text(66,19,"2")--���ÿؼ���ֵ
		elseif get_text(66,19) == "2"
		then
			set_text(66,19,"3")--���ÿؼ���ֵ	
		end

		return 1
	elseif control==18 and value==0
	then
		return 1
	
	--UCS7604д����
	elseif control==31 and value==1
	then
		set_text(66,32,"Setting")
	
		if get_value(66,7)==0	   then tmp_dat[7]=0x00
		elseif  get_value(66,7)==1 then tmp_dat[7]=0x01 end --����Ƶ��
		
		tmp_dat[8]=get_value(66,14)--����λ 0~3
		
		tmp_dat[9] = get_text(66,19)-1--�ֶ����� 0~3	
		
		tmp_dat[10] = get_value(66,24)--R 1~16
		tmp_dat[11] = get_value(66,25)--G 1~16	
		tmp_dat[12] = get_value(66,29)--B 1~16
		tmp_dat[13] = get_value(66,30)--W 1~16	

		Send_cmd(0xD0,0,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],tmp_dat[13])		
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n����оƬ���׵�")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nall white")
		end	
		change_screen(40)
		return 1
	elseif control==31 and value==0
	then
		return 1
	end
end

function screen_67()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==2 and value==1	--�ֶ�����
	then
		if get_value(67,39) == 0
		then
			set_value(67,39,1)--���ÿؼ���ֵ

			if get_language() == 0--����
			then
				set_text(67,6,"2��")	
			elseif get_language() == 1--Ӣ��
			then
				set_text(67,6,"Level 2")	
			end		
		elseif get_value(67,39) == 1
		then
			set_value(67,39,2)--���ÿؼ���ֵ
			
			if get_language() == 0--����
			then
				set_text(67,6,"3��")	
			elseif get_language() == 1--Ӣ��
			then
				set_text(67,6,"Level 3")	
			end		
		elseif get_value(67,39) == 2
		then
			set_value(67,39,3)--���ÿؼ���ֵ
			
			if get_language() == 0--����
			then
				set_text(67,6,"4��")	
			elseif get_language() == 1--Ӣ��
			then
				set_text(67,6,"Level 4")	
			end		
		elseif get_value(67,39) == 3
		then
			set_value(67,39,0)--���ÿؼ���ֵ	
			
			if get_language() == 0--����
			then
				set_text(67,6,"1��")	
			elseif get_language() == 1--Ӣ��
			then
				set_text(67,6,"Level 1")	
			end		
		end
		return 1
	elseif control==2 and value==0
	then
		return 1	
	elseif control==7 and value==1
	then
	
		if get_language() == 0--����
		then
			set_text(67,16,"������")	
		elseif get_language() == 1--Ӣ��
		then
			set_text(67,16,"Reverse polarity")	
		end		
			
		return 1	
	elseif control==7 and value==0
	then
	    if get_language() == 0--����
		then
			set_text(67,16,"������")	
		elseif get_language() == 1--Ӣ��
		then
			set_text(67,16,"Positive polarity")	
		end	
		return 1
    elseif control==10 and value==1	--�ֶ�����
	then
		if get_value(67,40) == 0
		then
			set_value(67,40,1)--���ÿؼ���ֵ
			set_text(67,18,"1KHz")
		elseif get_value(67,40) == 1
		then
			set_value(67,40,2)--���ÿؼ���ֵ
			set_text(67,18,"4KHz")	
		elseif get_value(67,40) == 2
		then
			set_value(67,40,3)--���ÿؼ���ֵ
		    set_text(67,18,"8KHz")	
		elseif get_value(67,40) == 3
		then
			set_value(67,40,0)--���ÿؼ���ֵ	
			set_text(67,18,"240Hz")	
		end
		return 1
	elseif control==10 and value==0
	then
		return 1
    elseif control==11 and value==1	--�ֶ�����
	then
		if get_value(67,43) == 0
		then
			set_value(67,43,1)--���ÿؼ���ֵ
			set_text(67,19,"3.8KHz")
		elseif get_value(67,43) == 1
		then
			set_value(67,43,2)--���ÿؼ���ֵ
			set_text(67,19,"7.9KHz")	
		elseif get_value(67,43) == 2
		then
			set_value(67,43,3)--���ÿؼ���ֵ
		    set_text(67,19,"15.8KHz")	
		elseif get_value(67,43) == 3
		then
			set_value(67,43,0)--���ÿؼ���ֵ	
			set_text(67,19,"1.9KHz")	
		end
		return 1
	elseif control==11 and value==0
	then
		return 1
    elseif control==12 and value==1 or control==22 and value==1	--�ֶ�����
	then
	    GS_canshu =  get_value(67,44)
		
		if control == 12  then  if GS_canshu > 0	then  GS_canshu = GS_canshu - 1  end
		elseif control == 22 then if GS_canshu < 31	then  GS_canshu = GS_canshu + 1  end   end
	 
		set_value(67,44,GS_canshu)
		
	    if GS_canshu == 0 then set_text(67,20,"0ns")
		elseif GS_canshu == 1 then set_text(67,20,"60ns")
		elseif GS_canshu == 2 then set_text(67,20,"120ns")
		elseif GS_canshu == 3 then set_text(67,20,"180ns")
		elseif GS_canshu == 4 then set_text(67,20,"240ns")
		elseif GS_canshu == 5 then set_text(67,20,"300ns")
		elseif GS_canshu == 6 then set_text(67,20,"360ns")
		elseif GS_canshu == 7 then set_text(67,20,"420ns")
		elseif GS_canshu == 8 then set_text(67,20,"480ns")
		elseif GS_canshu == 9 then set_text(67,20,"540ns")
		elseif GS_canshu == 10 then set_text(67,20,"600ns")
		elseif GS_canshu == 11 then set_text(67,20,"660ns")
		elseif GS_canshu == 12 then set_text(67,20,"720ns")
		elseif GS_canshu == 13 then set_text(67,20,"780ns")
		elseif GS_canshu == 14 then set_text(67,20,"840ns")
		elseif GS_canshu == 15 then set_text(67,20,"900ns")
		elseif GS_canshu == 16 then set_text(67,20,"960ns") 
		elseif GS_canshu == 17 then set_text(67,20,"1020ns")
		elseif GS_canshu == 18 then set_text(67,20,"1080ns")
		elseif GS_canshu == 19 then set_text(67,20,"1140ns")
		elseif GS_canshu == 20 then set_text(67,20,"1200ns")
		elseif GS_canshu == 21 then set_text(67,20,"1260ns")
		elseif GS_canshu == 22 then set_text(67,20,"1320ns")
		elseif GS_canshu == 23 then set_text(67,20,"1380ns")
		elseif GS_canshu == 24 then set_text(67,20,"1440ns")
		elseif GS_canshu == 25 then set_text(67,20,"1500ns")
		elseif GS_canshu == 26 then set_text(67,20,"1560ns")
		elseif GS_canshu == 27 then set_text(67,20,"1620ns")
		elseif GS_canshu == 28 then set_text(67,20,"1680ns")
		elseif GS_canshu == 29 then set_text(67,20,"1740ns")
		elseif GS_canshu == 30 then set_text(67,20,"1800ns")
		elseif GS_canshu == 31 then set_text(67,20,"1860ns")end
		return 1
	elseif control==12  and value==0 or control==22 and value==0
	then
		return 1
    elseif control==24  and value==1 or control==28 and value==1	--�ֶ�����
	then
	    GS_canshu =  get_value(67,45)
		
		if control == 24  then  if GS_canshu > 0	then  GS_canshu = GS_canshu - 1  end
		elseif control == 28 then if GS_canshu < 15	then  GS_canshu = GS_canshu + 1  end   end
	 
		set_value(67,45,GS_canshu)
		
	    if GS_canshu == 0 then set_text(67,26,"6.25%")
		elseif GS_canshu == 1 then set_text(67,26,"12.5%")
		elseif GS_canshu == 2 then set_text(67,26,"18.75%")
		elseif GS_canshu == 3 then set_text(67,26,"25%")
		elseif GS_canshu == 4 then set_text(67,26,"31.25%")
		elseif GS_canshu == 5 then set_text(67,26,"37.5%")
		elseif GS_canshu == 6 then set_text(67,26,"43.75%")
		elseif GS_canshu == 7 then set_text(67,26,"50%")
		elseif GS_canshu == 8 then set_text(67,26,"56.25%")
		elseif GS_canshu == 9 then set_text(67,26,"62.5%")
		elseif GS_canshu == 10 then set_text(67,26,"68.75%")
		elseif GS_canshu == 11 then set_text(67,26,"75%")
		elseif GS_canshu == 12 then set_text(67,26,"81.25%")
		elseif GS_canshu == 13 then set_text(67,26,"87.5%")
		elseif GS_canshu == 14 then set_text(67,26,"93.75%")
		elseif GS_canshu == 15 then set_text(67,26,"100%") end
		return 1
	elseif control==24  and value==0 or control==28 and value==0
	then
		return 1		
	--PWM����
	elseif control==13 and value==1
	then
		set_text(67,15,"Setting")
		
		tmp_dat[7] = get_value(67,39) --�Ҷ�ƽ��Ч��
		tmp_dat[8] = get_value(67,7) --PWM�������
		tmp_dat[9] = get_value(67,40) --���ˢ����
		tmp_dat[10] = get_value(67,43) --���ˢ����
		tmp_dat[11] = get_value(67,44) --��������

		Send_cmd(0xD2,0,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],0,0,0)		
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")
		end
		
		change_screen(40)

		return 1	
	elseif control==13 and value==0
	then
		return 1		
	elseif control==37 and value==1	--RGBW - ������������
	then	
        set_text(67,38,"Setting")
		
		tmp_dat[7] = get_value(67,45) --RGBW ����

		Send_cmd(0xD3,0,tmp_dat[7],0,0,0,0,0,0,0)		
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ�����")
		elseif get_language() == 1--Ӣ��
		then	
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother cyan")
		end
		
		change_screen(40)
		return 1
	elseif control==37 and value==0
	then	
		return 1
	elseif control==33 and value==1 --�л�����һ������
	then
		set_text(61,27,"GS8525")		
		change_screen(61)
		return 1
	elseif control==33 and value==0
	then
		return 1	
	end
end

function screen_68()
	screen = screen_t
	control = control_t
	value = value_t
	if control==1 and value==1
	then
	    change_screen(30)
		return 1
	elseif control==1 and value==0
	then
		return 1
	
	elseif control==13 and value==1
	then
		set_text(68,15,"Setting")

		tmp_dat[6] = 0x00--оƬ��Ŀ Ĭ��512
		tmp_dat[7] = 0x02
		
		local ch_num = get_value(68,6)
		if ch_num==1 
		then
			tmp_dat[8] = 0x00
		elseif ch_num==2
		then
			tmp_dat[8] = 0x80
		elseif ch_num==3 
		then
			tmp_dat[8] = 0x40
		elseif ch_num==4 
		then
			tmp_dat[8] = 0xC0
		else
			tmp_dat[8] = 0xC0
		end	
		
		local no_singal = get_value(68,7)
		if no_singal ==0
		then
			tmp_dat[9] = 0x00
		elseif no_singal ==1
		then
			tmp_dat[9] = 0x02
		else
			tmp_dat[9] = 0x02
		end

		tmp_dat[10] = get_value(68,9)--R�Ҷ�ֵ
		tmp_dat[11] = get_value(68,10)--G�Ҷ�ֵ
		tmp_dat[12] = get_value(68,11)--B�Ҷ�ֵ
		tmp_dat[13] = get_value(68,12)--W�Ҷ�ֵ

		tmp_dat[14] = get_value(68,33)*16 + get_value(68,32) --RG����
		tmp_dat[15] = get_value(68,35)*16 + get_value(68,34) --BW����

		Send_param_cmd(0x3F,0,tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],tmp_dat[13],tmp_dat[14],tmp_dat[15],0,0)
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
	
		if get_language() == 0--����
		then
		    if(get_value(68,7)==1)
			then
			    set_text(40,2,"д�����ɹ���,\r\n����оƬ������,\r\n���������оƬ��ʾ�ϵ�����Ч��")
			else
			   set_text(40,2,"д�����ɹ���,\r\n����оƬ������,\r\n���������оƬ��ʾ��ɫ")
			end
		elseif get_language() == 1--Ӣ��
		then
			if(get_value(68,7)==1)
			then
			    set_text(40,2,"Write ok,\r\nall blue,\r\nall light power on light status")	
			else
			   set_text(40,2,"Write ok,\r\nfirst blue,\r\nother black")	
			end
		end

		change_screen(40)
		
		return 1	
	elseif control==13 and value==0
	then
		return 1		

	--����д�����
	elseif control==17 and value==1
	then
		set_text(3,8,get_text(68,5))		
		change_screen(3)
		
		DMX_add_param = 0x33
		
		return 1
	elseif control==17 and value==0
	then
		return 1	
	--����ͨ����
	elseif control==2 and value==1
	then
		if get_value(68,6) == 1
		then
			set_value(68,6,2)--���ÿؼ���ֵ	
		elseif get_value(68,6) == 2
		then
			set_value(68,6,3)--���ÿؼ���ֵ
		elseif get_value(68,6) == 3
		then
			set_value(68,6,4)--���ÿؼ���ֵ
		elseif get_value(68,6) == 4
		then
			set_value(68,6,1)--���ÿؼ���ֵ	
		end
		return 1
	elseif control==2 and value==0
	then
		return 1
	-- 5,7,16
	elseif control==7 and value==1
	then	
		if get_language() == 0
		then
			set_text(68,16,"�ϵ�����Ч��")
		elseif get_language() == 1
		then
			set_text(68,16,"Restore light status")
		end
		return 1
	elseif control==7 and value==0
	then
		if get_language() == 0
		then
			set_text(68,16,"���")
		elseif get_language() == 1
		then
			set_text(68,16,"Save last frame")
		end
		return 1	
	end
end

function screen_69()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control == 11 and value == 1
	then
		qh_chip = 0x33
		change_screen(29)
		return 1
	elseif control == 11 and value ==0
	then
		return 1
	elseif control == 14 and value == 1
	then
		qh_chip = 0
		change_screen(2)
		return 1
	elseif control == 14 and value == 0
	then
		return 1
	end	
	
	if control == 13 and value == 1
	then
		set_value(4,3,get_value(69,10))
		set_value(4,7,0)
		
		change_screen(4)
		return 1
	elseif control == 13 and value ==0
	then
		return 1
	end
			
	if control==19 
	then
		set_value(69,19,1)
		set_value(69,20,0)
		return 1
	elseif control==20
	then
		set_value(69,19,0)
		set_value(69,20,1)
		return 1
	--����дַ����	
	--��ʼͨ��
	elseif control==4 and value==1
	then
		start_ch = get_value(69,9) 
		if start_ch >1 
		then
			start_ch = start_ch - 1--�ı�ؼ���ֵ 
		end	 
		set_value(69,9,start_ch)--���ÿؼ���ֵ		
		return 1
	elseif control==4 and value==0
	then
		return 1
	elseif control==5 and value==1
	then
		start_ch = get_value(69,9) 
		if start_ch <4096 
		then
			start_ch = start_ch + 1--�ı�ؼ���ֵ 
		end	 
		set_value(69,9,start_ch)--���ÿؼ���ֵ		
		return 1
	elseif control==5 and value==0
	then
		return 1
		
	--���ͨ��
	elseif control==6 and value==1
	then
		jiange_ch = get_value(69,10) 
		if jiange_ch >0 
		then
			jiange_ch = jiange_ch - 1--�ı�ؼ���ֵ 
		end	 
		set_value(69,10,jiange_ch)--���ÿؼ���ֵ		
		return 1
	elseif control==6 and value==0
	then
		return 1
	elseif control==7 and value==1
	then
		jiange_ch = get_value(69,10) 
		if jiange_ch <255
		then
			jiange_ch = jiange_ch + 1--�ı�ؼ���ֵ 
		end	 
		set_value(69,10,jiange_ch)--���ÿؼ���ֵ		
		return 1
	elseif control==7 and value==0
	then
		return 1
	
	--�ظ�д��
	elseif control==21 and value==1
	then
		chongfu_ch = get_value(69,23) 
		if chongfu_ch >0
		then
			chongfu_ch = chongfu_ch - 1--�ı�ؼ���ֵ 
		end	 
		set_value(69,23,chongfu_ch)--���ÿؼ���ֵ		
		return 1
	elseif control==21 and value==0
	then
		return 1
	elseif control==22 and value==1
	then
		chongfu_ch = get_value(69,23) 
		if chongfu_ch <2047
		then
			chongfu_ch = chongfu_ch + 1--�ı�ؼ���ֵ 
		end	 
		set_value(69,23,chongfu_ch)--���ÿؼ���ֵ		
		return 1
	elseif control==22 and value==0
	then
		return 1

	--д��
	elseif control==12 and value==1
	then
		if get_language() == 0--����
		then
			set_text(69,2,"����дַ")
		elseif get_language() == 1--Ӣ��
		then
			set_text(69,2,"Writing")
		end
			
		--����дַ����
		local write_addr={}  
	
		write_addr[0] = 0xc3

		write_addr[1] = 0xff --UID
		write_addr[2] = 0xff	
		write_addr[3] = 0xff	
		write_addr[4] = 0xff	
		
		write_addr[5] = 0xc6 --������

		start_ch = get_value(69,9)
		jiange_ch = get_value(69,10)
		
		chongfu_ch = get_value(69,23)

		sel_chip = 25
		
		if get_text(69,27)=="��ͨ��дַ" and get_language() == 0 or get_text(69,27)=="   Self channel" and get_language() == 1
		then
			sel_chip = 28
		elseif get_text(69,27)=="����дַ" and get_language() == 0 or get_text(69,27)=="   Parallel write" and get_language() == 1
		then
			sel_chip = 30
		elseif get_text(69,27)=="ͳһ��ַ" and get_language() == 0 or get_text(69,27)=="   Unified addr" and get_language() == 1	
		then
			tongyi = 0x55
			chongfu_ch = 0
		end

		if get_value(69,19) == 0 and get_value(69,20) == 1 --���յ���д
		then
			start_ch = (start_ch-1)*jiange_ch + 1;
			
			write_addr[6] = 0x00	
			write_addr[7] = math.modf(start_ch/256)	
			write_addr[8] = math.modf(start_ch%256)
		else --����ͨ��д
			write_addr[6] = 0x00	
			write_addr[7] = math.modf(start_ch/256)	
			write_addr[8] = math.modf(start_ch%256)
		end
		
		--���ͨ��
		write_addr[9] = jiange_ch

		--оƬ�ͺ�
		write_addr[10] = sel_chip
		
		--�ظ�д��
		write_addr[11] = math.modf(chongfu_ch/256)	
		write_addr[12] = math.modf(chongfu_ch%256)	
		
		--ͳһ��ַ
		write_addr[13] = tongyi	

		--дַ����
		write_addr[14] = get_value(3,26) * 85

		for i=15,18 do
			write_addr[i] = 0x00
		end

		local check_sum=0	
		for i=1,17 do
			check_sum = check_sum  + write_addr[i]
		end

		check_sum = math.modf(check_sum%256)	
		check_sum = Xor(check_sum,0x39)
	
		write_addr[18] = check_sum
		write_addr[19] = 0xca	
	
		uart_send_data(write_addr) --��������
		------------------------------
		--��ʾд��󣬵ƾߵ�״̬
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		str = get_text(69,8)--�õ���ǰ��IC�ͺ�
		if str == "UCS512-KH" or str == "UCS512-KL"
		then
			DMX_Status_page = 0x55
			
			if get_text(69,27)=="����дַ" and get_language() == 0 or get_text(69,27)=="Parallel write" and get_language() == 1
			then
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��ַȫ0�����,\r\n��ַ��ȫ0���̵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nAddress all zero Red,\r\nAddress not all zero Green")		
				end
			else
				if get_language() == 0--����
				then
					set_text(40,2,"дַ�ɹ���,\r\n��оƬ���Ƶ�,\r\n����оƬ���׵�")	
				elseif get_language() == 1--Ӣ��
				then
					set_text(40,2,"Write ok,\r\nfirst yellow,\r\nother white")	
				end
			end
			change_screen(40)
		end
		return 1
	elseif control==12 and value==0
	then
		return 1
	-----------------------------
	--�л�����Ӧ��д��������
	elseif control==17 and value==1
	then
		--set_value(4,3,get_value(3,10))
		--set_value(4,7,0)
		
		str = get_text(69,8)--�õ���ǰ��IC�ͺ�
		if str == "UCS512-KH"
		then
			set_text(53,5,"UCS512-KH")
			change_screen(53)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		elseif str == "UCS512-KL"
		then
			set_text(55,5,"UCS512-KL")
			change_screen(55)
			
			DMX_add_param = 0x55--����д�������棬�������Ҫ�Ķ�
		end
			return 1	
	elseif control==17 and value==0
	then
		return 1
	else--�˵�
		return 1
	end
end

function screen_70()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==2 and value==1	--�ֶ�����
	then
		if get_value(70,6) == 1
		then
			set_value(70,6,2)--���ÿؼ���ֵ	
		elseif get_value(70,6) == 2
		then
			set_value(70,6,3)--���ÿؼ���ֵ
		elseif get_value(70,6) == 3
		then
			if get_text(70,30) ~= "GS8523" 
			then
				set_value(70,6,4)--���ÿؼ���ֵ
			else
				set_value(70,6,1)--���ÿؼ���ֵ	
			end
		elseif get_value(70,6) == 4
		then
			set_value(70,6,1)--���ÿؼ���ֵ	
		end
		return 1
	elseif control==2 and value==0
	then
		return 1	
	elseif control==28 and value==1 --�����ֶ���
	then
		set_text(70,29,"Setting")
		
		---ͨ����
		local ch_num = get_value(70,6)
		if ch_num==1 
		then
			tmp_dat[7] = 0x02
		elseif ch_num==2
		then
			tmp_dat[7] = 0x01
		elseif ch_num==3 
		then
			tmp_dat[7] = 0x00
		elseif ch_num==4 
		then
			tmp_dat[7] = 0x03
		else
			tmp_dat[7] = 0x00
		end	

		Send_cmd(0xd4,0x00,tmp_dat[7],0,0,0,0,0,0)		
		
		stop_timer(4)
		start_timer(4,time5,1,1)

		----
		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"����д��ɹ�")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok")
		end
		
		change_screen(40)
		
		return 1	
	elseif control==28 and value==0
	then
		return 1		
	elseif control==24 and value==1	--R ����
	then
		if get_value(70,46) == 0
		then
			set_value(70,46,1)--���ÿؼ���ֵ	
			set_text(70,26,"6.1mA")
		elseif get_value(70,46) == 1
		then
			set_value(70,46,2)--���ÿؼ���ֵ
			set_text(70,26,"7.6mA")
		elseif get_value(70,46) == 2
		then
			set_value(70,46,3)--���ÿؼ���ֵ
			set_text(70,26,"9.1mA")
		elseif get_value(70,46) == 3
		then
			set_value(70,46,4)--���ÿؼ���ֵ
			set_text(70,26,"10.5mA")
        elseif get_value(70,46) == 4
		then
			set_value(70,46,5)--���ÿؼ���ֵ
			set_text(70,26,"11.9mA")
        elseif get_value(70,46) == 5
		then
			set_value(70,46,6)--���ÿؼ���ֵ	
            set_text(70,26,"13.5mA")		
        elseif get_value(70,46) == 6
		then
			set_value(70,46,7)--���ÿؼ���ֵ	
            set_text(70,26,"15mA")	
        elseif get_value(70,46) == 7
		then
			set_value(70,46,8)--���ÿؼ���ֵ	
            set_text(70,26,"16.3mA")	
        elseif get_value(70,46) == 8
		then
			set_value(70,46,9)--���ÿؼ���ֵ	
            set_text(70,26,"17.8mA")	
        elseif get_value(70,46) == 9
		then
			set_value(70,46,10)--���ÿؼ���ֵ	
            set_text(70,26,"19.3mA")	
        elseif get_value(70,46) == 10
		then
			set_value(70,46,11)--���ÿؼ���ֵ	
            set_text(70,26,"20.8mA")	
        elseif get_value(70,46) == 11
		then
			set_value(70,46,12)--���ÿؼ���ֵ	
            set_text(70,26,"22.1mA")	
        elseif get_value(70,46) == 12
		then
			set_value(70,46,13)--���ÿؼ���ֵ	
            set_text(70,26,"23.6mA")	
        elseif get_value(70,46) == 13
		then
			set_value(70,46,14)--���ÿؼ���ֵ	
            set_text(70,26,"25.1mA")	
        elseif get_value(70,46) == 14
		then
			set_value(70,46,15)--���ÿؼ���ֵ	
            set_text(70,26,"26.5mA")	
		 elseif get_value(70,46) == 15
		then
			set_value(70,46,0)--���ÿؼ���ֵ	
            set_text(70,26,"4.6mA")		
		end
		return 1
	elseif control==24 and value==0
	then
		return 1
	elseif control==31 and value==1	--G ����
	then
		if get_value(70,47) == 0
		then
			set_value(70,47,1)--���ÿؼ���ֵ	
			set_text(70,32,"6.1mA")
		elseif get_value(70,47) == 1
		then
			set_value(70,47,2)--���ÿؼ���ֵ
			set_text(70,32,"7.6mA")
		elseif get_value(70,47) == 2
		then
			set_value(70,47,3)--���ÿؼ���ֵ
			set_text(70,32,"9.1mA")
		elseif get_value(70,47) == 3
		then
			set_value(70,47,4)--���ÿؼ���ֵ
			set_text(70,32,"10.5mA")
        elseif get_value(70,47) == 4
		then
			set_value(70,47,5)--���ÿؼ���ֵ
			set_text(70,32,"11.9mA")
        elseif get_value(70,47) == 5
		then
			set_value(70,47,6)--���ÿؼ���ֵ	
            set_text(70,32,"13.5mA")		
        elseif get_value(70,47) == 6
		then
			set_value(70,47,7)--���ÿؼ���ֵ	
            set_text(70,32,"15mA")	
        elseif get_value(70,47) == 7
		then
			set_value(70,47,8)--���ÿؼ���ֵ	
            set_text(70,32,"16.3mA")	
        elseif get_value(70,47) == 8
		then
			set_value(70,47,9)--���ÿؼ���ֵ	
            set_text(70,32,"17.8mA")	
        elseif get_value(70,47) == 9
		then
			set_value(70,47,10)--���ÿؼ���ֵ	
            set_text(70,32,"19.3mA")	
        elseif get_value(70,47) == 10
		then
			set_value(70,47,11)--���ÿؼ���ֵ	
            set_text(70,32,"20.8mA")	
        elseif get_value(70,47) == 11
		then
			set_value(70,47,12)--���ÿؼ���ֵ	
            set_text(70,32,"22.1mA")	
        elseif get_value(70,47) == 12
		then
			set_value(70,47,13)--���ÿؼ���ֵ	
            set_text(70,32,"23.6mA")	
        elseif get_value(70,47) == 13
		then
			set_value(70,47,14)--���ÿؼ���ֵ	
            set_text(70,32,"25.1mA")	
        elseif get_value(70,47) == 14
		then
			set_value(70,47,15)--���ÿؼ���ֵ	
            set_text(70,32,"26.5mA")	
	    elseif get_value(70,47) == 15
		then
			set_value(70,47,0)--���ÿؼ���ֵ	
            set_text(70,32,"4.6mA")
		end
		return 1
	elseif control==31 and value==0
	then
		return 1
	elseif control==33 and value==1	--B ����
	then
		if get_value(70,48) == 0
		then
			set_value(70,48,1)--���ÿؼ���ֵ	
			set_text(70,34,"6.1mA")
		elseif get_value(70,48) == 1
		then
			set_value(70,48,2)--���ÿؼ���ֵ
			set_text(70,34,"7.6mA")
		elseif get_value(70,48) == 2
		then
			set_value(70,48,3)--���ÿؼ���ֵ
			set_text(70,34,"9.1mA")
		elseif get_value(70,48) == 3
		then
			set_value(70,48,4)--���ÿؼ���ֵ
			set_text(70,34,"10.5mA")
        elseif get_value(70,48) == 4
		then
			set_value(70,48,5)--���ÿؼ���ֵ
			set_text(70,34,"11.9mA")
        elseif get_value(70,48) == 5
		then
			set_value(70,48,6)--���ÿؼ���ֵ	
            set_text(70,34,"13.5mA")		
        elseif get_value(70,48) == 6
		then
			set_value(70,48,7)--���ÿؼ���ֵ	
            set_text(70,34,"15mA")	
        elseif get_value(70,48) == 7
		then
			set_value(70,48,8)--���ÿؼ���ֵ	
            set_text(70,34,"16.3mA")	
        elseif get_value(70,48) == 8
		then
			set_value(70,48,9)--���ÿؼ���ֵ	
            set_text(70,34,"17.8mA")	
        elseif get_value(70,48) == 9
		then
			set_value(70,48,10)--���ÿؼ���ֵ	
            set_text(70,34,"19.3mA")	
        elseif get_value(70,48) == 10
		then
			set_value(70,48,11)--���ÿؼ���ֵ	
            set_text(70,34,"20.8mA")	
        elseif get_value(70,48) == 11
		then
			set_value(70,48,12)--���ÿؼ���ֵ	
            set_text(70,34,"22.1mA")	
        elseif get_value(70,48) == 12
		then
			set_value(70,48,13)--���ÿؼ���ֵ	
            set_text(70,34,"23.6mA")	
        elseif get_value(70,48) == 13
		then
			set_value(70,48,14)--���ÿؼ���ֵ	
            set_text(70,34,"25.1mA")	
        elseif get_value(70,48) == 14
		then
			set_value(70,48,15)--���ÿؼ���ֵ	
            set_text(70,34,"26.5mA")	
        elseif get_value(70,48) == 15
		then
			set_value(70,48,0)--���ÿؼ���ֵ	
            set_text(70,34,"4.6mA")
		end
		return 1
	elseif control==33 and value==0
	then
		return 1
	elseif control==35 and value==1	--w ����
	then
		if get_value(70,49) == 0
		then
			set_value(70,49,1)--���ÿؼ���ֵ	
			set_text(70,36,"6.1mA")
		elseif get_value(70,49) == 1
		then
			set_value(70,49,2)--���ÿؼ���ֵ
			set_text(70,36,"7.6mA")
		elseif get_value(70,49) == 2
		then
			set_value(70,49,3)--���ÿؼ���ֵ
			set_text(70,36,"9.1mA")
		elseif get_value(70,49) == 3
		then
			set_value(70,49,4)--���ÿؼ���ֵ
			set_text(70,36,"10.5mA")
        elseif get_value(70,49) == 4
		then
			set_value(70,49,5)--���ÿؼ���ֵ
			set_text(70,36,"11.9mA")
        elseif get_value(70,49) == 5
		then
			set_value(70,49,6)--���ÿؼ���ֵ	
            set_text(70,36,"13.5mA")		
        elseif get_value(70,49) == 6
		then
			set_value(70,49,7)--���ÿؼ���ֵ	
            set_text(70,36,"15mA")	
        elseif get_value(70,49) == 7
		then
			set_value(70,49,8)--���ÿؼ���ֵ	
            set_text(70,36,"16.3mA")	
        elseif get_value(70,49) == 8
		then
			set_value(70,49,9)--���ÿؼ���ֵ	
            set_text(70,36,"17.8mA")	
        elseif get_value(70,49) == 9
		then
			set_value(70,49,10)--���ÿؼ���ֵ	
            set_text(70,36,"19.3mA")	
        elseif get_value(70,49) == 10
		then
			set_value(70,49,11)--���ÿؼ���ֵ	
            set_text(70,36,"20.8mA")	
        elseif get_value(70,49) == 11
		then
			set_value(70,49,12)--���ÿؼ���ֵ	
            set_text(70,36,"22.1mA")	
        elseif get_value(70,49) == 12
		then
			set_value(70,49,13)--���ÿؼ���ֵ	
            set_text(70,36,"23.6mA")	
        elseif get_value(70,49) == 13
		then
			set_value(70,49,14)--���ÿؼ���ֵ	
            set_text(70,36,"25.1mA")	
        elseif get_value(70,49) == 14
		then
			set_value(70,49,15)--���ÿؼ���ֵ	
            set_text(70,36,"26.5mA")
		elseif get_value(70,49) == 15
		then
			set_value(70,49,0)--���ÿؼ���ֵ
            set_text(70,36,"4.6mA")				
		end
		return 1
	elseif control==35 and value==0
	then
		return 1
	elseif control==37 and value==1	--����RGBW����
	then
		set_text(70,38,"Setting")
		
		tmp_dat[7] = get_value(70,49) * 16 + get_value(70,48)
		tmp_dat[8] = get_value(70,47) * 16 + get_value(70,46)
	
		Send_cmd(0xd4,0x01,tmp_dat[7],tmp_dat[8],0,0,0,0,0)
		
		stop_timer(4)
		start_timer(4,time5,1,1)

		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"����д��ɹ�")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok")
		end
		
		change_screen(40)
		return 1
	elseif control==37 and value==0
	then
		return 1
	elseif control==1
	then
		return 1
	elseif control==5
	then
		return 1
	elseif control==19 and value==1	--�����ϵ�����״̬
	then
		set_text(70,20,"Setting")
		
		tmp_dat[7] = get_value(70,1) 
		tmp_dat[8] = get_value(70,5) 
		
		tmp_dat[9] = get_value(70,12)
		tmp_dat[10] = get_value(70,14)
		tmp_dat[11] = get_value(70,16)
		tmp_dat[12] = get_value(70,18)

		Send_cmd(0xd4,0x02,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],0)		
		
		stop_timer(4)
		start_timer(4,time5,1,1)

		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"����д��ɹ�")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok")
		end
		
		change_screen(40)
		return 1
	elseif control==19 and value==0
	then
		return 1
	elseif control==13
	then
		return 1
	elseif control==17
	then
		return 1
	elseif control==22 and value==1
	then
		set_text(70,21,"Setting")
		
		tmp_dat[7] = get_value(70,13) * 32 + get_value(70,17) * 16

		Send_cmd(0xd4,0x03,tmp_dat[7],0,0,0,0,0,0)	

		stop_timer(4)
		start_timer(4,time5,1,1)

		DMX_Status_page = 0x55
			
		if get_language() == 0--����
		then
			set_text(40,2,"����д��ɹ�")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok")
		end
	
		change_screen(40)
		
		return 1	
	elseif control==22 and value==0
	then
		return 1
	--�л���д�����
	elseif control==41 and value==1 --�л���д�����
	then
		if get_value(0,12) == 0--����Ч��
		then
			Send_cmd(0xc1,0x55,0,0,0,0,0,0,0)	
		else
			Send_cmd(0xa1,0x55,0,0,0,0,0,0,0)	
		end
		
		set_text(3,8,get_text(70,30))			
		change_screen(3)
		
		for i=0,100 do
		end
		
		Send_cmd(0xd4,0xAA,0,0,0,0,0,0,0)
		
		DMX_add_param = 0x33
		return 1
	elseif control==41 and value==0
	then
		return 1
	elseif control==7 and value==1 --�л�����һ������
	then
		if get_value(0,12) == 0--����Ч��
		then
			Send_cmd(0xc1,0x55,0,0,0,0,0,0,0)	
		else
			Send_cmd(0xa1,0x55,0,0,0,0,0,0,0)	
		end
		
		change_screen(2)
		return 1
	elseif control==7 and value==0
	then
		return 1
	elseif control==9 and value==1 --�л�����һ������
	then
		if get_value(0,12) == 0--����Ч��
		then
			Send_cmd(0xc1,0x55,0,0,0,0,0,0,0)	
		else
			Send_cmd(0xa1,0x55,0,0,0,0,0,0,0)	
		end
		change_screen(34)
		return 1
	elseif control==9 and value==0
	then
		return 1	
	elseif control==25
	then
		set_text(71,30,get_text(70,30))			
		change_screen(71)
		return 1	
	end
end

function screen_71()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==11 and value==1	--�ֶ����ü�
	then
		if get_value(71,12) == 4
		then
			set_value(71,12,3)--���ÿؼ���ֵ	
		elseif get_value(71,12) == 3
		then
			set_value(71,12,2)--���ÿؼ���ֵ
		elseif get_value(71,12) == 2
		then
			set_value(71,12,1)--���ÿؼ���ֵ
		elseif get_value(71,12) == 1
		then
			set_value(71,12,1)--���ÿؼ���ֵ	
		end
		
		if get_value(71,24) == 1
		then
			GS_test()
		end
		return 1
	elseif control==11 and value==0
	then
		return 1	
	elseif control==6 and value==1	--�ֶ����ü�
	then
		if get_value(71,12) == 1
		then
			set_value(71,12,2)--���ÿؼ���ֵ	
		elseif get_value(71,12) == 2
		then
			set_value(71,12,3)--���ÿؼ���ֵ
		elseif get_value(71,12) == 3
		then
			set_value(71,12,4)--���ÿؼ���ֵ
		elseif get_value(71,12) == 4
		then
			set_value(71,12,4)--���ÿؼ���ֵ	
		end
		
		if get_value(71,24) == 1
		then
			GS_test()
		end
		return 1
	elseif control==6 and value==0
	then
		return 1
	elseif control==7 and value==1 or control==9 and value==1--����Ч��
	then
		local caidan = get_value(71,50)
		
		if control==7 
		then
			if caidan > 0 then  caidan = caidan - 1 end
		elseif control==9
		then
			if caidan < 5 then  caidan = caidan + 1 end
		end
		
		set_value(71,50,caidan)
		
		if caidan == 0
		then
			if get_language() == 0--����
			then
				set_text(71,15,"�������׺�����")
			
			elseif get_language() == 1--Ӣ��
			then	
				set_text(71,15,"R-G-B-W jump")
			end
		elseif caidan == 1
		then
			if get_language() == 0--����
			then
				set_text(71,15,"��ɫ����")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(71,15," Red ripple")
			end
		elseif caidan == 2
		then
			if get_language() == 0--����
			then
				set_text(71,15,"��ɫ����")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(71,15,"Green ripple")
			end
		elseif caidan == 3
		then
			if get_language() == 0--����
			then
				set_text(71,15,"��ɫ����")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(71,15,"Blue ripple")
			end
		elseif caidan == 4
		then
			if get_language() == 0--����
			then
				set_text(71,15,"��ɫ����")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(71,15,"White ripple")
			end
		elseif caidan == 5
		then
			if get_language() == 0--����
			then
				set_text(71,15,"����")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(71,15,"ALL bright")
			end
		end
		if get_value(71,24) == 1
		then
			GS_test()
		end
		return 1
	elseif control==7 and value==0 or  control==9 and value==0
	then
		return 1
	elseif control==14 and value==1	--Ƶ�����ü�
	then
		if get_text(71,18) == "500K"
		then
			set_text(71,18,"400K")	
		elseif get_text(71,18) == "400K"
		then
			set_text(71,18,"250K")	
		elseif get_text(71,18) == "250K"
		then
			set_text(71,18,"250K")	
		end
		if get_value(71,24) == 1
		then
			GS_test()
		end
		return 1
	elseif control==14 and value==0
	then
		return 1	
	elseif control==17 and value==1	--Ƶ�����ü�
	then
		if get_text(71,18) == "250K"
		then
			set_text(71,18,"400K")	
		elseif get_text(71,18) == "400K"
		then
			set_text(71,18,"500K")	
		elseif get_text(71,18) == "500K"
		then
			set_text(71,18,"500K")	
		end
		if get_value(71,24) == 1
		then
			GS_test()
		end
		return 1
	elseif control==17 and value==0
	then
		return 1
	elseif control==22 and value==1	--�����ٶȼ�
	then
		if get_value(71,23) == 7
		then
			set_value(71,23,6)	
		elseif get_value(71,23) == 6
		then
			set_value(71,23,5)	
		elseif get_value(71,23) == 5
		then
			set_value(71,23,4)	
		elseif get_value(71,23) == 4
		then
			set_value(71,23,3)	
		elseif get_value(71,23) == 3
		then
			set_value(71,23,2)	
		elseif get_value(71,23) == 2
		then
			set_value(71,23,1)
		elseif get_value(71,23) == 1
		then
			set_value(71,23,1)	
		end
		if get_value(71,24) == 1
		then
			GS_test()
		end
		return 1
	elseif control==22 and value==0 
	then
		return 1
	elseif control==27 and value==1	--�����ٶȼ�
	then
		if get_value(71,23) == 1
		then
			set_value(71,23,2)	
		elseif get_value(71,23) == 2
		then
			set_value(71,23,3)	
		elseif get_value(71,23) == 3
		then
			set_value(71,23,4)	
		elseif get_value(71,23) == 4
		then
			set_value(71,23,5)	
		elseif get_value(71,23) == 5
		then
			set_value(71,23,6)	
		elseif get_value(71,23) == 6
		then
			set_value(71,23,7)
		elseif get_value(71,23) == 7
		then
			set_value(71,23,7)	
		end
		if get_value(71,24) == 1
		then
			GS_test()
		end
		return 1
	elseif control==27 and value==0
	then
		return 1
	elseif control==24 and value==1
	then
		GS_test()
		return 1
	elseif control==24 and value==0
	then
		tmp_dat[7] = get_value(71,1) * 128 + get_value(71,5) * 32 + get_value(71,3) * 16
		Send_cmd(0xd4,0x05,tmp_dat[7],0,0,0,0,0,0)
		return 1
	elseif control==26 and value==1 --�л�����һ������
	then
		if get_value(71,24) == 1
		then
			Send_cmd(0xd4,0x05,0,0,0,0,0,0,0)
		
			change_screen(70)
			 
			set_value(71,24,0)
		else
			Send_cmd(0xd4,0x07,0,0,0,0,0,0,0)
			
			change_screen(70)
			
			set_value(71,24,0)
		end
		return 1
	elseif control==26 and value==0
	then
		return 1	
	end
end

function screen_72()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==1 and value==1	--����ͨ����
	then
		if get_value(72,7) == 1
		then
			set_value(72,7,2)--���ÿؼ���ֵ	
		elseif get_value(72,7) == 2
		then
			set_value(72,7,3)--���ÿؼ���ֵ	
		elseif get_value(72,7) == 3
		then
			set_value(72,7,4)--���ÿؼ���ֵ
		elseif get_value(72,7) == 4
		then
			set_value(72,7,1)--���ÿؼ���ֵ
		end
		return 1
	elseif control==1 and value==0
	then
		return 1	
	elseif control==2 and value==1--���õͻҲ���
	then
		if get_value(72,14) == 0
		then
			set_value(72,14,1)--���ÿؼ���ֵ
			set_text(72,9,"3T")
		elseif get_value(72,14) == 1
		then
			set_value(72,14,2)--���ÿؼ���ֵ
			set_text(72,9,"9T")
		elseif get_value(72,14) == 2
		then
			set_value(72,14,3)--���ÿؼ���ֵ
			set_text(72,9,"18T")
		elseif get_value(72,14) == 3
		then
			set_value(72,14,4)--���ÿؼ���ֵ
			set_text(72,9,"27T")
		elseif get_value(72,14) == 4
		then
			set_value(72,14,0)--���ÿؼ���ֵ
			if get_language() == 0--����
			then
				set_text(72,9,"�ͻҲ����ر�")
			elseif get_language() == 1--Ӣ��
			then
				set_text(72,9,"Close")
			end	
		end
		return 1	
	elseif control==2 and value==0
	then
		return 1		
	elseif control==5 and value==1--����2S���ź���ʾ
	then
		return 1	
	elseif control==5 and value==0
	then
		return 1
	elseif control==22 and value==1	--OUT W�˿�3������
	then
		return 1
	elseif control==22 and value==0
	then
		return 1	
	elseif control==37 and value==1	--�ͻ���Ƶ��
	then
		return 1	
	elseif control==37 and value==0
	then
		return 1
	elseif control==16 and value==1	--ȥдַ
	then
		set_text(3,8,"SM522")		
		change_screen(3)
		
		DMX_add_param = 0x33
		return 1	
	elseif control==16 and value==0
	then
		return 1
	elseif control==27 and value==1	--���ź�״̬���ϵ�Ҷ�����
	then
		set_text(72,19,"Setting")
		
		tmp_dat[7] = get_value(72,24)	--R�ϵ�Ч��
		tmp_dat[8] = get_value(72,25)	--G�ϵ�Ч��
		tmp_dat[9] = get_value(72,29)	--B�ϵ�Ч��
		tmp_dat[10] = get_value(72,30)	--W�ϵ�Ч��
		
		tmp_dat[11] = get_value(72,14) * 4 + (get_value(72,7)-1) * 32 +  get_value(72,37) * 128	--�ͻҲ�����ͨ�������ͻ���Ƶ��
		
		tmp_dat[12] = get_value(72,5) * 2 + get_value(72,22)	--OUT W 3�����������ź���ʾ	
			
		Send_param_cmd(0x40,0x01,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],0,0,0,0)
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
	
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ��ʾ�ϵ�������ɫ")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother light power on light status")	
		end	

		change_screen(40)
		return 1
	elseif control==27 and value==0	
	then
		return 1	
	elseif control==13 and value==1	--д��������
	then
		set_text(72,15,"Setting")
		
		tmp_dat[7] = get_value(72,4)	--R�ϵ�Ч��
		tmp_dat[8] = get_value(72,6)	--G�ϵ�Ч��
		tmp_dat[9] = get_value(72,10)	--B�ϵ�Ч��
		tmp_dat[10] = get_value(72,11)	--W�ϵ�Ч��
			
		Send_param_cmd(0x40,0x02,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],0,0,0,0,0,0)
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
	
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ���Ƶ�")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother yellow")
		end	

		change_screen(40)
		return 1
	elseif control==13 and value==0	
	then
		return 1		
	end
end

function screen_73()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==18 and value==1	--����ͨ����
	then
		local num = get_value(73,19)
		
		num = num + 1
		
		if num > 7
		then
			num = 0
		end
		
		set_value(73,19,num)

		for i = 1,7 do
		
			set_value(73,i+44,i)
			
			if i <= num
			then
				set_visiable(73,i+9,1)
				set_visiable(73,i+35,1)
				set_visiable(73,i+52,1)
			else
				set_visiable(73,i+9,0)
				set_visiable(73,i+35,0)
				set_visiable(73,i+52,0)
			end
			
			if num == 0
			then
				set_value(73,i+44,0)
			end
		end
		
		set_text(73,10,"R")
		set_text(73,11,"G")
		set_text(73,12,"B")
		set_text(73,13,"W")
		set_text(73,14,"X")
		set_text(73,15,"Y")
		set_text(73,16,"Z")
		
		return 1
	elseif control==18 and value==0
	then
		return 1			
	elseif control==7 and value==1	--ת��ͨ��ѡ��
	then
		return 1	
	elseif control==7 and value==0
	then
		return 1
	elseif control==8 and value==1	--ת��˳��ѡ��
	then
		return 1
	elseif control==8 and value==0
	then
		return 1	
	elseif control==6 and value==1	--�ҽ�ѡ��
	then
		return 1	
	elseif control==6 and value==0
	then
		return 1
	elseif control==21 and value==1	--ת��Э��ѡ��
	then
		return 1	
	elseif control==21 and value==0
	then
		return 1
	elseif control==22 and value==1	--ת������ѡ��
	then
		return 1	
	elseif control==22 and value==0
	then
		return 1	
	elseif control==2 and value==1	--ȥдַ
	then	
		set_text(3,8,get_text(73,5))		
		change_screen(3)
		
		DMX_add_param = 0x33
		return 1	
	elseif control==2 and value==0
	then
		return 1
	elseif control >35 and control < 43 and value == 1
	then
		local num = get_value(73,control + 9)
		
		num = num + 1
		
		if num > get_value(73,19)
		then
			num = 1
		end
		
		set_value(73,control + 9,num)
		
		if get_value(73,control + 9) == 1
		then
			set_text(73,control - 26,"R" )
		elseif get_value(73,control + 9) == 2
		then
			set_text(73,control - 26,"G" )
		elseif get_value(73,control + 9) == 3
		then
			set_text(73,control - 26,"B" )
		elseif get_value(73,control + 9) == 4
		then
			set_text(73,control - 26,"W" )
		elseif get_value(73,control + 9) == 5
		then
			set_text(73,control - 26,"X" )
		elseif get_value(73,control + 9) == 6
		then
			set_text(73,control - 26,"Y" )
		elseif get_value(73,control + 9) == 7
		then
			set_text(73,control - 26,"Z" )
		end

		return 1
	elseif control >35 and control < 43 and value == 0
	then
		return 1
	elseif control==34 and value==1	--���ź�״̬���ϵ�Ҷ�����
	then
		set_text(73,35,"Setting")
		
		--��������λ ת����ɫ				 ת��ͨ��			   ת��˳��			     �ҽ�ѡ��			   ת��Э��
		tmp_dat[7] = get_value(73,19) * 16 + get_value(73,7) * 8 + get_value(73,8) * 4 + get_value(73,6) * 2 + get_value(73,21)
		
		--ͨ������   ת������				 ת������
		tmp_dat[8] = get_value(73,22) * 32 + get_value(73,23) - 1
		
		--ͨ��1~7ת����ɫ��ͨ��1~7ת������ tmp_dat[9] ~ tmp_dat[15]
		for i = 1,7 do
			tmp_dat[i+8] = get_value(73,i+44) * 32 + get_value(73,i+52) - 1
			
			if get_value(73,19) == 0	--Ϊ0ʱ��ת��
			then
				tmp_dat[i+8] = 0
			end
		end	
			
		Send_param_cmd(0x41,0x01,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],tmp_dat[13],tmp_dat[14],tmp_dat[15],0)
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ������")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother blue")
		end	
		
		change_screen(40)
		
		return 1
	elseif control==34 and value==0	
	then
		return 1		
	end
end

function screen_74()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==18 and value==1	--����ͨ����
	then
		local num = get_value(74,33)
		
		num = num + 1
		
		if num > 3
		then
			num = 0
		end
		
		set_value(74,33,num)

		if get_value(74,33) == 0
		then
			if get_language() == 0--����
			then
				set_text(74,19,"�޵�������" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(74,19,"Close" )
			end
		elseif get_value(74,33) == 1
		then
			if get_language() == 0--����
			then
				set_text(74,19,"4bit��������λ" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(74,19,"4bit Current gain" )
			end
		elseif get_value(74,33) == 2
		then
			if get_language() == 0--����
			then
				set_text(74,19,"5bit��������λ" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(74,19,"5bit Current gain" )
			end
		elseif get_value(74,33) == 3
		then
			if get_language() == 0--����
			then
				set_text(74,19,"6bit��������λ" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(74,19,"6bitCurrent gain" )
			end
		end
		return 1
	elseif control==18 and value==0
	then
		return 1
	elseif control==8 and value==1	--��������ͨ����
	then
		local num = get_value(74,28)
		
		num = num + 1
		
		if num > 7
		then
			num = 3
		end
		
		set_value(74,28,num)
		
		return 1
	elseif control==8 and value==0
	then
		return 1
	elseif control==7 and value==1	--�������汣��λ��
	then
		local num = get_value(74,21)
		
		num = num + 1
		
		if num > 8
		then
			num = 0
		end
		
		set_value(74,21,num)
		return 1	
	elseif control==7 and value==0
	then
		return 1			
	elseif control==29 and value==1	--�������汣��λ��
	then
		return 1	
	elseif control==29 and value==0
	then
		return 1	
	elseif control==1 and value==1	--��һҳ
	then
		if get_text(74,5) == "SM18500PS" or get_text(74,5) == "SM18500PS-S"
		then
			change_screen(76)
		else
			change_screen(73)
		end
		return 1	
	elseif control==9 and value==1	--д��ͨ��
	then
		return 1	
	elseif control==9 and value==0
	then
		return 1
	elseif control==1 and value==0
	then
		return 1
	elseif control==34 and value==1	--���õ�������
	then
		set_text(74,35,"Setting")
		
		--������������ ��������λ��			 ��������ͨ����
		tmp_dat[7] = get_value(74,33) * 16 + get_value(74,28)
		
		--������������ �������汣��λ��		�������汣��λ��
		tmp_dat[8] = get_value(74,21) * 16 + get_value(74,29) * 8
		
		--������������ �������汣��λ����		
		tmp_dat[9] = get_value(74,25)
		
		--ͨ��1~7��������������  tmp_dat[10] ~ tmp_dat[16]
		for i = 1,7 do
			tmp_dat[i+9] = get_value(74,i+52)
		end	
			
		Send_param_cmd(0x41,0x02,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],tmp_dat[13],tmp_dat[14],tmp_dat[15],tmp_dat[16])	
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ���̵�")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother green")
		end	
		
		change_screen(40)
		
		return 1
	elseif control==34 and value==0	
	then
		return 1
	elseif control==6 and value==1 --�Զ�����ѡ��
	then
		local num = get_value(74,36)
		
		num = num + 1
		
		if num > 4
		then
			num = 0
		end
		
		set_value(74,36,num)

		if get_value(74,36) == 0
		then
			if get_language() == 0--����
			then
				set_text(74,22,"�׵�ַ1�Զ���ַ" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(74,22,"First address automatic addressing" )
			end
		elseif get_value(74,36) == 1
		then
			if get_language() == 0--����
			then
				set_text(74,22,"�׵�ַ�����Զ���ַ" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(74,22,"The first address remains auto addressed" )
			end
		elseif get_value(74,36) == 2
		then
			if get_language() == 0--����
			then
				set_text(74,22,"����Ӧ��ַ" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(74,22,"Adaptive address" )
			end
		elseif get_value(74,36) == 3
		then
			if get_language() == 0--����
			then
				set_text(74,22,"����Ӧ����" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(74,22,"Adaptive parameter" )
			end
		elseif get_value(74,36) == 4
		then
			if get_language() == 0--����
			then
				set_text(74,22,"�Զ����ܹر�" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(74,22,"Close" )
			end
		end
		return 1
	elseif control==6 and value==0	
	then
		return 1
	elseif control==15 and value==1	--��������дַ
	then
		set_text(74,16,"Setting")
		
		--����дַ���� ����дַ����
		if get_value(74,36) == 0
		then
			tmp_dat[7] = 0x0F
		elseif get_value(74,36) == 1
		then
			tmp_dat[7] = 0xC3
		elseif get_value(74,36) == 2
		then
			tmp_dat[7] = 0xF0
		elseif get_value(74,36) == 3
		then
			tmp_dat[7] = 0xA5
		elseif get_value(74,36) == 4
		then
			tmp_dat[7] = 0x00
		end
		
		--����дַ���� �Զ���ַ����			����Ӧ����
		tmp_dat[8] = get_value(74,10) * 16 + get_value(74,13)
		
		Send_param_cmd(0x41,0x03,tmp_dat[7],tmp_dat[8],0,0,0,0,0,0,0,0)	
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
		
		if get_language() == 0--����
		then
			set_text(40,2,"����д��ɹ�")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok")
		end	
		
		change_screen(40)
		
		return 1
	elseif control==15 and value==0	
	then
		return 1		
	end
end

function screen_75()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==18 and value==1	--����ͨ����
	then
		local num = get_value(75,15)
		
		num = num + 1
		
		if num > 2
		then
			num = 0
		end
		
		set_value(75,15,num)

		if get_value(75,15) == 0
		then
			if get_language() == 0--����
			then
				set_text(75,19,"���" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,19,"lighting-off" )
			end
		elseif get_value(75,15) == 1
		then
			if get_language() == 0--����
			then
				set_text(75,19,"��ʾ����Ч��" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,19,"Built in effect" )
			end
		elseif get_value(75,15) == 2
		then
			if get_language() == 0--����
			then
				set_text(75,19,"�ϵ�Ԥ��״̬" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,19,"preinstall" )
			end
		end
		return 1
	elseif control==18 and value==0
	then
		return 1
	elseif control==8 and value==1	--2S���ź�
	then
		return 1
	elseif control==8 and value==0
	then
		return 1
	elseif control==7 and value==1 --�ϵ�Ԥ�跢�ͼ��
	then
		local num = get_value(75,16)
		
		num = num + 1
		
		if num > 7
		then
			num = 0
		end
		
		set_value(75,16,num)

		if get_value(75,16) == 0
		then
			if get_language() == 0--����
			then
				set_text(75,21,"�ϵ�Ԥ�跢����֡���ٷ���" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,21,"Send twice by default" )
			end
		elseif get_value(75,16) == 1
		then
			if get_language() == 0--����
			then
				set_text(75,21,"���500ms������֡" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,21,"Send twice every 0.5 s" )
			end
		elseif get_value(75,16) == 2
		then
			if get_language() == 0--����
			then
				set_text(75,21,"���1S������֡" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,21,"Send twice every 1 s" )
			end
		elseif get_value(75,16) == 3
		then
			if get_language() == 0--����
			then
				set_text(75,21,"���2S������֡" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,21,"Send twice every 2 s" )
			end
		elseif get_value(75,16) == 4
		then
			if get_language() == 0--����
			then
				set_text(75,21,"���4S������֡" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,21,"Send twice every 4 s" )
			end
		elseif get_value(75,16) == 5
		then
			if get_language() == 0--����
			then
				set_text(75,21,"���8S������֡" )
			elseif get_language() == 1--Ӣ��
			then
				set_text(75,21,"Send twice every 8 s" )
			end
		elseif get_value(75,16) == 6
		then
			if get_language() == 0--����
			then
				set_text(75,21,"���16S������֡" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,21,"Send twice every 16 s" )
			end
		elseif get_value(75,16) == 7
		then
			if get_language() == 0--����
			then
				set_text(75,21,"���32S������֡" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,21,"Send twice every 32 s" )
			end
		end
		return 1		
	elseif control==7 and value==0
	then
		return 1			
	elseif control==29 and value==1	--�������汣��λ��
	then
		local num = get_value(75,28)
		
		num = num + 1
		
		if num > 3
		then
			num = 0
		end
		
		set_value(75,28,num)

		if get_value(75,28) == 0
		then
			if get_language() == 0--����
			then
				set_text(75,30,"8������" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,30,"8 pixels" )
			end
		elseif get_value(75,28) == 1
		then
			if get_language() == 0--����
			then
				set_text(75,30,"16������" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,30,"16 pixels" )
			end
		elseif get_value(75,28) == 2
		then
			if get_language() == 0--����
			then
				set_text(75,30,"32������" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,30,"32 pixels" )
			end
		elseif get_value(75,28) == 3
		then
			if get_language() == 0--����
			then
				set_text(75,30,"64������" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,30,"64 pixels" )
			end
		end
		return 1	
	elseif control==29 and value==0
	then
		return 1	
	elseif control==23 and value==1 --���ǲ�ֵ
	then
		local num = get_value(75,31)
		
		num = num + 1
		
		if num > 3
		then
			num = 0
		end
		
		set_value(75,31,num)

		if get_value(75,31) == 0
		then
			if get_language() == 0--����
			then
				set_text(75,25,"4���Ҷ�" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,25,"4 gray scale" )
			end
		elseif get_value(75,31) == 1
		then
			if get_language() == 0--����
			then
				set_text(75,25,"8���Ҷ�" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,25,"8 gray scale" )
			end
		elseif get_value(75,31) == 2
		then
			if get_language() == 0--����
			then
				set_text(75,25,"16���Ҷ�" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,25,"16 gray scale" )
			end
		elseif get_value(75,31) == 3
		then
			if get_language() == 0--����
			then
				set_text(75,25,"32���Ҷ�" )
			elseif get_language() == 1--Ӣ��
			then	
				set_text(75,25,"32 gray scale" )
			end
		end
		return 1
	elseif control==23 and value==0	
	then
		return 1
	elseif control==33 and value==1	--�߲�����
	then
		return 1
	elseif control==33 and value==0
	then
		return 1
	elseif control==36 and value==1	--ȫ�׽���
	then
		return 1
	elseif control==36 and value==0
	then
		return 1
	elseif control==37 and value==1	--��ɫ����
	then
		return 1
	elseif control==37 and value==0
	then
		return 1
	elseif control==38 and value==1	--���ǵ�
	then
		return 1
	elseif control==38 and value==0
	then
		return 1
	elseif control==22 and value==1	or  control==10 and value==1	--�߲������ٶ�
	then
		local num = get_value(75,32)
		
		if control == 10 -- ��
		then
			if num > 0
			then
				num = num - 1	--ʱ��Խ���ٶ�Խ��
			end
		elseif control == 22 --��
		then
			if num < 3
			then
				num = num + 1	--ʱ��Խ���ٶ�Խ��
			end
		end
		
		set_value(75,32,num)

		if get_value(75,32) == 0
		then
			set_text(75,9,"48S" )
		elseif get_value(75,32) == 1
		then
			set_text(75,9,"24S" )
		elseif get_value(75,32) == 2
		then
			set_text(75,9,"12S" )
		elseif get_value(75,32) == 3
		then
			set_text(75,9,"6S" )
		end
		return 1
	elseif control==22 and value==0	or  control==10 and value==0
	then
		return 1
	elseif control==3 and value==1	or  control==11 and value==1 --ȫ�׽����ٶ�
	then
		local num = get_value(75,42)
		
		if control == 11 -- ��
		then
			if num > 0
			then
				num = num - 1	--ʱ��Խ���ٶ�Խ��
			end
		elseif control == 3 --��
		then
			if num < 3
			then
				num = num + 1	--ʱ��Խ���ٶ�Խ��
			end
		end
		
		set_value(75,42,num)

		if get_value(75,42) == 0
		then
			set_text(75,6,"18S" )
		elseif get_value(75,42) == 1
		then
			set_text(75,6,"14S" )
		elseif get_value(75,42) == 2
		then
			set_text(75,6,"10S" )
		elseif get_value(75,42) == 3
		then
			set_text(75,6,"5S" )
		end
		return 1
	elseif control==3 and value==0	or  control==11 and value==0
	then
		return 1
	elseif control==12 and value==1	or  control==14 and value==1 --��ɫ�����ٶ�
	then
		local num = get_value(75,43)
		
		if control == 14 -- ��
		then
			if num > 0
			then
				num = num - 1	--ʱ��Խ���ٶ�Խ��
			end
		elseif control == 12 --��
		then
			if num < 3
			then
				num = num + 1	--ʱ��Խ���ٶ�Խ��
			end
		end
		
		set_value(75,43,num)

		if get_value(75,43) == 0
		then
			set_text(75,13,"120S" )
		elseif get_value(75,43) == 1
		then
			set_text(75,13,"90S" )
		elseif get_value(75,43) == 2
		then
			set_text(75,13,"60S" )
		elseif get_value(75,43) == 3
		then
			set_text(75,13,"30S" )
		end
		return 1
	elseif control==12 and value==0	or  control==14 and value==0
	then
		return 1
	elseif control==20 and value==1	or  control==40 and value==1 --���ǵ��ٶ�
	then
		local num = get_value(75,44)
		
		if control == 40 -- ��
		then
			if num > 0
			then
				num = num - 1	--ʱ��Խ���ٶ�Խ��
			end
		elseif control == 20 --��
		then
			if num < 3
			then
				num = num + 1	--ʱ��Խ���ٶ�Խ��
			end
		end
		
		set_value(75,44,num)

		if get_value(75,44) == 0
		then
			set_text(75,39,"48S" )
		elseif get_value(75,44) == 1
		then
			set_text(75,39,"37S" )
		elseif get_value(75,44) == 2
		then
			set_text(75,39,"25S" )
		elseif get_value(75,44) == 3
		then
			set_text(75,39,"15S" )
		end
		return 1
	elseif control==20 and value==0	or  control==40 and value==0
	then
		return 1
	elseif control==34 and value==1	--����Ч������
	then
		set_text(75,35,"Setting")
		
		--�������� 	�����ϵ���ʾЧ��		����2S���ź���ʾ  		�ϵ�Ԥ�跢�ͼ��
		tmp_dat[7] = get_value(75,15) * 64 + get_value(75,8) * 16 + get_value(75,16)
			
		--��ʾ����	���Ǽ��					���ǲ�ֵ  				����Ч������1		2						3						4
		tmp_dat[8] = get_value(75,28) * 64 + get_value(75,31) * 16 +  get_value(75,33) + get_value(75,36) * 2 + get_value(75,37) * 4 + get_value(75,38) * 8
		
		--Ч���ٶ�	�߲������ٶ�			 ȫ�׽����ٶ�			��ɫ�����ٶ�			���ǵ��ٶ�
		tmp_dat[9] = get_value(75,32) * 64 + get_value(75,42) * 16 + get_value(75,43) * 4 + get_value(75,44)
		
		--�ϵ�Ԥ��״̬ ͨ��1~7�ϵ�Ԥ��״̬ tmp_dat[10] ~ tmp_dat[16]
		for i = 1,7 do
			tmp_dat[i+9] = get_value(75,i+52)
		end	
		Send_param_cmd(0x41,0x04,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],tmp_dat[13],tmp_dat[14],tmp_dat[15],tmp_dat[16])	
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
		
		if get_value(75,15) == 0
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ��ɫ")
			elseif get_language() == 1--Ӣ��
			then
				set_text(40,2,"Write ok,\r\nall black")	
			end
		elseif get_value(75,15) == 1
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ������Ч��")
			elseif get_language() == 1--Ӣ��
			then	
				set_text(40,2,"Write ok,\r\nAll Play Built in effects")
			end
		elseif get_value(75,15) == 2
		then
			if get_language() == 0--����
			then
				set_text(40,2,"д�����ɹ���,\r\n����оƬ��ʾ�ϵ�������ɫ")
			elseif get_language() == 1--Ӣ��
			then
				set_text(40,2,"Write ok,\r\nall light power on light status")	
			end
		end
		
		change_screen(40)
		
		return 1
	elseif control==34 and value==0	
	then
		return 1		
	end
end

function screen_76()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==18 and value==1	--����ͨ����
	then
		local num = get_value(76,19)
		
		num = num + 1
		
		if num > 7
		then
			num = 0
		end
		
		set_value(76,19,num)

		for i = 1,7 do
		
			set_value(73,i+44,i)
			
			if i <= num
			then
				set_visiable(76,i+52,1)
			else
				set_visiable(76,i+52,0)
			end
		end
		
		return 1
	elseif control==18 and value==0
	then
		return 1			
	elseif control==7 and value==1	--ת��ͨ��ѡ��
	then
		return 1	
	elseif control==7 and value==0
	then
		return 1	
	elseif control==21 and value==1	--ת��Э��ѡ��
	then
		return 1	
	elseif control==21 and value==0
	then
		return 1
	elseif control==22 and value==1	--ת������ѡ��
	then
		return 1	
	elseif control==22 and value==0
	then
		return 1
	elseif control==2 and value==1	--ȥдַ
	then
		set_text(3,8,get_text(76,5))		
		change_screen(3)
		
		DMX_add_param = 0x33
		return 1	
	elseif control==2 and value==0
	then
		return 1
	elseif control==34 and value==1	--���ź�״̬���ϵ�Ҷ�����
	then
		set_text(76,35,"Setting")
		
		--��������λ ת����ɫ				 ת��ͨ��				   ת��Э��
		tmp_dat[7] = get_value(76,19) * 16 + get_value(76,7) * 8 + get_value(76,9)
		
		--ͨ������   ת������				 ת������
		tmp_dat[8] = get_value(76,22) * 32 + get_value(76,7)
		
		--ͨ��1~7ת������ tmp_dat[9] ~ tmp_dat[15]
		for i = 1,7 do
			tmp_dat[i+8] = get_value(76,i+52)
			
			if get_value(76,19) == 0	--Ϊ0ʱ��ת��
			then
				tmp_dat[i+8] = 0
			end
		end	
			
		Send_param_cmd(0x41,0x00,tmp_dat[7],tmp_dat[8],tmp_dat[9],tmp_dat[10],tmp_dat[11],tmp_dat[12],tmp_dat[13],tmp_dat[14],tmp_dat[15],0)	
		
		stop_timer(4)
		start_timer(4,time5,1,1)
		
		DMX_Status_page = 0x55
		
		if get_language() == 0--����
		then
			set_text(40,2,"д�����ɹ���,\r\n��оƬ�����,\r\n����оƬ������")
		elseif get_language() == 1--Ӣ��
		then
			set_text(40,2,"Write ok,\r\nfirst red,\r\nother blue")
		end	
		
		change_screen(40)
		return 1
	elseif control==34 and value==0	
	then
		return 1		
	end
end

function screen_77()
	screen = screen_t
	control = control_t
	value = value_t
	
	if control==4 and value==1
	then
		ztd_flag = 0x44
		
		set_text(39,2,"")--��������
		set_text(39,8,"")

		if secret_2 == 0x00--��һ�ε��������ʱ
		then
			change_screen(39)
		else
			if get_language() == 0--����
			then
				set_text(36,2,"��ȷ��Ҫ���øò�����")	
				set_text(36,7,"д�ɹ������е����׹�")
			elseif get_language() == 1--Ӣ��
			then
				set_text(36,2,"Are you sure set param��")			
				set_text(36,7,"Write ok,all white")
			end	
			
			change_screen(36)
		end
		return 1
	elseif control==4 and value==0
	then
		return 1
	end
end